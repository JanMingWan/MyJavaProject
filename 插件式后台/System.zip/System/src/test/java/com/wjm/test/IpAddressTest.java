package com.wjm.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.junit.Test;

public class IpAddressTest {
	@Test
	public void checkIp() throws ClientProtocolException, IOException {

//		@SuppressWarnings("static-access")
//		Map<String, String> a = new IpAddress()
//				.checkIpAddress("192.168.1.120");
//		System.out.println(a!=null);
//		for (String key : a.keySet()) {
//			System.out.println(a.get(key));
//		}

	}
}

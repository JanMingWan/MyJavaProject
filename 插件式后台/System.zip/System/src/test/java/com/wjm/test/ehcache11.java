package com.wjm.test;

import org.junit.Test;

import com.system.util.ehcache.EhCache;

public class ehcache11 {
	@Test
	public void tt() {
		EhCache e1 = EhCache.getInstance();
		String bb = "123";
		e1.setCache("adminCache", "a", bb);

		String a = (String) e1.getCache("adminCache", "a");
		System.out.println(a == null ? "空" : a);
	}

}

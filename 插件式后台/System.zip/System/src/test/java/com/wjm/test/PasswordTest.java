package com.wjm.test;

import java.util.Date;

import org.junit.Test;

import com.system.util.encryption.Encryption;

public class PasswordTest {
	@Test
	public void password() {
		System.out.println("普通密码123123:" + Encryption.MD5("123123"));

		String dataTime = String.valueOf(new Date().getTime());
		System.out.println("dataTime:" + dataTime);
		System.out.println("盐值加密123123:"
				+ Encryption.MD5Encryption("123123", dataTime));

		System.out.println("登录密码校验:"
				+ Encryption.checkPassword(
						Encryption.MD5Encryption("123123", dataTime), "123123",
						dataTime));
	}
}

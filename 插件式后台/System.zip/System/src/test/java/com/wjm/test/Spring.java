package com.wjm.test;

import org.junit.Test;

public class Spring {
	@Test
	public void test1() {
		// ApplicationContext ap = new ClassPathXmlApplicationContext(
		// "applicationContext.xml");
		// IAdminService admin = (IAdminService) ap.getBean("adminServiceImpl");
	}
}

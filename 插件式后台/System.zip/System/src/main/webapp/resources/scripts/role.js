$(document).ready(function() {
		var location = (window.location + '').split('/');
		var basePath = location[0] + '//' + location[2] + '/'+ location[3];
		$('#name').blur(function() {
			var name1 = $('#name').val();
			if (name1 != "") {
			$.ajax({
			type : "POST",
			url : basePath+ "/manageRole/role!checkRoleName.action",
			data : "name=" + name1,
			dataType : 'json',
			success : function(msg) {
					if (msg.success) {
							 $('#success_name').show();
							 $('#success_name').html(msg.msg);
							 $('#error_name').hide();
							 $('#add').removeAttr("disabled");
					} else {
							 $('#success_name').hide();
							 $('#error_name').show();
							 $('#error_name').html(msg.msg);
							 $('#add').attr({disabled : "disabled"});
					}
				}
		    });
			} else {
				$('#success_name').hide();
				$('#error_name').show();
				$('#error_name').html("不能为空");
				$('#add').attr({disabled : "disabled"});
			}
			});	
			$('#action').click(function() {
				var checkId = "";
				if ($('#dropdown').val() == 1) {// 删除功能
					$(".checkbox:checked").each(function() {
						checkId += $(this).attr("id")+ ",";
					});
					
						if (checkId != "") {
							  if (confirm('确定删除所选项?'))window.location.href = basePath+ "/manageRole/role!deleteRole.action?roleId="+ checkId;
						} else {
							  alert("请选中要删除的项");
						}
				}
			 });
		   $('#update_authority').submit(function() {
						if ($('#update_url').val() != "") {
							$('#success_url').show();
							$('#success_url').html("校验成功");
							$('#error_url').hide();
							return true;
						} else {
							url = false;
							$('#success_url').hide();
							$('#error_url').show();
							$('#error_url').html("不能为空");
							return false;
						}
			});
		   
		   $('#surplusCheckbox').click(function(){//全选

			 $("#surplusCheckbox").attr("checked",($(this).attr("checked")=='checked'?false:true));
			   $(".authority").attr("checked",($(this).attr("checked")=='checked'?true:false));
		   });
		   
		/*   $(".authority").click(function(){
			  if($(".authority:checked").length==$(".authority").length){
				  $('#surplusCheckbox').attr("checked",true);
			  }else{
				  $('#surplusCheckbox').attr("checked",false);
			  }
		   });*/
});

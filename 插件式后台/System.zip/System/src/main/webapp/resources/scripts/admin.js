function checkSumit(checkName,checkRealName,checkEmail){
	if (checkName == true && checkRealName == true&&checkEmail==true) {
		$('#addAdmin').removeAttr("disabled");
	} else {
		$('#addAdmin').attr({disabled : "disabled"});
	}
}

$(document).ready(function() {
	//basePath
	var location = (window.location + '').split('/');
	var basePath = location[0] + '//' + location[2] + '/'+ location[3];	
	var checkName=false;
	var checkRealName=false;
	var checkEmail=false;
	//异步校验登录名
	$('#name').blur(function(){//名字异步校验
		var name=$('#name').val();
		if(name!=""){
			$.ajax({
				type : "POST",
				url : basePath+ "/manageAdmin/admin!checkName.action",
				data : "name=" + name,
				dataType : 'json',
				success : function(msg) {
					if (msg.success) {
							$('#success_name').show();
							$('#success_name').html(msg.msg);
							$('#error_name').hide();
							checkName = true;
							checkSumit(checkName,checkRealName,checkEmail);
					} else {
						    $('#success_name').hide();
							$('#error_name').show();
							$('#error_name').html(msg.msg);
							checkName = false;
					}
				}
		     });	
		}else{
			$('#success_name').hide();
			$('#error_name').show();
			$('#error_name').html("不能为空");
			checkName = false;
		}
	});	
	//异步校验真实姓名
	$('#realName').blur(function(){
		var realName=$('#realName').val();
		if(realName!=""){
			$.ajax({
				type : "POST",
				url : basePath+ "/manageAdmin/admin!checkRealName.action",
				data : "realName=" + realName,
				dataType : 'json',
				success : function(msg) {
					if (msg.success) {
						
							$('#success_realName').show();
							$('#success_realName').html(msg.msg);
							$('#error_realName').hide();
							checkRealName = true;
							checkSumit(checkName,checkRealName,checkEmail);
					} else {
						
						    $('#success_realName').hide();
							$('#error_realName').show();
							$('#error_realName').html(msg.msg);
							checkRealName = false;
					}
				}
		     });	
		}else{
			$('#success_realName').hide();
			$('#error_realName').show();
			$('#error_realName').html("不能为空");
			checkRealName = false;
		}
	});
	//简单校验邮箱
	$('#email').blur(function(){
		var email=$('#email').val();
		if(email!=""){
			$('#success_email').show();
			$('#success_email').html("校验成功");
			$('#error_email').hide();
			checkEmail = true;
			checkSumit(checkName,checkRealName,checkEmail);
		}else{
			$('#success_email').hide();
			$('#error_email').show();
			$('#error_email').html("不能为空");
			checkEmail = false;
		}
	});
	//校验管理员类型
	$(".type").click(function(){
		if($(this).val()==2){
		   $('#city').show();
		}else{
		   $('#city').hide();
		}
	});
	//批量命令
	$('#action').click(function() {
		var checkId = "";
		if ($('#dropdown').val() == 1) {// 删除功能
			$(".checkbox:checked").each(function() {
				checkId += $(this).attr("id")+ ",";
			});
			if (checkId != "") {
			    if (confirm('确定删除所选项?'))window.location.href = basePath+ "/manageAdmin/admin!deleteAdmin.action?adminId="+ checkId;
			} else {
			    alert("请选中要删除的项");
			}
		}
	 });
});
function check(obj, obj2) {
	if (obj == true && obj2 == true) {
		$('#add').removeAttr("disabled");
	} else {
		$('#add').attr({disabled : "disabled"});
	}
}

$(document)
		.ready(
				function() {
					var location = (window.location + '').split('/');
					var basePath = location[0] + '//' + location[2] + '/'+ location[3];
					var name = false;
					var url = false;
					$('#name')
							.blur(
									function() {
										var name1 = $('#name').val();
										if (name1 != "") {
											$.ajax({
												type : "POST",
												url : basePath+ "/manageAuthority/authority!checkAuthorityName.action",
												data : "name=" + name1,
												dataType : 'json',
												success : function(msg) {
													if (msg.success) {
																$('#success_name').show();
																$('#success_name').html(msg.msg);
																$('#error_name').hide();
																name = true;
																check(name, url);
															} else {
																$(
																		'#success_name')
																		.hide();
																$('#error_name')
																		.show();
																$('#error_name')
																		.html(
																				msg.msg);
																name = false;
																check(name, url);
															}
														}
													});
										} else {
											$('#success_name').hide();
											$('#error_name').show();
											$('#error_name').html("不能为空");
											name = false;
											check(name, url);
										}
									});
					$('#url').blur(function() {
						if ($('#url').val() != "") {
							url = true;
							$('#success_url').show();
							$('#success_url').html("校验成功");
							$('#error_url').hide();
							check(name, url);
						} else {
							url = false;
							$('#success_url').hide();
							$('#error_url').show();
							$('#error_url').html("不能为空");
							check(name, url);
						}
					});
					$('#action').click(function() {
							var checkId = "";
							if ($('#dropdown').val() == 1) {// 删除功能
							    $(".checkbox:checked").each(function() {
									checkId += $(this).attr("id")+ ",";});
							    if (checkId != "") {
							        if (confirm('确定删除所选项?'))window.location.href = basePath+ "/manageAuthority/authority!deleteAuthority.action?authorityId="+ checkId;
							    } else {
								    alert("请选中要删除的项");
								}
							}else if($('#dropdown').val() == 2){//批量关联
								 $(".checkbox:checked").each(function(){checkId += $(this).attr("id")+ ",";});
								 if (checkId != "") {
								        window.location.href = basePath+ "/manageAuthority/authority!jumpRelevance.action?authorityId="+ checkId;
								 } else {
									    alert("请选中要关联的项");
							     }
							}
					});
					$('#update_authority').submit(function() {
						if ($('#update_url').val() != "") {
							$('#success_url').show();
							$('#success_url').html("校验成功");
							$('#error_url').hide();
							return true;
						} else {
							url = false;
							$('#success_url').hide();
							$('#error_url').show();
							$('#error_url').html("不能为空");
							return false;
						}
					});
				});

package com.system.manageModelDriven;

import java.io.Serializable;

import com.system.base.impl.BaseModelDriven;

/**
 * 
 * @classDescription:权限&菜单模型驱动
 * @author: 王嘉明
 * @cerateTime: 2013-11-28
 * @className: AuthorityModelDriven.java
 */

public class AuthorityModelDriven extends BaseModelDriven implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7332721883180675339L;
	private String authorityId;// id
	private Boolean isMenu;// 是否菜单项
	private String name;// 名字
	private String permissonCode;// 权限类型(CRUD)
	private Boolean status;// 是否冻结
	private String url;// 路径
	private int type;// 权限类型
	private String menuId;// 菜单项ID
	

	

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getAuthorityId() {
		return authorityId;
	}

	public void setAuthorityId(String authorityId) {
		this.authorityId = authorityId;
	}

	public Boolean getIsMenu() {
		return isMenu;
	}

	public void setIsMenu(Boolean isMenu) {
		this.isMenu = isMenu;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPermissonCode() {
		return permissonCode;
	}

	public void setPermissonCode(String permissonCode) {
		this.permissonCode = permissonCode;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	

}

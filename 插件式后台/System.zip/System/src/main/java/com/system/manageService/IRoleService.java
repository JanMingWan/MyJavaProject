package com.system.manageService;

import java.util.List;
import java.util.Set;

import com.system.base.IBaseService;
import com.system.manageModel.Admin;
import com.system.manageModel.Authority;
import com.system.manageModel.Role;
import com.system.manageModelDriven.RoleModelDriven;

/**
 * 
 * @classDescription:role业务接口
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: IRoleService.java
 */
public interface IRoleService extends IBaseService<Role, RoleModelDriven> {
	/**
	 * 检查权限名是否重复
	 * 
	 * @param roleModelDriven
	 * @return
	 */
	public boolean checkRoleName(RoleModelDriven roleModelDriven);

	/**
	 * 排除当前角色的权限
	 * 
	 * @param roleAuthority
	 * @return
	 */
	public List<Authority> getSurplusAuthority(Set<Authority> roleAuthority);

	/**
	 * 获取关联权限
	 * 
	 * @param roleModelDriven
	 * @return
	 */
	public Set<Authority> getAuthorityList(Role role);

	/**
	 * 更新角色权限
	 * 
	 * @param roleModelDriven
	 * @return
	 */
	public void updateRoleAuthority(RoleModelDriven roleModelDriven);

	/**
	 * 剩余管理员
	 * 
	 * @param admin
	 *            已选管理员
	 * @return
	 */
	public List<Admin> getSurplusAdmin(Set<Admin> admin);

	/**
	 * 更新角色管理员
	 * 
	 * @param roleModelDriven
	 */
	public void updateRoleAdmin(RoleModelDriven roleModelDriven);
}

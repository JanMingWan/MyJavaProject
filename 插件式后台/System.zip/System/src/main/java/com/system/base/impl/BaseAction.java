package com.system.base.impl;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSON;
import com.opensymphony.xwork2.ActionSupport;
import com.system.util.ehcache.EhCache;

/**
 * @className:BaseAction.java
 * @author 王嘉明
 * @createTime:2013-11-5 父类Action,封装serlvetAPI,和其他通用方法
 * 
 */
@Controller
@Scope("prototype")
public abstract class BaseAction extends ActionSupport implements
		ServletRequestAware, ServletResponseAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7345605010030388776L;
	protected HttpServletRequest request;
	protected HttpServletResponse response;

	protected EhCache ehCache = EhCache.getInstance();// 初始化单例模式eh缓存

	/**
	 * 取得HttpSession的简化函数.
	 */
	public HttpSession getSession() {
		return request.getSession();
	}

	/**
	 * request获取参数简化方法
	 * 
	 * @param name参数名
	 * @return
	 */
	public String getParameter(String name) {
		return (null == this.request.getParameter(name)) ? null : this.request
				.getParameter(name);
	}

	/**
	 * 获取request
	 * 
	 * @param name
	 *            参数名
	 * @return
	 */
	public Object getRequestAttribute(String name) {
		return request.getAttribute(name);
	}

	/**
	 * 获取session
	 * 
	 * @param name
	 *            参数名
	 * @return
	 */
	public Object getSessionAttribute(String name) {
		return this.getSession().getAttribute(name);
	}

	/**
	 * 设置request
	 * 
	 * @param key
	 *            参数名
	 * @param object
	 *            类
	 */
	public void setRequestAttribute(String key, Object object) {
		request.setAttribute(key, object);
	}

	/**
	 * 设置session
	 * 
	 * @param name
	 *            session名
	 * @param object
	 *            类
	 */
	public void setSessionAttribute(String name, Object object) {
		getSession().setAttribute(name, object);
	}

	/**
	 * 获取root
	 * 
	 * @return
	 */
	public String getRoot() {
		return request.getContextPath();
	}

	/**
	 * 获取根目录
	 * 
	 */
	public String getRealRoot() {
		return this.getSession().getServletContext().getRealPath("/");
	}

	/**
	 * 获取IP
	 * 
	 * @return ip
	 */
	public String getRemoteAddr() {
		return request.getRemoteAddr();
	}

	/**
	 * 返回json给前台
	 * 
	 * @param json
	 */
	public void writeJson(Object json) {

		try {
			ServletActionContext.getResponse().setContentType(
					"text/html;charset=utf-8");
			ServletActionContext.getResponse().getWriter()
					.write(JSON.toJSONString(json));
			ServletActionContext.getResponse().getWriter().flush();
			ServletActionContext.getResponse().getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// -----------------------------------
	@Override
	public void setServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}

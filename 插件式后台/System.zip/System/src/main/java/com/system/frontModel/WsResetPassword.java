package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsResetPassword entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_reset_password", catalog = "wslm")
public class WsResetPassword implements java.io.Serializable {

	// Fields

	private Integer resetId;
	private String resetEmail;
	private String resetCode;
	private Integer resetTime;
	private Boolean resetType;

	// Constructors

	/** default constructor */
	public WsResetPassword() {
	}

	/** full constructor */
	public WsResetPassword(String resetEmail, String resetCode,
			Integer resetTime, Boolean resetType) {
		this.resetEmail = resetEmail;
		this.resetCode = resetCode;
		this.resetTime = resetTime;
		this.resetType = resetType;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "reset_id", unique = true, nullable = false)
	public Integer getResetId() {
		return this.resetId;
	}

	public void setResetId(Integer resetId) {
		this.resetId = resetId;
	}

	@Column(name = "reset_email", nullable = false, length = 60)
	public String getResetEmail() {
		return this.resetEmail;
	}

	public void setResetEmail(String resetEmail) {
		this.resetEmail = resetEmail;
	}

	@Column(name = "reset_code", nullable = false, length = 45)
	public String getResetCode() {
		return this.resetCode;
	}

	public void setResetCode(String resetCode) {
		this.resetCode = resetCode;
	}

	@Column(name = "reset_time", nullable = false)
	public Integer getResetTime() {
		return this.resetTime;
	}

	public void setResetTime(Integer resetTime) {
		this.resetTime = resetTime;
	}

	@Column(name = "reset_type", nullable = false)
	public Boolean getResetType() {
		return this.resetType;
	}

	public void setResetType(Boolean resetType) {
		this.resetType = resetType;
	}

}
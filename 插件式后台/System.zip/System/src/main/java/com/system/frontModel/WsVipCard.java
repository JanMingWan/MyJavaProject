package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * WsVipCard entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_vip_card", catalog = "wslm", uniqueConstraints = @UniqueConstraint(columnNames = "vip_code"))
public class WsVipCard implements java.io.Serializable {

	// Fields

	private Integer vipId;
	private String vipCode;
	private String vipPassword;
	private Boolean useable;
	private Integer useTime;
	private Integer userId;
	private String remarks;

	// Constructors

	/** default constructor */
	public WsVipCard() {
	}

	/** minimal constructor */
	public WsVipCard(String vipCode, String vipPassword, Boolean useable) {
		this.vipCode = vipCode;
		this.vipPassword = vipPassword;
		this.useable = useable;
	}

	/** full constructor */
	public WsVipCard(String vipCode, String vipPassword, Boolean useable,
			Integer useTime, Integer userId, String remarks) {
		this.vipCode = vipCode;
		this.vipPassword = vipPassword;
		this.useable = useable;
		this.useTime = useTime;
		this.userId = userId;
		this.remarks = remarks;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "vip_id", unique = true, nullable = false)
	public Integer getVipId() {
		return this.vipId;
	}

	public void setVipId(Integer vipId) {
		this.vipId = vipId;
	}

	@Column(name = "vip_code", unique = true, nullable = false, length = 20)
	public String getVipCode() {
		return this.vipCode;
	}

	public void setVipCode(String vipCode) {
		this.vipCode = vipCode;
	}

	@Column(name = "vip_password", nullable = false, length = 20)
	public String getVipPassword() {
		return this.vipPassword;
	}

	public void setVipPassword(String vipPassword) {
		this.vipPassword = vipPassword;
	}

	@Column(name = "useable", nullable = false)
	public Boolean getUseable() {
		return this.useable;
	}

	public void setUseable(Boolean useable) {
		this.useable = useable;
	}

	@Column(name = "use_time")
	public Integer getUseTime() {
		return this.useTime;
	}

	public void setUseTime(Integer useTime) {
		this.useTime = useTime;
	}

	@Column(name = "user_id")
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "remarks", length = 20)
	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
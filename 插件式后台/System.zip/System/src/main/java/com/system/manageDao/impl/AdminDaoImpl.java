package com.system.manageDao.impl;

import org.springframework.stereotype.Repository;

import com.system.base.impl.BaseDaoImpl;
import com.system.manageDao.IAdminDao;
import com.system.manageModel.Admin;
/**
 * 后台WsAdminDao接口实现类
 * 
 * @author 王嘉明
 * @createTime:2013/11/18
 * @param <T>
 */

@Repository
public class AdminDaoImpl extends BaseDaoImpl<Admin> implements
		IAdminDao {

}

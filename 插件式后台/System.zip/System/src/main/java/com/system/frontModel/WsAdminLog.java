package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsAdminLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_admin_log", catalog = "wslm")
public class WsAdminLog implements java.io.Serializable {

	// Fields

	private Integer logId;
	private String logInfo;
	private Integer logTime;
	private Integer adminId;
	private String ipAddress;

	// Constructors

	/** default constructor */
	public WsAdminLog() {
	}

	/** full constructor */
	public WsAdminLog(String logInfo, Integer logTime, Integer adminId,
			String ipAddress) {
		this.logInfo = logInfo;
		this.logTime = logTime;
		this.adminId = adminId;
		this.ipAddress = ipAddress;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "log_id", unique = true, nullable = false)
	public Integer getLogId() {
		return this.logId;
	}

	public void setLogId(Integer logId) {
		this.logId = logId;
	}

	@Column(name = "log_info", nullable = false, length = 45)
	public String getLogInfo() {
		return this.logInfo;
	}

	public void setLogInfo(String logInfo) {
		this.logInfo = logInfo;
	}

	@Column(name = "log_time", nullable = false)
	public Integer getLogTime() {
		return this.logTime;
	}

	public void setLogTime(Integer logTime) {
		this.logTime = logTime;
	}

	@Column(name = "admin_id", nullable = false)
	public Integer getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	@Column(name = "ip_address", nullable = false, length = 45)
	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

}
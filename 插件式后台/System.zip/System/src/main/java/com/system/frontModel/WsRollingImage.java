package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsRollingImage entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_rolling_image", catalog = "wslm")
public class WsRollingImage implements java.io.Serializable {

	// Fields

	private Integer imageId;
	private String path;
	private Boolean sort;
	private Boolean isOn;
	private String link;

	// Constructors

	/** default constructor */
	public WsRollingImage() {
	}

	/** full constructor */
	public WsRollingImage(String path, Boolean sort, Boolean isOn, String link) {
		this.path = path;
		this.sort = sort;
		this.isOn = isOn;
		this.link = link;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "image_id", unique = true, nullable = false)
	public Integer getImageId() {
		return this.imageId;
	}

	public void setImageId(Integer imageId) {
		this.imageId = imageId;
	}

	@Column(name = "path", nullable = false, length = 100)
	public String getPath() {
		return this.path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Column(name = "sort", nullable = false)
	public Boolean getSort() {
		return this.sort;
	}

	public void setSort(Boolean sort) {
		this.sort = sort;
	}

	@Column(name = "is_on", nullable = false)
	public Boolean getIsOn() {
		return this.isOn;
	}

	public void setIsOn(Boolean isOn) {
		this.isOn = isOn;
	}

	@Column(name = "link", nullable = false, length = 100)
	public String getLink() {
		return this.link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}
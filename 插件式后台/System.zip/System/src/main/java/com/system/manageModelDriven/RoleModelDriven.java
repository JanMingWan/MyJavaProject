package com.system.manageModelDriven;

import com.system.base.impl.BaseModelDriven;

/**
 * 
 * @classDescription:role模型驱动
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: RoleModelDriven.java
 */
public class RoleModelDriven extends BaseModelDriven {
	private String roleId;// id
	private Long createTime;// 创建时间
	private String name;// 角色名
	private Long modificationTime;// 最后修改时间

	private String authroityId;// 权限ID
	private String adminId;//管理员id

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getAuthroityId() {
		return authroityId;
	}

	public void setAuthroityId(String authroityId) {
		this.authroityId = authroityId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public Long getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(Long modificationTime) {
		this.modificationTime = modificationTime;
	}

}

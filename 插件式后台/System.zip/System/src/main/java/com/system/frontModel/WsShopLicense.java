package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopLicense entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_license", catalog = "wslm")
public class WsShopLicense implements java.io.Serializable {

	// Fields

	private Integer licenseId;
	private String licenseName;

	// Constructors

	/** default constructor */
	public WsShopLicense() {
	}

	/** full constructor */
	public WsShopLicense(Integer licenseId, String licenseName) {
		this.licenseId = licenseId;
		this.licenseName = licenseName;
	}

	// Property accessors
	@Id
	@Column(name = "license_id", unique = true, nullable = false)
	public Integer getLicenseId() {
		return this.licenseId;
	}

	public void setLicenseId(Integer licenseId) {
		this.licenseId = licenseId;
	}

	@Column(name = "license_name", nullable = false, length = 45)
	public String getLicenseName() {
		return this.licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

}
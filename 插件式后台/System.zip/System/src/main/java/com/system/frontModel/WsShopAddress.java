package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopAddress entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_address", catalog = "wslm")
public class WsShopAddress implements java.io.Serializable {

	// Fields

	private Integer branchId;
	private Integer provinceId;
	private String province;
	private Integer cityId;
	private String city;
	private Integer areaId;
	private String area;
	private String address;
	private String shopPhone;
	private Integer shopId;
	private String shopPhone2;
	private String shopPhone3;

	// Constructors

	/** default constructor */
	public WsShopAddress() {
	}

	/** minimal constructor */
	public WsShopAddress(Integer provinceId, String province, Integer cityId,
			String city, Integer areaId, String area, String address,
			String shopPhone, Integer shopId) {
		this.provinceId = provinceId;
		this.province = province;
		this.cityId = cityId;
		this.city = city;
		this.areaId = areaId;
		this.area = area;
		this.address = address;
		this.shopPhone = shopPhone;
		this.shopId = shopId;
	}

	/** full constructor */
	public WsShopAddress(Integer provinceId, String province, Integer cityId,
			String city, Integer areaId, String area, String address,
			String shopPhone, Integer shopId, String shopPhone2,
			String shopPhone3) {
		this.provinceId = provinceId;
		this.province = province;
		this.cityId = cityId;
		this.city = city;
		this.areaId = areaId;
		this.area = area;
		this.address = address;
		this.shopPhone = shopPhone;
		this.shopId = shopId;
		this.shopPhone2 = shopPhone2;
		this.shopPhone3 = shopPhone3;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "branch_id", unique = true, nullable = false)
	public Integer getBranchId() {
		return this.branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	@Column(name = "province_id", nullable = false)
	public Integer getProvinceId() {
		return this.provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	@Column(name = "province", nullable = false)
	public String getProvince() {
		return this.province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	@Column(name = "city_id", nullable = false)
	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	@Column(name = "city", nullable = false)
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "area_id", nullable = false)
	public Integer getAreaId() {
		return this.areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}

	@Column(name = "area", nullable = false)
	public String getArea() {
		return this.area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@Column(name = "address", nullable = false, length = 100)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "shop_phone", nullable = false, length = 40)
	public String getShopPhone() {
		return this.shopPhone;
	}

	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "shop_phone2", length = 40)
	public String getShopPhone2() {
		return this.shopPhone2;
	}

	public void setShopPhone2(String shopPhone2) {
		this.shopPhone2 = shopPhone2;
	}

	@Column(name = "shop_phone3", length = 40)
	public String getShopPhone3() {
		return this.shopPhone3;
	}

	public void setShopPhone3(String shopPhone3) {
		this.shopPhone3 = shopPhone3;
	}

}
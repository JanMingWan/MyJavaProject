package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsUserMessage entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_user_message", catalog = "wslm")
public class WsUserMessage implements java.io.Serializable {

	// Fields

	private Integer messageId;
	private Integer userId;
	private String content;
	private Integer createTime;
	private Integer sendUser;
	private Integer messageType;

	// Constructors

	/** default constructor */
	public WsUserMessage() {
	}

	/** full constructor */
	public WsUserMessage(Integer userId, String content, Integer createTime,
			Integer sendUser, Integer messageType) {
		this.userId = userId;
		this.content = content;
		this.createTime = createTime;
		this.sendUser = sendUser;
		this.messageType = messageType;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "message_id", unique = true, nullable = false)
	public Integer getMessageId() {
		return this.messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	@Column(name = "user_id", nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "content", nullable = false, length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

	@Column(name = "send_user", nullable = false)
	public Integer getSendUser() {
		return this.sendUser;
	}

	public void setSendUser(Integer sendUser) {
		this.sendUser = sendUser;
	}

	@Column(name = "message_type", nullable = false)
	public Integer getMessageType() {
		return this.messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

}
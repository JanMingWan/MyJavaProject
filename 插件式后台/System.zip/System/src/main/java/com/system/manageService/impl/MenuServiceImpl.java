package com.system.manageService.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.manageDao.IAuthorityDao;
import com.system.manageDao.IMenuDao;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModelDriven.MenuModelDriven;
import com.system.manageService.IMenuService;
import com.system.util.date.DateUtil;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:菜单业务实现类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: MenuServiceImpl.java
 */
@Service
public class MenuServiceImpl implements IMenuService {

	@Autowired
	IMenuDao menuDao;
	@Autowired
	IAuthorityDao authorityDao;

	/**
	 * 存储菜单
	 */
	@Override
	public void save(MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		Long time = DateUtil.getTime();
		menu.setCreateTime(time);
		menu.setModificationTime(time);
		menu.setName(menuModelDriven.getName());
		menu.setAuthorities(null);
		menuDao.save(menu, true);
	}

	/**
	 * 校验menu名字
	 */
	@Override
	public boolean checkMenuName(MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		String hql = "from Menu menu where menu.name=:name";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", menuModelDriven.getName());
		List<Menu> menus = menuDao.findAll(hql, params, true);
		if (menus != null && menus.size() > 0)
			return false;
		return true;
	}

	/**
	 * 删除menu
	 */
	@Override
	public void delete(MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		String[] menuId = menuModelDriven.getMenuId().split(",");
		Map<String, Object> params = new HashMap<String, Object>(1);
		for (int i = 0; i < menuId.length; i++) {
			params.put("id", Integer.parseInt(menuId[i]));
			String hql = "from Menu menu where menu.menuId=:id";
			Menu menu = menuDao.get(hql, params, true);
			menuDao.delete(menu, true);
		}
	}

	/**
	 * 更新菜单项
	 */
	@Override
	public void update(MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		Menu menu = get(menuModelDriven);
		menu.setName(menuModelDriven.getName());
		menu.setModificationTime(DateUtil.getTime());
		menuDao.update(menu, true);
	}

	/**
	 * 获取二级菜单
	 */
	@Override
	public Page<Authority> getAuthorityList(String forwordName,
			MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		Page<Authority> authority_Page = new Page<Authority>(25, forwordName,
				menuModelDriven.getSort());
		Map<String, Object> params = new HashMap<String, Object>(1);
		Menu menu = get(menuModelDriven);
		params.put("menu", menu);
		authorityDao.count(authority_Page,
				"select count(*) from Authority a where a.menu=:menu", params,
				true);
		if (menuModelDriven.getPageNo() != null
				&& !menuModelDriven.getPageNo().equals("")) {
			authority_Page.setPageNo(Integer.parseInt(menuModelDriven
					.getPageNo()));
		}
		// 页面设置
		String hql = "from Authority a where a.menu=:menu order by a.createTime "+menuModelDriven.getSort();
		authorityDao.findAll(authority_Page, hql, params, true);

		return authority_Page;
	}

	/**
	 * 关键字查询
	 */
	@Override
	public Page<Menu> search(String forwordName, MenuModelDriven menuModelDriven) {
		// TODO Auto-generated method stub
		Page<Menu> menus_Page = new Page<Menu>(25, forwordName,	menuModelDriven.getSort());
		if (menuModelDriven.getName() != null&& !menuModelDriven.getName().equals("")) {
			Map<String, Object> params = new HashMap<String, Object>(1);
			params.put("name", "%" + menuModelDriven.getName() + "%");
			menuDao.count(
					menus_Page,
					"select count(*) from Menu menu where menu.name like :name",
					params, true);// 获取数量
			if (menuModelDriven.getPageNo() != null
					&& !menuModelDriven.getPageNo().equals("")) {// 查看是否有分页
				menus_Page.setPageNo(Integer.parseInt(menuModelDriven
						.getPageNo()));
			}
			// 页面设置
			String hql = "from Menu menu where menu.name like :name order by menu.createTime "+menuModelDriven.getSort();
			menuDao.findAll(menus_Page, hql, params, true);

		} else {
			menuDao.count(menus_Page, "select count(*) from Menu", null, true);// 获取数量
			if (menuModelDriven.getPageNo() != null
					&& !menuModelDriven.getPageNo().equals("")) {// 查看是否有分页
				menus_Page.setPageNo(Integer.parseInt(menuModelDriven
						.getPageNo()));
			}
			// 页面设置
			String hql = "from Menu menu order by menu.menuId "+menuModelDriven.getSort();
			menuDao.findAll(menus_Page, hql, null, true);
		}
		return menus_Page;
	}

	/**
	 * 查询menu对象
	 */
	@Override
	public Menu get(MenuModelDriven menuModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("id", Integer.parseInt(menuModelDriven.getMenuId()));
		String hql = "from Menu menu where menu.menuId=:id";
		return menuDao.get(hql, params, true);
	}

	/**
	 * 查询所有menu
	 */
	@Override
	public Page<Menu> findAll(String forwordName,MenuModelDriven menuModelDriven) {
		Page<Menu> menu_Page = new Page<Menu>(25, forwordName,menuModelDriven.getSort());// 设置页数
		menuDao.count(menu_Page, "select count(*) from Menu", null, true);// 获取数量
		if (menuModelDriven.getPageNo() != null	&& !menuModelDriven.getPageNo().equals("")) {// 查看是否有分页
			menu_Page.setPageNo(Integer.parseInt(menuModelDriven.getPageNo()));
		}// 页面设置
		String hql = "from Menu menu order by menu.createTime "	+ menuModelDriven.getSort();
		menuDao.findAll(menu_Page, hql, null, true);

		return menu_Page;
	}

}

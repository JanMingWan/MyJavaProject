package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsIndexShop entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_index_shop", catalog = "wslm")
public class WsIndexShop implements java.io.Serializable {

	// Fields

	private Integer indexShopId;
	private String content;
	private String shopName;
	private String imagePath;
	private String url;
	private String sn;

	// Constructors

	/** default constructor */
	public WsIndexShop() {
	}

	/** full constructor */
	public WsIndexShop(String content, String shopName, String imagePath,
			String url, String sn) {
		this.content = content;
		this.shopName = shopName;
		this.imagePath = imagePath;
		this.url = url;
		this.sn = sn;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "index_shop_id", unique = true, nullable = false)
	public Integer getIndexShopId() {
		return this.indexShopId;
	}

	public void setIndexShopId(Integer indexShopId) {
		this.indexShopId = indexShopId;
	}

	@Column(name = "content", nullable = false, length = 100)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "shop_name", nullable = false, length = 30)
	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	@Column(name = "image_path", nullable = false, length = 100)
	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Column(name = "url", nullable = false, length = 100)
	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "sn", nullable = false, length = 10)
	public String getSn() {
		return this.sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

}
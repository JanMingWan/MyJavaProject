package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsAdmin entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_admin", catalog = "wslm")
public class WsAdmin implements java.io.Serializable {

	// Fields

	private Integer adminId;
	private String email;
	private String name;
	private String password;
	private String phone;
	private String actionList;
	private Integer roleId;
	private Boolean state;
	private Integer addTime;
	private String lastIp;
	private Integer lastLogin;

	// Constructors

	/** default constructor */
	public WsAdmin() {
	}

	/** minimal constructor */
	public WsAdmin(String email, String name, String password, Integer roleId,
			Boolean state) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.roleId = roleId;
		this.state = state;
	}

	/** full constructor */
	public WsAdmin(String email, String name, String password, String phone,
			String actionList, Integer roleId, Boolean state, Integer addTime,
			String lastIp, Integer lastLogin) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.phone = phone;
		this.actionList = actionList;
		this.roleId = roleId;
		this.state = state;
		this.addTime = addTime;
		this.lastIp = lastIp;
		this.lastLogin = lastLogin;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "admin_id", unique = true, nullable = false)
	public Integer getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	@Column(name = "email", nullable = false, length = 60)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "name", nullable = false, length = 20)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "password", nullable = false, length = 32)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "phone", length = 11)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "action_list", length = 65535)
	public String getActionList() {
		return this.actionList;
	}

	public void setActionList(String actionList) {
		this.actionList = actionList;
	}

	@Column(name = "role_id", nullable = false)
	public Integer getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	@Column(name = "state", nullable = false)
	public Boolean getState() {
		return this.state;
	}

	public void setState(Boolean state) {
		this.state = state;
	}

	@Column(name = "add_time")
	public Integer getAddTime() {
		return this.addTime;
	}

	public void setAddTime(Integer addTime) {
		this.addTime = addTime;
	}

	@Column(name = "last_ip", length = 15)
	public String getLastIp() {
		return this.lastIp;
	}

	public void setLastIp(String lastIp) {
		this.lastIp = lastIp;
	}

	@Column(name = "last_login")
	public Integer getLastLogin() {
		return this.lastLogin;
	}

	public void setLastLogin(Integer lastLogin) {
		this.lastLogin = lastLogin;
	}

}
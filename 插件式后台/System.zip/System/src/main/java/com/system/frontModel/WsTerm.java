package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsTerm entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_term", catalog = "wslm")
public class WsTerm implements java.io.Serializable {

	// Fields

	private Integer termId;
	private String term;

	// Constructors

	/** default constructor */
	public WsTerm() {
	}

	/** full constructor */
	public WsTerm(String term) {
		this.term = term;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "term_id", unique = true, nullable = false)
	public Integer getTermId() {
		return this.termId;
	}

	public void setTermId(Integer termId) {
		this.termId = termId;
	}

	@Column(name = "term", nullable = false, length = 20)
	public String getTerm() {
		return this.term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

}
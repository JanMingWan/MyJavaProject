package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsCity entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_city", catalog = "wslm")
public class WsCity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 2441208164308962104L;
	private Integer cityId;//id
	private String city;//城市名
	private Integer provinceId;//省名
	private Boolean useable;//是否激活

	// Constructors

	/** default constructor */
	public WsCity() {
	}

	/** full constructor */
	public WsCity(Integer cityId, String city, Integer provinceId,
			Boolean useable) {
		this.cityId = cityId;
		this.city = city;
		this.provinceId = provinceId;
		this.useable = useable;
	}

	// Property accessors
	@Id
	@Column(name = "city_id", unique = true, nullable = false)
	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	@Column(name = "city", nullable = false, length = 50)
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "province_id", nullable = false)
	public Integer getProvinceId() {
		return this.provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	@Column(name = "useable", nullable = false)
	public Boolean getUseable() {
		return this.useable;
	}

	public void setUseable(Boolean useable) {
		this.useable = useable;
	}

}
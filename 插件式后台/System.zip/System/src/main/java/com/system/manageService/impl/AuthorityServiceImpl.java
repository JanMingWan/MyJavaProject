package com.system.manageService.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.manageDao.IAuthorityDao;
import com.system.manageDao.IMenuDao;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModel.Role;
import com.system.manageModelDriven.AuthorityModelDriven;
import com.system.manageService.IAuthorityService;
import com.system.util.date.DateUtil;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:权限&菜单业务层实现类
 * @author: 王嘉明
 * @cerateTime: 2013-11-28
 * @className: AuthorityService.java
 */
@Service
public class AuthorityServiceImpl implements IAuthorityService {

	@Autowired
	IAuthorityDao authorityDao;
	@Autowired
	IMenuDao menuDao;

	/**
	 * 检查权限名字
	 */
	@Override
	public boolean checkAuthority(AuthorityModelDriven authorityModelDriven) {
		String hql = "from Authority a where a.name=:name";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", authorityModelDriven.getName());
		List<Authority> authority = authorityDao.findAll(hql, params, true);
		if (authority != null && authority.size() > 0)
			return false;
		return true;
	}

	/**
	 * 保存
	 */
	@Override
	public void save(AuthorityModelDriven authorityModelDriven) {
		Authority authority = new Authority();
		BeanUtils.copyProperties(authorityModelDriven, authority,
				new String[] { "pageNo" });// 复制参数
		long time = DateUtil.getTime();
		authority.setCreateTime(time);
		authority.setModificationTime(time);
		authority.setStatus(true);
		authorityDao.save(authority, true);
	}

	/**
	 * 删除权限
	 */
	@Override
	public void delete(AuthorityModelDriven authorityModelDriven) {
		// 分割ID
		String[] authorityId = authorityModelDriven.getAuthorityId().split(",");// 获取客户端
		// 设置ID参数
		Map<String, Object> params = new HashMap<String, Object>(1);
		for (int i = 0; i < authorityId.length; i++) {
			params.put("id", Integer.parseInt(authorityId[i]));
			String hql = "from Authority a where a.authorityId=:id";
			Authority authority = authorityDao.get(hql, params, true);
			authorityDao.delete(authority, true);
		}
	}

	/**
	 * 搜索
	 */
	@Override
	public Page<Authority> search(String forwordName,
			AuthorityModelDriven authorityModelDriven) {
		Page<Authority> authority_Page = new Page<Authority>(25, forwordName,
				authorityModelDriven.getSort());// 创建新页面类
		if (authorityModelDriven.getName() != null
				&& !authorityModelDriven.getName().equals("")) {// 若存在搜索字眼
			Map<String, Object> params = new HashMap<String, Object>(1);// 一个搜索参数
			params.put("name", "%" + authorityModelDriven.getName() + "%");// 设置参数
			authorityDao.count(authority_Page,
					"select count(*) from Authority a where a.name like :name",
					params, true);// 搜索总记录数
			if (authorityModelDriven.getPageNo() != null
					&& !authorityModelDriven.getPageNo().equals("")) {// 设置跳转页数
				authorityModelDriven
						.setPageNo(authorityModelDriven.getPageNo());// 设置跳转页
			}
			String hql = "from Authority a where a.name like :name order by a.authorityId "
					+ authorityModelDriven.getSort();// 搜索
			authorityDao.findAll(authority_Page, hql, params, true);
		} else {// 若搜索为空
			authorityDao.count(authority_Page,
					"select count(*) from Authority", null, true);// 搜索总列表
			if (authorityModelDriven.getPageNo() != null
					&& !authorityModelDriven.getPageNo().equals("")) {// 设置跳转页数
				authorityModelDriven
						.setPageNo(authorityModelDriven.getPageNo());// 设置跳转页
			}
			String hql = "from Authority a order by a.authorityId "
					+ authorityModelDriven.getSort();
			authorityDao.findAll(authority_Page, hql, null, true);
		}
		return authority_Page;
	}

	/**
	 * 更新authority
	 */
	@Override
	public void update(AuthorityModelDriven authorityModelDriven) {
		Authority authority = get(authorityModelDriven);// 查询该类
		BeanUtils.copyProperties(authorityModelDriven, authority, new String[] {
				"authorityId", "pageNo", "name" });// 复制参数
		authority.setModificationTime(DateUtil.getTime());// 设置更新时间
		authorityDao.update(authority, true);// 更新

	}

	/**
	 * 获取authority对象
	 */
	@Override
	public Authority get(AuthorityModelDriven authorityModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("id",
				Integer.parseInt(authorityModelDriven.getAuthorityId()));
		String hql = "from Authority a where a.authorityId=:id";
		return authorityDao.get(hql, params, true);
	}

	/**
	 * 查询所有authority
	 */
	@Override
	public Page<Authority> findAll(String forwordName,
			AuthorityModelDriven authorityModelDriven) {
		Page<Authority> authority_Page = new Page<Authority>(25, forwordName,
				authorityModelDriven.getSort());
		authorityDao.count(authority_Page, "select count(*) from Authority",
				null, true);// 获取总数量
		if (authorityModelDriven.getPageNo() != null
				&& !authorityModelDriven.getPageNo().equals("")) {
			authority_Page.setPageNo(Integer.parseInt(authorityModelDriven
					.getPageNo()));// 设置当前页码
		}
		String hql = "from Authority a order by a.authorityId "
				+ authorityModelDriven.getSort();
		authorityDao.findAll(authority_Page, hql, null, true);
		return authority_Page;
	}

	/**
	 * 获取所有菜单项
	 */
	@Override
	public List<Menu> getMenus() {
		return menuDao.findAll("from Menu menu order by menu.createTime desc",
				null, true);
	}

	/**
	 * 获取AuthorityList
	 */
	@Override
	public List<Authority> getAuthorityList(
			AuthorityModelDriven authorityModelDriven) {
		List<Authority> authorityList = new ArrayList<Authority>();
		String[] authorityId = authorityModelDriven.getAuthorityId().split(",");// 拆分authorityID
		Map<String, Object> params = new HashMap<String, Object>(1);
		for (int i = 0; i < authorityId.length; i++) {
			params.put("id", Integer.parseInt(authorityId[i]));
			String hql = "from Authority a where a.authorityId=:id";
			authorityList.add(authorityDao.get(hql, params, true));
		}
		return authorityList;
	}

	/**
	 * 关联
	 */
	@Override
	public int updateRelevance(AuthorityModelDriven authorityModelDriven) {
		int success_Authority = 0;// 记录成功数量
		Map<String, Object> params = new HashMap<String, Object>(1);// 设置参数
		params.put("menuId", Integer.parseInt(authorityModelDriven.getMenuId()));
		Menu menu = menuDao.get("from Menu menu where menu.menuId=:menuId",
				params, true);// 查找menu
		params.remove("menuId");// 移除menuId参数
		String[] authorityId = authorityModelDriven.getAuthorityId().split(",");// 分割权限id
		for (int i = 0; i < authorityId.length; i++) {
			params.put("id", Integer.parseInt(authorityId[i].trim()));// 查找authority
			String hql = "from Authority a where a.authorityId=:id";
			Authority authority = authorityDao.get(hql, params, true);
			if (authority.getIsMenu() == true) {// 设置关联
				authority.setMenu(menu);
				authorityDao.update(authority, true);
				success_Authority++;
			}
		}
		return success_Authority;
	}

	/**
	 * 二级菜单
	 */
	@Override
	public Page<Authority> searchSecondMenu(String forwordName,
			AuthorityModelDriven authorityModelDriven) {
		Page<Authority> authority_Page = new Page<Authority>(25, forwordName,
				authorityModelDriven.getSort());// 初始化分页
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("menuId", Integer.parseInt(authorityModelDriven.getMenuId()));
		Menu menu = menuDao.get("from Menu m where m.menuId=:menuId", params,
				true);
		params.remove("menuId");// 删除menu参数
		params.put("menu", menu);// 重写封装menu对象参数
		authorityDao.count(authority_Page,
				"select count(*) from Authority a where a.menu=:menu", params,
				true);// 获取总数量
		if (authorityModelDriven.getPageNo() != null
				&& !authorityModelDriven.getPageNo().equals("")) {
			authority_Page.setPageNo(Integer.parseInt(authorityModelDriven
					.getPageNo()));// 设置当前页码
		}
		String hql = "from Authority a where a.menu=:menu order by a.authorityId "
				+ authorityModelDriven.getSort();
		authorityDao.findAll(authority_Page, hql, params, true);
		return authority_Page;
	}

	/**
	 * 获取所有权限
	 */
	@Override
	public List<Authority> findAll() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("status", true);
		return authorityDao.findAll("from Authority a where a.status=:status",
				params, true);
	}

	@Override
	public List<Authority> menuAuthority(Set<Role> roles) {
		

		return null;
	}
}

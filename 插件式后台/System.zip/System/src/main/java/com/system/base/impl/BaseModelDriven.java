package com.system.base.impl;

/**
 * 
 * @classDescription:通用的模型驱动参数
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: BaseModelDriven.java
 */
public class BaseModelDriven {
	private boolean page=true;// 是否分页标签
	private String sort="desc";// 排序
	private String pageNo;// 分页
	private String success;// 成功信息
	private String error;// 失败信息
	private String message;// 普通信息提示

	public boolean isPage() {
		return page;
	}

	public void setPage(boolean page) {
		this.page = page;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getPageNo() {
		return pageNo;
	}

	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}

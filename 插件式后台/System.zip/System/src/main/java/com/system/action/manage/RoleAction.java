package com.system.action.manage;

import java.util.List;
import java.util.Set;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ModelDriven;
import com.system.base.impl.BaseAction;
import com.system.manageModel.Authority;
import com.system.manageModel.Role;
import com.system.manageModelDriven.RoleModelDriven;
import com.system.manageService.IRoleService;
import com.system.util.jsonUtil.Json;

/**
 * 
 * @classDescription:role权限Action
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: RoleAction.java
 */
@Namespace("/manageRole")
@Results({
		@Result(name = "jumpRolePage_SUCCESS", location = "/WEB-INF/manage/role/role.jsp"),
		@Result(name = "success", location = "/WEB-INF/manage/result/success.jsp"),
		@Result(name = "jumpUpdateRole_SUCCESS", location = "/WEB-INF/manage/role/editRole.jsp"),
		@Result(name = "editRoleAuthority", location = "/WEB-INF/manage/role/editRoleAuthority.jsp"),
		@Result(name = "jumpRoleAdmin_SUCCESS", location = "/WEB-INF/manage/role/editRoleAdmin.jsp") })
public class RoleAction extends BaseAction implements
		ModelDriven<RoleModelDriven> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 196695809794122754L;
	RoleModelDriven roleModelDriven = new RoleModelDriven();

	@Autowired
	IRoleService roleService;

	/**
	 * role进入页面
	 * 
	 * @return
	 */
	public String jumpRolePage() {
		this.setRequestAttribute(
				"role_Page",
				roleService.findAll(this.getRoot()
						+ "/manageRole/role!jumpRolePage", roleModelDriven));
		return "jumpRolePage_SUCCESS";
	}

	/**
	 * 检查权限名字是否重复
	 * 
	 * @return
	 */
	public void checkRoleName() {
		Json json = new Json();
		if (roleService.checkRoleName(roleModelDriven)) {
			json.setSuccess(true);
			json.setMsg("校验成功");
		} else {
			json.setSuccess(false);
			json.setMsg("名字已存在");
		}
		this.writeJson(json);
	}

	/**
	 * 查询Role
	 * 
	 * @return
	 */
	public String searchRole() {
		this.setRequestAttribute(
				"role_Page",
				roleService.search(
						this.getRoot() + "/manageRole/role!searchRole?name="
								+ roleModelDriven.getName(), roleModelDriven));
		return "jumpRolePage_SUCCESS";
	}

	/**
	 * 添加role
	 * 
	 * @return
	 */
	public String saveRole() {
		roleService.save(roleModelDriven);
		roleModelDriven.setSuccess("成功添加 " + roleModelDriven.getName() + " 角色");
		return SUCCESS;
	}

	/**
	 * 更新跳转
	 * 
	 * @return
	 */
	public String jumpUpdateRole() {
		Role role = roleService.get(roleModelDriven);
		this.setRequestAttribute("role", role);
		roleModelDriven.setMessage("正在更新 " + role.getName() + " 角色");
		return "jumpUpdateRole_SUCCESS";
	}

	/**
	 * 更新role
	 * 
	 * @return
	 */
	public String updateRole() {
		roleService.update(roleModelDriven);
		roleModelDriven.setSuccess("成功更新 " + roleModelDriven.getName() + " 角色");
		return SUCCESS;
	}

	/**
	 * 删除role
	 * 
	 * @return
	 */
	public String deleteRole() {
		roleService.delete(roleModelDriven);
		roleModelDriven.setSuccess("成功删除");
		return SUCCESS;
	}

	/**
	 * 角色权限跳转
	 * 
	 * @return
	 */
	public String jumpRoleAuthority() {
		Role role = roleService.get(roleModelDriven);
		Set<Authority> roleAuthority = roleService.getAuthorityList(role);
		List<Authority> surplusAuthority = roleService.getSurplusAuthority(roleAuthority);
		roleModelDriven.setMessage("正在更新 "+role.getName()+" 角色权限");
		this.setRequestAttribute("role", role);
		this.setRequestAttribute("roleAuthority", roleAuthority);
		this.setRequestAttribute("surplusAuthority", surplusAuthority);
		
		return "editRoleAuthority";
	}
    /**
     * 关联权限
     * @return
     */
	public String updateRoleAuthority(){
		roleService.updateRoleAuthority(roleModelDriven);
		roleModelDriven.setSuccess("成功更新权限关联");
		return SUCCESS;
	}
	/**
	 * 角色管理员跳转
	 * @return
	 */
	public String jumpRoleAdmin(){
		Role role = roleService.get(roleModelDriven);
		this.setRequestAttribute("role", role);
		this.setRequestAttribute("surplusAdmin",roleService.getSurplusAdmin(role.getAdmins()));
		roleModelDriven.setMessage("正在更新 "+role.getName()+" 角色管理员");
		return "jumpRoleAdmin_SUCCESS";
	}
	/**
	 * 更新角色管理员
	 * @return
	 */
	public String updateRoleAdmin(){
		roleService.updateRoleAdmin(roleModelDriven);
		roleModelDriven.setSuccess("成功更新管理员关联");
		return SUCCESS;
	}
	// ------模型驱动------
	@Override
	public RoleModelDriven getModel() {
		return roleModelDriven;
	}

}

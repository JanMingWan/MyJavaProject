package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsVerification entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_verification", catalog = "wslm")
public class WsVerification implements java.io.Serializable {

	// Fields

	private Integer verId;
	private Integer userId;
	private String verEmail;
	private String verCode;
	private Integer verTime;
	private Boolean verType;
	private String bindEmail;

	// Constructors

	/** default constructor */
	public WsVerification() {
	}

	/** minimal constructor */
	public WsVerification(Integer userId, String verEmail, String verCode,
			Integer verTime, Boolean verType) {
		this.userId = userId;
		this.verEmail = verEmail;
		this.verCode = verCode;
		this.verTime = verTime;
		this.verType = verType;
	}

	/** full constructor */
	public WsVerification(Integer userId, String verEmail, String verCode,
			Integer verTime, Boolean verType, String bindEmail) {
		this.userId = userId;
		this.verEmail = verEmail;
		this.verCode = verCode;
		this.verTime = verTime;
		this.verType = verType;
		this.bindEmail = bindEmail;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ver_id", unique = true, nullable = false)
	public Integer getVerId() {
		return this.verId;
	}

	public void setVerId(Integer verId) {
		this.verId = verId;
	}

	@Column(name = "user_id", nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "ver_email", nullable = false, length = 60)
	public String getVerEmail() {
		return this.verEmail;
	}

	public void setVerEmail(String verEmail) {
		this.verEmail = verEmail;
	}

	@Column(name = "ver_code", nullable = false, length = 45)
	public String getVerCode() {
		return this.verCode;
	}

	public void setVerCode(String verCode) {
		this.verCode = verCode;
	}

	@Column(name = "ver_time", nullable = false)
	public Integer getVerTime() {
		return this.verTime;
	}

	public void setVerTime(Integer verTime) {
		this.verTime = verTime;
	}

	@Column(name = "ver_type", nullable = false)
	public Boolean getVerType() {
		return this.verType;
	}

	public void setVerType(Boolean verType) {
		this.verType = verType;
	}

	@Column(name = "bind_email", length = 60)
	public String getBindEmail() {
		return this.bindEmail;
	}

	public void setBindEmail(String bindEmail) {
		this.bindEmail = bindEmail;
	}

}
package com.system.util.comparator;

import java.util.Comparator;

import com.system.manageModel.Authority;

/**
 * 
 * @classDescription:顶级目录排序
 * @author: 王嘉明
 * @cerateTime: 2013-12-11
 * @className: ComparatorMenu.java
 */
public class ComparatorSecondMenu implements Comparator<Authority> {

	@Override
	public int compare(Authority o1, Authority o2) {
		Authority fristAuthority = o1;
		Authority secondAuthority = o2;
		return fristAuthority.getAuthorityId() - secondAuthority.getAuthorityId();
	}

}

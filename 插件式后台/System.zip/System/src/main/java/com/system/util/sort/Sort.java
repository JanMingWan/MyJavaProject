package com.system.util.sort;

import java.util.Comparator;

import com.system.manageModel.Authority;
import com.system.manageModel.Menu;

/**
 * 
 * @classDescription:排序判断工具类
 * @author: 王嘉明
 * @cerateTime: 2013-11-30
 * @className: Sort.java
 */
public class Sort implements Comparator<Object> {
	/**
	 * 返回相反的排序
	 * 
	 * @param sortType
	 *            排序方式
	 * @return desc降序 asc升序
	 */
	public static String sort(String sortType) {
		if (sortType != null && !sortType.equals("")) {// 判断是否为空
			if (sortType.equals("desc")) {
				return "asc";
			} else {
				return "desc";
			}
		} else {
			return "desc";
		}
	}

	/**
	 * 顶级菜单Set排序
	 */
	@Override
	public int compare(Object o1, Object o2) {
		Menu fristMenu = (Menu) o1;
		Menu secondMenu = (Menu) o2;
		return fristMenu.getMenuId() - secondMenu.getMenuId();
	}
	
    /**
     * 2级菜单排序
     * @param o1
     * @param o2
     * @return
     */
	public int comparaSecondMenu(Object o1, Object o2) {
		Authority fristAuthority = (Authority) o1;
		Authority secondAuthority = (Authority) o2;
		return fristAuthority.getAuthorityId()
				- secondAuthority.getAuthorityId();
	}
}

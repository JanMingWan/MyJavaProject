package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * WsUser entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_user", catalog = "wslm", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class WsUser implements java.io.Serializable {

	// Fields

	private Integer userId;
	private String email;
	private String phone;
	private String wsNum;
	private String realName;
	private Boolean sex;
	private Integer job;
	private Integer birthday;
	private String password;
	private String nickName;
	private String qq;
	private Integer provinceId;
	private String province;
	private Integer cityId;
	private String city;
	private String school;
	private String idCard;
	private String headImage;
	private Integer integral;
	private String lastIp;
	private Integer lastLogin;
	private Integer visitCount;
	private Integer registerTime;
	private Integer onlineTime;
	private String intro;
	private Integer rank;
	private Integer isMessage;
	private Integer isVip;
	private Integer vipDeadline;
	private String address;
	private Integer areaId;
	private String area;
	private Integer score;

	// Constructors

	/** default constructor */
	public WsUser() {
	}

	/** minimal constructor */
	public WsUser(String wsNum, Boolean sex, String password, Integer integral,
			Integer visitCount, Integer rank, Integer isMessage, Integer isVip,
			Integer score) {
		this.wsNum = wsNum;
		this.sex = sex;
		this.password = password;
		this.integral = integral;
		this.visitCount = visitCount;
		this.rank = rank;
		this.isMessage = isMessage;
		this.isVip = isVip;
		this.score = score;
	}

	/** full constructor */
	public WsUser(String email, String phone, String wsNum, String realName,
			Boolean sex, Integer job, Integer birthday, String password,
			String nickName, String qq, Integer provinceId, String province,
			Integer cityId, String city, String school, String idCard,
			String headImage, Integer integral, String lastIp,
			Integer lastLogin, Integer visitCount, Integer registerTime,
			Integer onlineTime, String intro, Integer rank, Integer isMessage,
			Integer isVip, Integer vipDeadline, String address, Integer areaId,
			String area, Integer score) {
		this.email = email;
		this.phone = phone;
		this.wsNum = wsNum;
		this.realName = realName;
		this.sex = sex;
		this.job = job;
		this.birthday = birthday;
		this.password = password;
		this.nickName = nickName;
		this.qq = qq;
		this.provinceId = provinceId;
		this.province = province;
		this.cityId = cityId;
		this.city = city;
		this.school = school;
		this.idCard = idCard;
		this.headImage = headImage;
		this.integral = integral;
		this.lastIp = lastIp;
		this.lastLogin = lastLogin;
		this.visitCount = visitCount;
		this.registerTime = registerTime;
		this.onlineTime = onlineTime;
		this.intro = intro;
		this.rank = rank;
		this.isMessage = isMessage;
		this.isVip = isVip;
		this.vipDeadline = vipDeadline;
		this.address = address;
		this.areaId = areaId;
		this.area = area;
		this.score = score;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "user_id", unique = true, nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "email", unique = true, length = 60)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "phone", length = 11)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "ws_num", nullable = false, length = 11)
	public String getWsNum() {
		return this.wsNum;
	}

	public void setWsNum(String wsNum) {
		this.wsNum = wsNum;
	}

	@Column(name = "real_name", length = 20)
	public String getRealName() {
		return this.realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	@Column(name = "sex", nullable = false)
	public Boolean getSex() {
		return this.sex;
	}

	public void setSex(Boolean sex) {
		this.sex = sex;
	}

	@Column(name = "job")
	public Integer getJob() {
		return this.job;
	}

	public void setJob(Integer job) {
		this.job = job;
	}

	@Column(name = "birthday")
	public Integer getBirthday() {
		return this.birthday;
	}

	public void setBirthday(Integer birthday) {
		this.birthday = birthday;
	}

	@Column(name = "password", nullable = false, length = 32)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "nick_name", length = 20)
	public String getNickName() {
		return this.nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	@Column(name = "qq", length = 20)
	public String getQq() {
		return this.qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	@Column(name = "province_id")
	public Integer getProvinceId() {
		return this.provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	@Column(name = "province", length = 20)
	public String getProvince() {
		return this.province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	@Column(name = "city_id")
	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	@Column(name = "city", length = 20)
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "school", length = 100)
	public String getSchool() {
		return this.school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	@Column(name = "id_card", length = 18)
	public String getIdCard() {
		return this.idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	@Column(name = "head_image", length = 100)
	public String getHeadImage() {
		return this.headImage;
	}

	public void setHeadImage(String headImage) {
		this.headImage = headImage;
	}

	@Column(name = "integral", nullable = false)
	public Integer getIntegral() {
		return this.integral;
	}

	public void setIntegral(Integer integral) {
		this.integral = integral;
	}

	@Column(name = "last_ip", length = 15)
	public String getLastIp() {
		return this.lastIp;
	}

	public void setLastIp(String lastIp) {
		this.lastIp = lastIp;
	}

	@Column(name = "last_login")
	public Integer getLastLogin() {
		return this.lastLogin;
	}

	public void setLastLogin(Integer lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Column(name = "visit_count", nullable = false)
	public Integer getVisitCount() {
		return this.visitCount;
	}

	public void setVisitCount(Integer visitCount) {
		this.visitCount = visitCount;
	}

	@Column(name = "register_time")
	public Integer getRegisterTime() {
		return this.registerTime;
	}

	public void setRegisterTime(Integer registerTime) {
		this.registerTime = registerTime;
	}

	@Column(name = "online_time")
	public Integer getOnlineTime() {
		return this.onlineTime;
	}

	public void setOnlineTime(Integer onlineTime) {
		this.onlineTime = onlineTime;
	}

	@Column(name = "intro", length = 100)
	public String getIntro() {
		return this.intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	@Column(name = "rank", nullable = false)
	public Integer getRank() {
		return this.rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Column(name = "is_message", nullable = false)
	public Integer getIsMessage() {
		return this.isMessage;
	}

	public void setIsMessage(Integer isMessage) {
		this.isMessage = isMessage;
	}

	@Column(name = "is_vip", nullable = false)
	public Integer getIsVip() {
		return this.isVip;
	}

	public void setIsVip(Integer isVip) {
		this.isVip = isVip;
	}

	@Column(name = "vip_deadline")
	public Integer getVipDeadline() {
		return this.vipDeadline;
	}

	public void setVipDeadline(Integer vipDeadline) {
		this.vipDeadline = vipDeadline;
	}

	@Column(name = "address", length = 100)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "area_id")
	public Integer getAreaId() {
		return this.areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}

	@Column(name = "area", length = 20)
	public String getArea() {
		return this.area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@Column(name = "score", nullable = false)
	public Integer getScore() {
		return this.score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

}
package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsNum entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_num", catalog = "wslm")
public class WsNum implements java.io.Serializable {

	// Fields

	private Integer wsId;
	private String wsNum;
	private Boolean useable;
	private Boolean isBeauty;

	// Constructors

	/** default constructor */
	public WsNum() {
	}

	/** full constructor */
	public WsNum(String wsNum, Boolean useable, Boolean isBeauty) {
		this.wsNum = wsNum;
		this.useable = useable;
		this.isBeauty = isBeauty;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ws_id", unique = true, nullable = false)
	public Integer getWsId() {
		return this.wsId;
	}

	public void setWsId(Integer wsId) {
		this.wsId = wsId;
	}

	@Column(name = "ws_num", nullable = false, length = 11)
	public String getWsNum() {
		return this.wsNum;
	}

	public void setWsNum(String wsNum) {
		this.wsNum = wsNum;
	}

	@Column(name = "useable", nullable = false)
	public Boolean getUseable() {
		return this.useable;
	}

	public void setUseable(Boolean useable) {
		this.useable = useable;
	}

	@Column(name = "is_beauty", nullable = false)
	public Boolean getIsBeauty() {
		return this.isBeauty;
	}

	public void setIsBeauty(Boolean isBeauty) {
		this.isBeauty = isBeauty;
	}

}
package com.system.base.impl;

import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.system.base.IBaseDao;
import com.system.util.page.Page;

/**
 * 后台BaseDao实现类
 * 
 * @author 王嘉明
 * @createTime:2013/11/18
 * @param <T>
 */
public class BaseDaoImpl<T> implements IBaseDao<T> {
	/**
	 * 后台sessionFactory
	 */
	@Resource(name = "sessionFactoryManage")
	protected SessionFactory sessionFactoryManage;

	@Resource(name = "sessionFactoryFront")
	protected SessionFactory sessionFactoryFront;

	/**
	 * 简化返回session
	 * 
	 * @param type
	 *            false为前台数据库session true为后台数据库session
	 * @return
	 */
	private Session getCurrentSession(boolean type) {
		if (type) {
			return this.sessionFactoryManage.getCurrentSession();
		} else {
			return this.sessionFactoryFront.getCurrentSession();
		}
	}
    /**
     * 保存
     */
	@Override
	public void save(T object, boolean type) {
		// TODO Auto-generated method stub
		this.getCurrentSession(type).save(object);
	}
    /**
     * 删除
     */
	@Override
	public void delete(T object, boolean type) {
		// TODO Auto-generated method stub
		this.getCurrentSession(type).delete(object);
	}
    /**
     * 更新
     */
	@Override
	public void update(T object, boolean type) {
		// TODO Auto-generated method stub
		this.getCurrentSession(type).update(object);
	}
    /**
     * 获取一个对象
     */
	@Override
	public T get(String hql, Map<String, Object> params, boolean type) {
		// 设置查询
		Query query = this.getCurrentSession(type).createQuery(hql);
		if (params != null && !params.isEmpty()) {// 判断参数是否存在
			for (String key : params.keySet()) {// 循环参数
				query.setParameter(key, params.get(key));// 替换占位符
			}
		}
		@SuppressWarnings("unchecked")
		List<T> list = query.list();
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}
    /**
     * 保存或更新
     */
	@Override
	public void saveOrUpdate(T object, boolean type) {
		this.getCurrentSession(type).saveOrUpdate(object);
	}
    /**
     * 查找
     */
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findAll(String hql, Map<String, Object> params, boolean type) {
		// 设置查询
		Query query = this.getCurrentSession(type).createQuery(hql);
		if (params != null && !params.isEmpty()) {// 判断参数是否存在
			for (String key : params.keySet()) {// 循环参数
				query.setParameter(key, params.get(key));// 替换占位符
			}
		}
		return query.list();
	}
    /**
     * 带分页查找
     */
	@SuppressWarnings("unchecked")
	@Override
	public Page<T> findAll(Page<T> page, String hql,
			Map<String, Object> params, boolean type) {
		Query query = this.getCurrentSession(type).createQuery(hql);
		if (params != null && !params.isEmpty()) {
			for (String key : params.keySet()) {
				query.setParameter(key, params.get(key));
			}
		}
		page.setResult(query
				.setFirstResult((page.getPageNo() - 1) * page.getPageSize())
				.setMaxResults(page.getPageSize()).list());

		return page;
	}
    /**
     * 获取查找数量
     */
	@Override
	public void count(Page<T> page, String hql, Map<String, Object> params,
			boolean type) {
		// TODO Auto-generated method stub
		Query query = this.getCurrentSession(type).createQuery(hql);
		if (params != null && !params.isEmpty()) {
			for (String key : params.keySet()) {
				query.setParameter(key, params.get(key));
			}
		}
		page.setTotalCount((Long) query.uniqueResult());// 设置分页总记录数
	}
}

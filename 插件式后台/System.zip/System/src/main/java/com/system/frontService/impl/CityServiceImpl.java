package com.system.frontService.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.frontDao.ICityDao;
import com.system.frontModel.WsCity;
import com.system.frontModelDriven.CityModelDriven;
import com.system.frontService.ICityService;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:城市业务接口实现类
 * @author: 王嘉明
 * @cerateTime: 2013-12-5
 * @className: CityServiceImpl.java
 */
@Service
public class CityServiceImpl implements ICityService {
	@Autowired
	ICityDao cityDao;
    /**
     * 添加保存
     */
	@Override
	public void save(CityModelDriven object) {

	}
    /**
     * 删除
     */
	@Override
	public void delete(CityModelDriven object) {

	}
    /**
     * 更新
     */
	@Override
	public void update(CityModelDriven object) {

	}
    /**
     * 获取一个city对象
     */
	@Override
	public WsCity get(CityModelDriven cityModelDriven) {
		Map<String,Object>params=new HashMap<String, Object>(1);
		params.put("id", cityModelDriven.getCityId());
		String hql="from WsCity city where city.cityId=:id";
		WsCity city=cityDao.get(hql, params, false);
		return city;
	}
    /**
     * 获取所有city
     */
	@Override
	public Page<WsCity> findAll(String forwordName, CityModelDriven object) {
		return null;
	}
    /**
     * 查找
     */
	@Override
	public Page<WsCity> search(String forwordName, CityModelDriven object) {
		return null;
	}
	/**
	 * 获取激活的城市，list集合
	 */
	@Override
	public List<WsCity> allCity() {
		return cityDao.findAll("from WsCity city where city.useable=true", null, false);
	}

}

package com.system.util.date;

import java.util.Date;

/**
 * 
 * @classDescription:时间工具类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: DateUtil.java
 */
public class DateUtil {
	/**
	 * 获取时间戳
	 * 
	 * @return
	 */
	public static long getTime() {
		return new Date().getTime();
	}
}

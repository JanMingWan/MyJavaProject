package com.system.manageDao;

import com.system.base.IBaseDao;
import com.system.manageModel.Menu;

/**
 * 
 * @classDescription:菜单数据访问层接口
 * @author: 王嘉明
 * @cerateTime: 2013-11-26
 * @className: IMenuDao.java
 */
public interface IMenuDao extends IBaseDao<Menu> {

}

package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsProvince entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_province", catalog = "wslm")
public class WsProvince implements java.io.Serializable {

	// Fields

	private Integer provinceId;
	private String province;
	private Boolean useable;

	// Constructors

	/** default constructor */
	public WsProvince() {
	}

	/** full constructor */
	public WsProvince(Integer provinceId, String province, Boolean useable) {
		this.provinceId = provinceId;
		this.province = province;
		this.useable = useable;
	}

	// Property accessors
	@Id
	@Column(name = "province_id", unique = true, nullable = false)
	public Integer getProvinceId() {
		return this.provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	@Column(name = "province", nullable = false, length = 50)
	public String getProvince() {
		return this.province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	@Column(name = "useable", nullable = false)
	public Boolean getUseable() {
		return this.useable;
	}

	public void setUseable(Boolean useable) {
		this.useable = useable;
	}

}
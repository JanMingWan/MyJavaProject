package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsAlbum entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_album", catalog = "wslm")
public class WsAlbum implements java.io.Serializable {

	// Fields

	private Integer albumId;
	private Integer shopId;
	private String albumNane;
	private Integer createTime;

	// Constructors

	/** default constructor */
	public WsAlbum() {
	}

	/** full constructor */
	public WsAlbum(Integer shopId, String albumNane, Integer createTime) {
		this.shopId = shopId;
		this.albumNane = albumNane;
		this.createTime = createTime;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "album_id", unique = true, nullable = false)
	public Integer getAlbumId() {
		return this.albumId;
	}

	public void setAlbumId(Integer albumId) {
		this.albumId = albumId;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "album_nane", nullable = false, length = 45)
	public String getAlbumNane() {
		return this.albumNane;
	}

	public void setAlbumNane(String albumNane) {
		this.albumNane = albumNane;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

}
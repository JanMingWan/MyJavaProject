package com.system.frontDao;

import com.system.base.IBaseDao;
import com.system.frontModel.WsCity;
/**
 * 
 * @classDescription:城市数据访问层接口
 * @author: 王嘉明
 * @cerateTime: 2013-12-5
 * @className: ICityDao.java
 */
public interface ICityDao extends IBaseDao<WsCity>{

}

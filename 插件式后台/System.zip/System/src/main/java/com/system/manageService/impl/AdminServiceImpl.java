package com.system.manageService.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.client.ClientProtocolException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.manageDao.IAdminDao;
import com.system.manageDao.IRoleDao;
import com.system.manageModel.Admin;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModel.Role;
import com.system.manageModelDriven.AdminModelDriven;
import com.system.manageService.IAdminService;
import com.system.util.comparator.ComparatorMenu;
import com.system.util.comparator.ComparatorSecondMenu;
import com.system.util.date.DateUtil;
import com.system.util.ehcache.cacheModel.AdminMenuCacheModel;
import com.system.util.encryption.Encryption;
import com.system.util.ipAddress.IpAddress;
import com.system.util.page.Page;

/**
 * AdminServiceDao实现类
 * 
 * @author 王嘉明
 * @createTime 2013/11/22
 */
@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao adminDao;

	@Autowired
	IRoleDao roleDao;

	/**
	 * 登录
	 */
	@Override
	public Admin login(AdminModelDriven adminModelDriven, String login_IP) {
		Map<String, Object> params = new HashMap<String, Object>();// 参数封装
		params.put("name", adminModelDriven.getName());
		Admin admin = adminDao.get("from Admin admin where admin.name=:name",
				params, true);// 账号查询
		// ----判断admin是否为空
		if (admin != null) {
			// ----
			boolean checkPassword = Encryption.checkPassword(
					admin.getPassword(), adminModelDriven.getPassword(),
					String.valueOf(admin.getCreateTime()));// 密码校验
			if (checkPassword) {// 判断登录密码是否正确
				try {
					Map<String, String> ipAddress = IpAddress
							.checkIpAddress(login_IP);// 获取ip Map
					for (String key : ipAddress.keySet()) {
						if (key.equals("region")) {
							admin.setLastLoginArea(ipAddress.get(key));// 地区
						} else if (key.equals("city")) {
							admin.setLastLoginCity(ipAddress.get(key));// 城市
						} else if (key.equals("country")) {
							admin.setLastLoginCounty(ipAddress.get(key));// 国家
						} else {
							admin.setLastLoginIsp(ipAddress.get(key));// 运营商
						}
					}
					admin.setLastTime(DateUtil.getTime());
					adminDao.update(admin, true);
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

				return admin;// 成功返回admin对象
			} else {
				return null;// 失败返回null
			}
		} else {
			return null;// 查找不到用户
		}

	}

	/**
	 * 添加管理员用户
	 */
	@Override
	public void save(AdminModelDriven adminModelDriven) {
		Admin admin = new Admin();
		BeanUtils.copyProperties(adminModelDriven, admin,
				new String[] { "manageCity" });// 复制参数
		Long time = DateUtil.getTime();// 创建时间
		admin.setCreateTime(time);
		admin.setModificationTime(time);
		admin.setPassword(Encryption.MD5Encryption("ws123456789lm",
				String.valueOf(time)));// 加密密码
		if (adminModelDriven.getType() == 2) {
			admin.setManageCity(adminModelDriven.getManageCity());
		}
		admin.setStatus(true);
		adminDao.save(admin, true);
	}

	/**
	 * 删除管理员
	 */
	@Override
	public void delete(AdminModelDriven adminModelDriven) {
		String[] adminId = adminModelDriven.getAdminId().split(",");// 获取id组
		Map<String, Object> params = new HashMap<String, Object>(1);
		for (int i = 0; i < adminId.length; i++) {
			params.put("id", Long.valueOf((adminId[i])));
			String hql = "from Admin admin where admin.adminId=:id";
			Admin admin = adminDao.get(hql, params, true);
			adminDao.delete(admin, true);
		}
	}

	/**
	 * 更新管理员
	 */
	@Override
	public void update(AdminModelDriven adminModelDriven) {
		Admin admin = get(adminModelDriven);
		admin.setName(adminModelDriven.getName());
		admin.setRealName(adminModelDriven.getRealName());
		admin.setEmail(adminModelDriven.getEmail());
		Long time = DateUtil.getTime();// 创建时间
		admin.setModificationTime(time);
		if (admin.getType() == 2) {
			admin.setManageCity(adminModelDriven.getManageCity());
		}
		adminDao.update(admin, true);
	}

	/**
	 * 获取该管理员
	 */
	@Override
	public Admin get(AdminModelDriven adminModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);// 保存参数
		params.put("id", Long.valueOf(adminModelDriven.getAdminId()));
		String hql = "from Admin admin where admin.adminId=:id";
		return adminDao.get(hql, params, true);
	}

	/**
	 * 查询所有所有管理员
	 */
	@Override
	public Page<Admin> findAll(String forwordName,
			AdminModelDriven adminModelDriven) {
		Page<Admin> admin_Page = new Page<Admin>(25, forwordName,
				adminModelDriven.getSort());// 设置页面
		adminDao.count(admin_Page, "select count(*) from Admin", null, true);// 记录admin数量
		if (adminModelDriven.getPageNo() != null
				&& !adminModelDriven.getPageNo().equals("")) {// 查看有无分页参数传过来
			admin_Page
					.setPageNo(Integer.parseInt(adminModelDriven.getPageNo()));
		}
		String hql = "from Admin admin order by admin.adminId "
				+ adminModelDriven.getSort();
		adminDao.findAll(admin_Page, hql, null, true);
		return admin_Page;
	}

	/**
	 * 搜索
	 * 
	 * @param forwordName
	 * @param adminModelDriven
	 * @return
	 */
	@Override
	public Page<Admin> search(String forwordName,
			AdminModelDriven adminModelDriven) {
		Page<Admin> admin_Page = new Page<Admin>(25, forwordName,
				adminModelDriven.getSort());// 设置分页参数
		if (adminModelDriven.getRealName() != null
				&& !adminModelDriven.getRealName().equals("")) {// 判断搜索内容
			Map<String, Object> params = new HashMap<String, Object>(1);// 设置参数
			params.put("realName", "%" + adminModelDriven.getRealName() + "%");// 模糊查询
			adminDao.count(
					admin_Page,
					"select count(*) from Admin admin where admin.realName like :realName",
					params, true);// 计算数量
			if (adminModelDriven.getPageNo() != null
					&& !adminModelDriven.getPageNo().equals("")) {
				admin_Page.setPageNo(Integer.parseInt(adminModelDriven
						.getPageNo()));
			}
			String hql = "from Admin admin where admin.realName like :realName order by admin.createTime "
					+ adminModelDriven.getSort();
			adminDao.findAll(admin_Page, hql, params, true);
		} else {
			adminDao.count(admin_Page, "select count(*) from Admin", null, true);
			if (adminModelDriven.getPageNo() != null
					&& !adminModelDriven.getPageNo().equals("")) {
				admin_Page.setPageNo(Integer.parseInt(adminModelDriven
						.getPageNo()));
			}
			String hql = "from Admin admin order by admin.createTime "
					+ adminModelDriven.getSort();
			adminDao.findAll(admin_Page, hql, null, true);
		}

		return admin_Page;
	}

	/**
	 * 校验name
	 */
	@Override
	public boolean checkName(AdminModelDriven adminModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("name", adminModelDriven.getName());
		String hql = "from Admin admin where admin.name=:name";
		List<Admin> admins = adminDao.findAll(hql, params, true);
		if (admins.size() > 0)
			return false;
		return true;
	}

	/**
	 * 校验realName
	 */
	@Override
	public boolean checkRealName(AdminModelDriven adminModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("realName", adminModelDriven.getRealName());
		String hql = "from Admin admin where admin.realName=:realName";
		List<Admin> admins = adminDao.findAll(hql, params, true);
		if (admins.size() > 0)
			return false;
		return true;
	}

	/**
	 * 初始化密码
	 */
	@Override
	public void initializePassword(AdminModelDriven adminModelDriven) {
		Admin admin = get(adminModelDriven);// 根据ID获取admin对象
		admin.setPassword(Encryption.MD5Encryption("ws123456789lm",
				String.valueOf(admin.getCreateTime())));
		adminDao.update(admin, true);
	}

	@Override
	public List<Authority> get(Long id) {
		List<Authority> authority = null;
		Map<String, Object> params = new HashMap<String, Object>(1);// 保存参数
		params.put("id", id);
		String hql = "from Admin admin where admin.adminId=:id";
		Admin admin = adminDao.get(hql, params, true);
		if (admin != null) {
			Set<Role> roles = admin.getRoles();
			authority = new LinkedList<Authority>();
			for (Role role : roles) {
				authority.addAll(role.getAuthorities());
			}
		}
		return authority;

	}

	/**
	 * 获取管理员目录
	 */
	@Override
	public AdminMenuCacheModel getMenu(Admin admin) {
		
		Set<Authority> setAuthorities = new HashSet<Authority>();// set集合过滤重复属性
		Set<Menu> setMenu = new HashSet<Menu>();
		for (Role role : admin.getRoles()) {// 循环自身角色提取自己的目录
			for (Authority authority : role.getAuthorities()) {
				if (authority.getIsMenu() == true) {
					setAuthorities.add(authority);
					setMenu.add(authority.getMenu());
				}
			}
		}

		List<Authority> listAuthority = new ArrayList<Authority>(setAuthorities);// 排序好的目录
		List<Menu> listMenu = new ArrayList<Menu>(setMenu);

		AdminMenuCacheModel amcm = new AdminMenuCacheModel();
		ComparatorMenu cMenu = new ComparatorMenu();// 进行排序
		ComparatorSecondMenu csMenu = new ComparatorSecondMenu();
		Collections.sort(listMenu, cMenu);
		Collections.sort(listAuthority, csMenu);

		amcm.setMenu(listMenu);// 排序完
		amcm.setAuthority(listAuthority);

		return amcm;
	}
}

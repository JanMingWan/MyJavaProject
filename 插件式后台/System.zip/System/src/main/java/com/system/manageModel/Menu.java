package com.system.manageModel;

// default package

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @classDescription:菜单类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: Menu.java
 */
@Entity
@Table(name = "wslm_menu", catalog = "wslm_manage")
public class Menu implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -3273835781264427639L;
	private Integer menuId;// id
	private Long createTime;// 创建时间
	private Long modificationTime;//最后修改时间
	private String name;// 菜单名
	
	private Set<Authority> authorities = new HashSet<Authority>(0);

	// Constructors

	/** default constructor */
	public Menu() {
	}

	/** minimal constructor */
	public Menu(Integer menuId, Long createTime, String name) {
		this.menuId = menuId;
		this.createTime = createTime;
		this.name = name;
	}

	/** full constructor */
	public Menu(Integer menuId, Long createTime, String name,
			Set<Authority> authorities) {
		this.menuId = menuId;
		this.createTime = createTime;
		this.name = name;
		this.authorities = authorities;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "menu_id", unique = true, nullable = false)
	public Integer getMenuId() {
		return this.menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	@Column(name = "createTime", nullable = false, length = 50)
	public Long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}
	@Column(name = "modificationTime", length = 50)
	public Long getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(Long modificationTime) {
		this.modificationTime = modificationTime;
	}

	@Column(name = "name", nullable = false, length = 50)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "menu")
	public Set<Authority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Set<Authority> authorities) {
		this.authorities = authorities;
	}

}
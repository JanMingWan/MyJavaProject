package com.system.frontModelDriven;

import com.system.base.impl.BaseModelDriven;

/**
 * 
 * @classDescription:前端城市模型驱动
 * @author: 王嘉明
 * @cerateTime: 2013-12-5
 * @className: CityModelDriven.java
 */
public class CityModelDriven extends BaseModelDriven {
	private Integer cityId;
	private String city;
	private Integer provinceId;
	private Boolean useable;

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public Boolean getUseable() {
		return useable;
	}

	public void setUseable(Boolean useable) {
		this.useable = useable;
	}

}

package com.system.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.system.manageModel.Authority;

/**
 * 
 * @classDescription:安全拦截器接口
 * @author: 王嘉明
 * @cerateTime: 2013-12-7
 * @className: ISercurityFilter.java
 */
public interface ISercurityFilter {

	/**
	 * 不需要校验的方法
	 * 
	 * @param httpRequest
	 * @return
	 */
	public boolean skipMethod(String url);

	/**
	 * 重定向登录方法
	 * 
	 * @param httpRequest
	 */
	public void redirectLogin(ServletRequest request,ServletResponse response);

	/**
	 * 管理员权限判断
	 * 
	 * @param request
	 * @param response
	 * @param chain
	 * @param authority
	 */
	public void doAdminAuthorities(ServletRequest request,ServletResponse response, FilterChain chain, Authority authority)throws IOException, ServletException;
	
}

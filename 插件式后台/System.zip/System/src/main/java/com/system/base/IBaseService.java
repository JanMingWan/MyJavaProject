package com.system.base;

import com.system.util.page.Page;

/**
 * 
 * @classDescription:通用业务接口 规范所有基础业务的命名 所有业务接口都要继承该接口
 * @author: 王嘉明
 * @cerateTime: 2013-12-1
 * @className: IBaseService.java
 * @param <T> model对象
 * @param <T1> 模型驱动
 */
public interface IBaseService<T, T1> {
	/**
	 * 添加业务
	 * 
	 * @param object
	 */
	public void save(T1 object);

	/**
	 * 删除业务
	 * 
	 * @param object
	 */
	public void delete(T1 object);

	/**
	 * 更新业务
	 * 
	 * @param object
	 */
	public void update(T1 object);

	/**
	 * 查询业务
	 * 
	 * @param object
	 * @return
	 */
	public T get(T1 object);

	/**
	 * 分页查询所有
	 * 
	 * @param forwordName
	 * @param object
	 * @return
	 */
	public Page<T> findAll(String forwordName, T1 object);

	/**
	 * 搜索
	 * @param forwordName
	 * @param object
	 * @return
	 */
	public Page<T> search(String forwordName, T1 object);
}

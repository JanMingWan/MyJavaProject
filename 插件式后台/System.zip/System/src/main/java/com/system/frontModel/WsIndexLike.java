package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsIndexLike entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_index_like", catalog = "wslm")
public class WsIndexLike implements java.io.Serializable {

	// Fields

	private Integer indexLikeId;
	private String likeName;
	private Double likePrice;
	private String imagePath;
	private String url;
	private String sn;

	// Constructors

	/** default constructor */
	public WsIndexLike() {
	}

	/** full constructor */
	public WsIndexLike(String likeName, Double likePrice, String imagePath,
			String url, String sn) {
		this.likeName = likeName;
		this.likePrice = likePrice;
		this.imagePath = imagePath;
		this.url = url;
		this.sn = sn;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "index_like_id", unique = true, nullable = false)
	public Integer getIndexLikeId() {
		return this.indexLikeId;
	}

	public void setIndexLikeId(Integer indexLikeId) {
		this.indexLikeId = indexLikeId;
	}

	@Column(name = "like_name", nullable = false, length = 30)
	public String getLikeName() {
		return this.likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	@Column(name = "like_price", nullable = false, precision = 10)
	public Double getLikePrice() {
		return this.likePrice;
	}

	public void setLikePrice(Double likePrice) {
		this.likePrice = likePrice;
	}

	@Column(name = "image_path", nullable = false, length = 100)
	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Column(name = "url", nullable = false, length = 100)
	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "sn", nullable = false, length = 10)
	public String getSn() {
		return this.sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

}
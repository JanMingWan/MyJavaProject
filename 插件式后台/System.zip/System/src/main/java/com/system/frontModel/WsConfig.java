package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsConfig entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_config", catalog = "wslm")
public class WsConfig implements java.io.Serializable {

	// Fields

	private Integer configId;
	private Integer pid;
	private String code;
	private String description;
	private String value;
	private String type;
	private Integer sort;

	// Constructors

	/** default constructor */
	public WsConfig() {
	}

	/** minimal constructor */
	public WsConfig(Integer pid, String code) {
		this.pid = pid;
		this.code = code;
	}

	/** full constructor */
	public WsConfig(Integer pid, String code, String description, String value,
			String type, Integer sort) {
		this.pid = pid;
		this.code = code;
		this.description = description;
		this.value = value;
		this.type = type;
		this.sort = sort;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "config_id", unique = true, nullable = false)
	public Integer getConfigId() {
		return this.configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	@Column(name = "pid", nullable = false)
	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	@Column(name = "code", nullable = false, length = 100)
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Column(name = "description", length = 100)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "value", length = 100)
	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Column(name = "type", length = 100)
	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name = "sort")
	public Integer getSort() {
		return this.sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

}
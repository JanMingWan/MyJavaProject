package com.system.util.comparator;

import java.util.Comparator;

import com.system.manageModel.Menu;

/**
 * 
 * @classDescription:顶级目录排序
 * @author: 王嘉明
 * @cerateTime: 2013-12-11
 * @className: ComparatorMenu.java
 */
public class ComparatorMenu implements Comparator<Menu> {

	@Override
	public int compare(Menu o1, Menu o2) {
		Menu fristMenu = o1;
		Menu secondMenu = o2;
		return fristMenu.getMenuId() - secondMenu.getMenuId();
	}

}

package com.system.manageDao.impl;

import org.springframework.stereotype.Repository;

import com.system.base.impl.BaseDaoImpl;
import com.system.manageDao.IRoleDao;
import com.system.manageModel.Role;
/**
 * 
 * @classDescription:权限Dao实现类
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: RoleDaoImp.java
 */
@Repository
public class RoleDaoImp extends BaseDaoImpl<Role> implements IRoleDao {

	
}

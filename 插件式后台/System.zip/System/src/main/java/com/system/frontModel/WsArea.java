package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsArea entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_area", catalog = "wslm")
public class WsArea implements java.io.Serializable {

	// Fields

	private Integer areaId;
	private String area;
	private Integer cityId;

	// Constructors

	/** default constructor */
	public WsArea() {
	}

	/** full constructor */
	public WsArea(Integer areaId, String area, Integer cityId) {
		this.areaId = areaId;
		this.area = area;
		this.cityId = cityId;
	}

	// Property accessors
	@Id
	@Column(name = "area_id", unique = true, nullable = false)
	public Integer getAreaId() {
		return this.areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}

	@Column(name = "area", nullable = false, length = 50)
	public String getArea() {
		return this.area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@Column(name = "city_id", nullable = false)
	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

}
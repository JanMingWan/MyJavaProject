package com.system.manageDao;

import com.system.base.IBaseDao;
import com.system.manageModel.Role;
/**
 * 
 * @classDescription:权限RoleDao
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: IRoleDao.java
 */
public interface IRoleDao extends IBaseDao<Role> {

}

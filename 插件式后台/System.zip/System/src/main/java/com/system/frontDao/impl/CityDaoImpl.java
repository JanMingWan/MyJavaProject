package com.system.frontDao.impl;

import org.springframework.stereotype.Repository;

import com.system.base.impl.BaseDaoImpl;
import com.system.frontDao.ICityDao;
import com.system.frontModel.WsCity;
/**
 * 
 * @classDescription:城市数据访问层接口实现类
 * @author: 王嘉明
 * @cerateTime: 2013-12-5
 * @className: CityImpl.java
 */
@Repository
public class CityDaoImpl extends BaseDaoImpl<WsCity> implements ICityDao {

}

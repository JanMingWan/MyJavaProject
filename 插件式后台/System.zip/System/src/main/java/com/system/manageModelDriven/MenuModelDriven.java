package com.system.manageModelDriven;

import java.io.Serializable;

import com.system.base.impl.BaseModelDriven;

/**
 * 
 * @classDescription:菜单项模型驱动
 * @author: 王嘉明
 * @cerateTime: 2013-11-28
 * @className: MenuModelDriven.java
 */
public class MenuModelDriven extends BaseModelDriven implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5277405513116818492L;
	private String menuId;// id
	private String name;// 菜单名
	private String createTime;// 创建日期

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

}

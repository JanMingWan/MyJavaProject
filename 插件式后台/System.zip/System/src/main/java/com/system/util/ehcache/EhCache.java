package com.system.util.ehcache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * 
 * @classDescription:缓存类
 * @author: 王嘉明
 * @cerateTime: 2013-12-10
 * @className: Ehcache.java
 */
public class EhCache {  
	private static EhCache ehCache;
	private static CacheManager cacheManager;

	private EhCache() {
	}// 私有化构造器

	/**
	 * 静态化ehcahe缓存
	 */
	static void init() {
		if (null == cacheManager) {
			cacheManager=CacheManager.create();
		}
	}

	/**
	 * 获取EhCache单例模式
	 * 
	 * @return
	 */
	public static EhCache getInstance() {
		if (null == ehCache) {
			ehCache = new EhCache();
			init();
		}
		return ehCache;
	}

	/**
	 * 设置缓存
	 * 
	 * @param cacheName 缓存管理器名
	 *            
	 * @param key
	 *            缓存名
	 * @param object
	 *            缓存对象
	 */
	public void setCache(String cacheName,String key, Object object) {
		Cache cache=cacheManager.getCache(cacheName);
		Element element = new Element(key, object);
		cache.put(element);
	}

	/**
	 * 获取缓存
	 * 
	 * @param cacheName
	 *            缓存文件xml名
	 * @param key
	 *            缓存名
	 * @return
	 */
	public Object getCache(String cacheName,String key) {
		Cache cache = cacheManager.getCache(cacheName);
		Element element = cache.get(key);
		if (element != null)
			return element.getObjectValue();
		return null;
	}

	/**
	 * 删除缓存
	 * 
	 * @param cacheName
	 * @param key
	 */
	public void clearCahce(String cacheName, String key) {
		Cache cache = cacheManager.getCache(cacheName);
		cache.remove(key);
	}

}

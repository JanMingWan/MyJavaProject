package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsGoodsSetmeals entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_goods_setmeals", catalog = "wslm")
public class WsGoodsSetmeals implements java.io.Serializable {

	// Fields

	private Integer setmealsId;
	private Integer goodsId;
	private String num;
	private String content;
	private Double price;

	// Constructors

	/** default constructor */
	public WsGoodsSetmeals() {
	}

	/** minimal constructor */
	public WsGoodsSetmeals(Integer goodsId, String num, String content) {
		this.goodsId = goodsId;
		this.num = num;
		this.content = content;
	}

	/** full constructor */
	public WsGoodsSetmeals(Integer goodsId, String num, String content,
			Double price) {
		this.goodsId = goodsId;
		this.num = num;
		this.content = content;
		this.price = price;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "setmeals_id", unique = true, nullable = false)
	public Integer getSetmealsId() {
		return this.setmealsId;
	}

	public void setSetmealsId(Integer setmealsId) {
		this.setmealsId = setmealsId;
	}

	@Column(name = "goods_id", nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "num", nullable = false, length = 11)
	public String getNum() {
		return this.num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	@Column(name = "content", nullable = false, length = 200)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "price", precision = 10)
	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

}
package com.system.frontModel;

// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsOrder entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_order", catalog = "wslm")
public class WsOrder implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -7360904462295647496L;
	private Integer orderId;
	private Integer userId;
	private String orderSn;
	private Integer createTime;
	private Integer payTime;
	private Integer payType;
	private String payTypeName;
	private Integer status;
	private String code;
	private String note;
	private Double orderPrice;
	private Double payPrice;
	private String receivePhone;
	private String shopName;
	private Integer shopId;
	private Integer peopleNum;
	private Integer order_handler;
	private Integer usedTime;
	private String discountContent;
	private String shopNote;
	private Boolean isComment;
	private Boolean isVip;
	private String tradeNo;
	private String tradeStatus;

	// Constructors

	/** default constructor */
	public WsOrder() {
	}

	/** minimal constructor */
	public WsOrder(Integer userId, String orderSn, Integer createTime,
			Integer status, String code, Double orderPrice, Double payPrice,
			String receivePhone, String shopName, Integer shopId,
			Boolean isComment, Boolean isVip) {
		this.userId = userId;
		this.orderSn = orderSn;
		this.createTime = createTime;
		this.status = status;
		this.code = code;
		this.orderPrice = orderPrice;
		this.payPrice = payPrice;
		this.receivePhone = receivePhone;
		this.shopName = shopName;
		this.shopId = shopId;
		this.isComment = isComment;
		this.isVip = isVip;
	}

	/** full constructor */
	public WsOrder(Integer userId, String orderSn, Integer createTime,
			Integer payTime, Integer payType, String payTypeName,
			Integer status, String code, String note, Double orderPrice,
			Double payPrice, String receivePhone, String shopName,
			Integer shopId, Integer peopleNum, Integer order_handler,
			Integer usedTime, String discountContent, String shopNote,
			Boolean isComment, Boolean isVip, String tradeNo, String tradeStatus) {
		this.userId = userId;
		this.orderSn = orderSn;
		this.createTime = createTime;
		this.payTime = payTime;
		this.payType = payType;
		this.payTypeName = payTypeName;
		this.status = status;
		this.code = code;
		this.note = note;
		this.orderPrice = orderPrice;
		this.payPrice = payPrice;
		this.receivePhone = receivePhone;
		this.shopName = shopName;
		this.shopId = shopId;
		this.peopleNum = peopleNum;
		this.order_handler = order_handler;
		this.usedTime = usedTime;
		this.discountContent = discountContent;
		this.shopNote = shopNote;
		this.isComment = isComment;
		this.isVip = isVip;
		this.tradeNo = tradeNo;
		this.tradeStatus = tradeStatus;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "order_id", unique = true, nullable = false)
	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	@Column(name = "user_id", nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "order_sn", nullable = false, length = 45)
	public String getOrderSn() {
		return this.orderSn;
	}

	public void setOrderSn(String orderSn) {
		this.orderSn = orderSn;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

	@Column(name = "pay_time")
	public Integer getPayTime() {
		return this.payTime;
	}

	public void setPayTime(Integer payTime) {
		this.payTime = payTime;
	}

	@Column(name = "pay_type")
	public Integer getPayType() {
		return this.payType;
	}

	public void setPayType(Integer payType) {
		this.payType = payType;
	}

	@Column(name = "pay_type_name", length = 45)
	public String getPayTypeName() {
		return this.payTypeName;
	}

	public void setPayTypeName(String payTypeName) {
		this.payTypeName = payTypeName;
	}

	@Column(name = "status", nullable = false)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "code", nullable = false, length = 45)
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Column(name = "note", length = 200)
	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Column(name = "order_price", nullable = false, precision = 10)
	public Double getOrderPrice() {
		return this.orderPrice;
	}

	public void setOrderPrice(Double orderPrice) {
		this.orderPrice = orderPrice;
	}

	@Column(name = "pay_price", nullable = false, precision = 10)
	public Double getPayPrice() {
		return this.payPrice;
	}

	public void setPayPrice(Double payPrice) {
		this.payPrice = payPrice;
	}

	@Column(name = "receive_phone", nullable = false, length = 11)
	public String getReceivePhone() {
		return this.receivePhone;
	}

	public void setReceivePhone(String receivePhone) {
		this.receivePhone = receivePhone;
	}

	@Column(name = "shop_name", nullable = false, length = 100)
	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "people_num")
	public Integer getPeopleNum() {
		return this.peopleNum;
	}

	public void setPeopleNum(Integer peopleNum) {
		this.peopleNum = peopleNum;
	}

	@Column(name = "handler")
	public Integer getOrder_handler() {
		return order_handler;
	}

	public void setOrder_handler(Integer order_handler) {
		this.order_handler = order_handler;
	}

	@Column(name = "used_time")
	public Integer getUsedTime() {
		return this.usedTime;
	}

	public void setUsedTime(Integer usedTime) {
		this.usedTime = usedTime;
	}

	@Column(name = "discount_content", length = 20)
	public String getDiscountContent() {
		return this.discountContent;
	}

	public void setDiscountContent(String discountContent) {
		this.discountContent = discountContent;
	}

	@Column(name = "shop_note", length = 200)
	public String getShopNote() {
		return this.shopNote;
	}

	public void setShopNote(String shopNote) {
		this.shopNote = shopNote;
	}

	@Column(name = "is_comment", nullable = false)
	public Boolean getIsComment() {
		return this.isComment;
	}

	public void setIsComment(Boolean isComment) {
		this.isComment = isComment;
	}

	@Column(name = "is_vip", nullable = false)
	public Boolean getIsVip() {
		return this.isVip;
	}

	public void setIsVip(Boolean isVip) {
		this.isVip = isVip;
	}

	@Column(name = "trade_no", length = 45)
	public String getTradeNo() {
		return this.tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	@Column(name = "trade_status", length = 45)
	public String getTradeStatus() {
		return this.tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

}
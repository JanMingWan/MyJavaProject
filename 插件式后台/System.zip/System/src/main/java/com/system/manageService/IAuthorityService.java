package com.system.manageService;

import java.util.List;
import java.util.Set;

import com.system.base.IBaseService;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModel.Role;
import com.system.manageModelDriven.AuthorityModelDriven;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:权限&菜单业务层接口
 * @author: 王嘉明
 * @cerateTime: 2013-11-28
 * @className: IAuthorityService.java
 */
public interface IAuthorityService extends
		IBaseService<Authority, AuthorityModelDriven> {
	/**
	 * 检查权限名字是否存在
	 * 
	 * @param authorityModelDriven
	 * @return 成功true 失败false
	 */
	public boolean checkAuthority(AuthorityModelDriven authorityModelDriven);

	/**
	 * 获取菜单项list
	 * 
	 * @return
	 */
	public List<Menu> getMenus();

	/**
	 * 获取list
	 * 
	 * @param authorityModelDriven
	 * @return
	 */
	public List<Authority> getAuthorityList(AuthorityModelDriven authorityModelDriven);

	/**
	 * 菜单关联
	 * 
	 * @param authorityModelDriven
	 */
	public int updateRelevance(AuthorityModelDriven authorityModelDriven);

	/**
	 * 搜索二级菜单
	 * 
	 * @param authorityModelDriven
	 * @return
	 */
	public Page<Authority> searchSecondMenu(String forwordName,AuthorityModelDriven authorityModelDriven);
	/**
	 * 获取所有权限
	 * @return
	 */
	public List<Authority> findAll();
	/**
	 * 菜单权限
	 * @param roles
	 * @return
	 */
	public List<Authority> menuAuthority(Set<Role> roles);

}

package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsPhoto entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_photo", catalog = "wslm")
public class WsPhoto implements java.io.Serializable {

	// Fields

	private Integer photoId;
	private String albumId;
	private String photoPath;
	private String minPhotoPath;
	private Integer createTime;

	// Constructors

	/** default constructor */
	public WsPhoto() {
	}

	/** full constructor */
	public WsPhoto(String albumId, String photoPath, String minPhotoPath,
			Integer createTime) {
		this.albumId = albumId;
		this.photoPath = photoPath;
		this.minPhotoPath = minPhotoPath;
		this.createTime = createTime;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "photo_id", unique = true, nullable = false)
	public Integer getPhotoId() {
		return this.photoId;
	}

	public void setPhotoId(Integer photoId) {
		this.photoId = photoId;
	}

	@Column(name = "album_id", nullable = false, length = 45)
	public String getAlbumId() {
		return this.albumId;
	}

	public void setAlbumId(String albumId) {
		this.albumId = albumId;
	}

	@Column(name = "photo_path", nullable = false, length = 100)
	public String getPhotoPath() {
		return this.photoPath;
	}

	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}

	@Column(name = "min_photo_path", nullable = false, length = 100)
	public String getMinPhotoPath() {
		return this.minPhotoPath;
	}

	public void setMinPhotoPath(String minPhotoPath) {
		this.minPhotoPath = minPhotoPath;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

}
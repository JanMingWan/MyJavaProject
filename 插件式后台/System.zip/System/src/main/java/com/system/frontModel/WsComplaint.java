package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsComplaint entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_complaint", catalog = "wslm")
public class WsComplaint implements java.io.Serializable {

	// Fields

	private Integer complaintId;
	private String complaintSn;
	private Integer userId;
	private Integer shopId;
	private Integer complaintTime;
	private String content;
	private String imagePath;
	private Integer orderId;
	private Integer phone;
	private String email;
	private Integer adminId;
	private String adminReply;
	private Boolean status;
	private Integer relyTime;

	// Constructors

	/** default constructor */
	public WsComplaint() {
	}

	/** minimal constructor */
	public WsComplaint(String complaintSn, Integer userId, Integer shopId,
			Integer complaintTime, String content, Integer orderId,
			Integer phone, String email, Integer adminId, Boolean status) {
		this.complaintSn = complaintSn;
		this.userId = userId;
		this.shopId = shopId;
		this.complaintTime = complaintTime;
		this.content = content;
		this.orderId = orderId;
		this.phone = phone;
		this.email = email;
		this.adminId = adminId;
		this.status = status;
	}

	/** full constructor */
	public WsComplaint(String complaintSn, Integer userId, Integer shopId,
			Integer complaintTime, String content, String imagePath,
			Integer orderId, Integer phone, String email, Integer adminId,
			String adminReply, Boolean status, Integer relyTime) {
		this.complaintSn = complaintSn;
		this.userId = userId;
		this.shopId = shopId;
		this.complaintTime = complaintTime;
		this.content = content;
		this.imagePath = imagePath;
		this.orderId = orderId;
		this.phone = phone;
		this.email = email;
		this.adminId = adminId;
		this.adminReply = adminReply;
		this.status = status;
		this.relyTime = relyTime;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "complaint_id", unique = true, nullable = false)
	public Integer getComplaintId() {
		return this.complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	@Column(name = "complaint_sn", nullable = false, length = 20)
	public String getComplaintSn() {
		return this.complaintSn;
	}

	public void setComplaintSn(String complaintSn) {
		this.complaintSn = complaintSn;
	}

	@Column(name = "user_id", nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "complaint_time", nullable = false)
	public Integer getComplaintTime() {
		return this.complaintTime;
	}

	public void setComplaintTime(Integer complaintTime) {
		this.complaintTime = complaintTime;
	}

	@Column(name = "content", nullable = false, length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "image_path", length = 100)
	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Column(name = "order_id", nullable = false)
	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	@Column(name = "phone", nullable = false)
	public Integer getPhone() {
		return this.phone;
	}

	public void setPhone(Integer phone) {
		this.phone = phone;
	}

	@Column(name = "email", nullable = false, length = 60)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "admin_id", nullable = false)
	public Integer getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	@Column(name = "admin_reply", length = 65535)
	public String getAdminReply() {
		return this.adminReply;
	}

	public void setAdminReply(String adminReply) {
		this.adminReply = adminReply;
	}

	@Column(name = "status", nullable = false)
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Column(name = "rely_time")
	public Integer getRelyTime() {
		return this.relyTime;
	}

	public void setRelyTime(Integer relyTime) {
		this.relyTime = relyTime;
	}

}
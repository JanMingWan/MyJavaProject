package com.system.action.manage;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ModelDriven;
import com.system.base.impl.BaseAction;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModelDriven.MenuModelDriven;
import com.system.manageService.IMenuService;
import com.system.util.jsonUtil.Json;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:菜单Action
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: MenuAction.java
 */
@Namespace("/manageMenu")
@Results({
		@Result(name = "menu_Page", location = "/WEB-INF/manage/menu/menu.jsp"),
		@Result(name = "success", location = "/WEB-INF/manage/result/success.jsp"),
		@Result(name = "jumpUpdateMenuPage_SUCCESS", location = "/WEB-INF/manage/menu/editMenu.jsp"),
		@Result(name = "secondMenu", location = "/WEB-INF/manage/menu/secondMenu.jsp") })
public class MenuAction extends BaseAction implements
		ModelDriven<MenuModelDriven> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4271691674189116489L;
	MenuModelDriven menuModelDriven = new MenuModelDriven();

	@Autowired
	IMenuService menuService;

	/**
	 * 添加菜单
	 * 
	 * @return
	 */
	public String addMenu() {
		menuService.save(menuModelDriven);
		this.setRequestAttribute("success","成功添加\"" + menuModelDriven.getName() + "\"菜单项");
		return SUCCESS;
	}

	/**
	 * 添加菜单页面跳转
	 * 
	 * @return
	 */
	public String jumpAddMenuPage() {
		// 提示信息
		Page<Menu> menus = menuService.findAll(this.getRoot()+ "/manageMenu/menu!jumpAddMenuPage", menuModelDriven);
		this.setRequestAttribute("menu_page",menus);
		return "menu_Page";
	}

	/**
	 * 关键字查询
	 * 
	 * @return
	 */
	public String search() {
		Page<Menu> menus=menuService.search(this.getRoot()+"/manageMenu/menu!search?name="+menuModelDriven.getName(), menuModelDriven);
		this.setRequestAttribute("menu_page",menus);
		return "menu_Page";
	}

	/**
	 * 检查菜单名是否存在
	 */
	public void checkMenuName() {
		boolean checkResult = menuService.checkMenuName(menuModelDriven);
		Json json = new Json();// json实例
		if (checkResult) {// 判断校验结果
			json.setSuccess(true);
			json.setMsg("校验成功");
		} else {
			json.setSuccess(false);
			json.setMsg("菜单名已存在");
		}
		this.writeJson(json);
	}

	/**
	 * 删除
	 * 
	 * @return
	 */
	public String delete() {
		menuService.delete(menuModelDriven);
		this.setRequestAttribute("success", "成功删除菜单项");
		return SUCCESS;
	}

	/**
	 * 修改页面跳转
	 * 
	 * @return
	 */
	public String jumpUpdateMenuPage() {
		Menu menu = menuService.get(menuModelDriven);
		this.setRequestAttribute("menu", menu);
		this.setRequestAttribute("message", "你正在更新\"" + menu.getName()
				+ "\"菜单项");
		return "jumpUpdateMenuPage_SUCCESS";
	}

	/**
	 * 更新菜单项
	 * 
	 * @return
	 */
	public String updateMenu() {
		menuService.update(menuModelDriven);
		this.setRequestAttribute("success",
				"你成功更新成\"" + menuModelDriven.getName() + "\"的菜单项");
		return SUCCESS;
	}
    /**
     * 二级菜单
     * @return
     */
	public String secondMenu(){
		Page<Authority> authority_Page=menuService.getAuthorityList(this.getRealRoot()+"/manageMenu/menu!secondMenu", menuModelDriven);
		this.setRequestAttribute("authority",authority_Page.getResult());
		System.out.println(authority_Page.getResult().size());
		this.setRequestAttribute("tag",authority_Page.getTag());
		return "secondMenu";
		
	}

	// ------模型驱动-------
	@Override
	public MenuModelDriven getModel() {
		// TODO Auto-generated method stub
		return menuModelDriven;
	}
}

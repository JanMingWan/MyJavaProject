package com.system.action.manage;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ModelDriven;
import com.system.base.impl.BaseAction;
import com.system.frontModelDriven.CityModelDriven;
import com.system.frontService.ICityService;
import com.system.manageModel.Admin;
import com.system.manageModelDriven.AdminModelDriven;
import com.system.manageService.IAdminService;
import com.system.manageService.IAuthorityService;
import com.system.manageService.IMenuService;
import com.system.util.ehcache.cacheModel.AdminMenuCacheModel;
import com.system.util.jsonUtil.Json;
/**
 * 
 * @classDescription:管理员Action
 * @author: 王嘉明
 * @cerateTime: 2013-12-12
 * @className: AdminAction.java
 */
@Namespace("/manageAdmin")
@Results({
		@Result(name = "login_SUCCESS", location = "/manage_index/index.jsp"),
		@Result(name = "login_ERROR", location = "/login.jsp"),
		@Result(name = "logOut_SUCCESS", location = "/login.jsp", type = "redirect"),
		@Result(name = "jumpAdminPage_SUCCESS", location = "/WEB-INF/manage/admin/admin.jsp"),
		@Result(name = "success", location = "/WEB-INF/manage/result/success.jsp"),
		@Result(name = "jumpUpdatePage_SUCCESS", location = "/WEB-INF/manage/admin/editAdmin.jsp"),
		@Result(name = "adminMessage_SUCCESS", location = "/WEB-INF/manage/admin/adminMessage.jsp"),
		@Result(name = "jumpAdminRole_SUCCESS", location = "/WEB-INF/manage/admin/editAdminRole.jsp") })

public class AdminAction extends BaseAction implements ModelDriven<AdminModelDriven> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4271572368427117787L;

	AdminModelDriven adminModelDriven = new AdminModelDriven();

	@Autowired
	IAdminService adminService;
	@Autowired
	ICityService cityService;
	@Autowired
	IAuthorityService authorityService;
	@Autowired
	IMenuService menuService;

	/**
	 * 登录方法
	 * 
	 * @return
	 */
	public String login() {
		Admin admin = adminService
				.login(adminModelDriven, this.getRemoteAddr());// 查询admin
		if (admin != null) {
			if (ehCache.getCache("adminCache",
					"adminMenu_" + admin.getAdminId()) != null) {
				this.setSessionAttribute("adminMenu",ehCache.getCache("adminCache","adminMenu_" + admin.getAdminId()));
			} else {
				AdminMenuCacheModel amcm = adminService.getMenu(admin);
				ehCache.setCache("adminCache","adminMenu_" + admin.getAdminId(), amcm);
				this.setSessionAttribute("adminMenu", amcm);
			}

			this.setSessionAttribute("admin", admin);
			return "login_SUCCESS";
		} else {
			this.setRequestAttribute("errorMessage", "账号或密码错误");
			return "login_ERROR";
		}
	}

	/**
	 * 登出方法
	 * 
	 * @return
	 */
	public String logOut() {
		this.getSession().invalidate();
		return "logOut_SUCCESS";
	}

	/**
	 * 页面跳转
	 * 
	 * @return
	 */
	public String jumpAdminPage() {
		this.setRequestAttribute(
				"admin_Page",
				adminService.findAll(this.getRoot()
						+ "/manageAdmin/admin!jumpAdminPage", adminModelDriven));
		this.setRequestAttribute("cities", cityService.allCity());
		return "jumpAdminPage_SUCCESS";
	}

	/**
	 * 校验
	 * 
	 * @return
	 */
	public void checkName() {
		Json json = new Json();
		if (adminService.checkName(adminModelDriven)) {
			json.setMsg("校验成功");
			json.setSuccess(true);
		} else {
			json.setMsg("登录名已存在");
			json.setSuccess(false);
		}
		this.writeJson(json);
	}

	/**
	 * 校验真实姓名
	 */
	public void checkRealName() {
		Json json = new Json();
		if (adminService.checkRealName(adminModelDriven)) {
			json.setMsg("校验成功");
			json.setSuccess(true);
		} else {
			json.setMsg("该真实姓名已存在");
			json.setSuccess(false);
		}
		this.writeJson(json);
	}

	/**
	 * 添加保存Admin
	 * 
	 * @return
	 */
	public String saveAdmin() {
		adminService.save(adminModelDriven);
		adminModelDriven.setSuccess("成功添加 " + adminModelDriven.getName()
				+ " 管理员");
		return SUCCESS;
	}

	/**
	 * 初始化密码
	 * 
	 * @return
	 */
	public String initializePassword() {
		adminService.initializePassword(adminModelDriven);
		adminModelDriven.setSuccess("成功初始化密码");
		return SUCCESS;
	}

	/**
	 * 删除管理员
	 * 
	 * @return
	 */
	public String deleteAdmin() {
		adminService.delete(adminModelDriven);
		adminModelDriven.setSuccess("删除成功");
		return SUCCESS;
	}

	/**
	 * 搜索admin
	 * 
	 * @return
	 */
	public String searchAdmin() {
		this.setRequestAttribute(
				"admin_Page",
				adminService.search(this.getRoot()
						+ "/manageAdmin/admin!searchAdmin?name="
						+ adminModelDriven.getName(), adminModelDriven));
		return "jumpAdminPage_SUCCESS";
	}

	/**
	 * 更新页面跳转
	 * 
	 * @return
	 */
	public String jumpUpdatePage() {
		Admin admin = adminService.get(adminModelDriven);
		this.setRequestAttribute("admin", admin);
		this.setRequestAttribute("cities", cityService.allCity());
		adminModelDriven.setMessage("正在修改 " + admin.getRealName() + " 管理员");
		return "jumpUpdatePage_SUCCESS";
	}

	/**
	 * 更新admin
	 * 
	 * @return
	 */
	public String updateAdmin() {
		adminService.update(adminModelDriven);
		adminModelDriven.setSuccess("更新成功");
		return SUCCESS;
	}

	/**
	 * 管理员信息
	 * 
	 * @return
	 */
	public String adminMessage() {
		Admin admin = adminService.get(adminModelDriven);
		this.setRequestAttribute("admin", admin);
		CityModelDriven cityModelDriven = new CityModelDriven();
		cityModelDriven.setCityId(admin.getManageCity());
		this.setRequestAttribute("city", cityService.get(cityModelDriven));
		return "adminMessage_SUCCESS";
	}

	// ----模型驱动实现类----
	@Override
	public AdminModelDriven getModel() {
		return adminModelDriven;
	}
}

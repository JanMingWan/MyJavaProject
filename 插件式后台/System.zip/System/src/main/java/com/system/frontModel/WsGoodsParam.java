package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsGoodsParam entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_goods_param", catalog = "wslm")
public class WsGoodsParam implements java.io.Serializable {

	// Fields

	private Integer paramId;
	private String paramName;
	private Integer pid;
	private Integer goodsId;

	// Constructors

	/** default constructor */
	public WsGoodsParam() {
	}

	/** full constructor */
	public WsGoodsParam(String paramName, Integer pid, Integer goodsId) {
		this.paramName = paramName;
		this.pid = pid;
		this.goodsId = goodsId;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "param_id", unique = true, nullable = false)
	public Integer getParamId() {
		return this.paramId;
	}

	public void setParamId(Integer paramId) {
		this.paramId = paramId;
	}

	@Column(name = "param_name", nullable = false, length = 45)
	public String getParamName() {
		return this.paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	@Column(name = "pid", nullable = false)
	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	@Column(name = "goods_id", nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

}
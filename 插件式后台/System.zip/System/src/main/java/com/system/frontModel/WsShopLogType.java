package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopLogType entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_log_type", catalog = "wslm")
public class WsShopLogType implements java.io.Serializable {

	// Fields

	private Integer typeId;
	private String typeName;

	// Constructors

	/** default constructor */
	public WsShopLogType() {
	}

	/** full constructor */
	public WsShopLogType(String typeName) {
		this.typeName = typeName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "type_id", unique = true, nullable = false)
	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	@Column(name = "type_name", nullable = false, length = 45)
	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

}
package com.system.manageModel;

// default package

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * 
 * @classDescription:角色类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: Role.java
 */
@Entity
@Table(name = "wslm_role", catalog = "wslm_manage")
public class Role implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 4629952257144491660L;
	private Integer roleId;//id
	private Long createTime;//创建时间
	private String name;//角色名
	private Long modificationTime;// 最后修改时间
	
	private Set<Admin> admins = new HashSet<Admin>(0);
	private Set<Authority> authorities = new HashSet<Authority>(0);

	// Constructors

	/** default constructor */
	public Role() {
	}

	/** minimal constructor */
	public Role(Integer roleId, Long createTime, String name) {
		this.roleId = roleId;
		this.createTime = createTime;
		this.name = name;
	}

	/** full constructor */
	public Role(Integer roleId, Long createTime, String name,
			Set<Admin> admins, Set<Authority> authorities) {
		this.roleId = roleId;
		this.createTime = createTime;
		this.name = name;
		this.admins = admins;
		this.authorities = authorities;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "role_id", unique = true, nullable = false)
	public Integer getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	@Column(name = "createTime", nullable = false, length = 50)
	public Long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	@Column(name = "name", nullable = false, length = 100)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "wslm_admin_role", catalog = "wslm_manage", joinColumns = { @JoinColumn(name = "role_id", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "admin_id", nullable = false, updatable = false) })
	public Set<Admin> getAdmins() {
		return admins;
	}

	public void setAdmins(Set<Admin> admins) {
		this.admins = admins;
	}

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "wslm_role_authority", catalog = "wslm_manage", joinColumns = { @JoinColumn(name = "role_id", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "authority_id", nullable = false, updatable = false) })
	public Set<Authority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Set<Authority> authorities) {
		this.authorities = authorities;
	}
	@Column(name = "modificationTime", nullable = false, length = 50)
	public Long getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(Long modificationTime) {
		this.modificationTime = modificationTime;
	}

}
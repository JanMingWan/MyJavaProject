package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsGoodsParamMatch entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_goods_param_match", catalog = "wslm")
public class WsGoodsParamMatch implements java.io.Serializable {

	// Fields

	private Integer matchId;
	private String matchContent;
	private Integer goodsId;
	private Double price;
	private Double wsPrice;
	private Double vipPrice;
	private Integer num;
	private String matchName;

	// Constructors

	/** default constructor */
	public WsGoodsParamMatch() {
	}

	/** minimal constructor */
	public WsGoodsParamMatch(Integer goodsId, Double price, Double wsPrice,
			Integer num) {
		this.goodsId = goodsId;
		this.price = price;
		this.wsPrice = wsPrice;
		this.num = num;
	}

	/** full constructor */
	public WsGoodsParamMatch(String matchContent, Integer goodsId,
			Double price, Double wsPrice, Double vipPrice, Integer num,
			String matchName) {
		this.matchContent = matchContent;
		this.goodsId = goodsId;
		this.price = price;
		this.wsPrice = wsPrice;
		this.vipPrice = vipPrice;
		this.num = num;
		this.matchName = matchName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "match_id", unique = true, nullable = false)
	public Integer getMatchId() {
		return this.matchId;
	}

	public void setMatchId(Integer matchId) {
		this.matchId = matchId;
	}

	@Column(name = "match_content", length = 65535)
	public String getMatchContent() {
		return this.matchContent;
	}

	public void setMatchContent(String matchContent) {
		this.matchContent = matchContent;
	}

	@Column(name = "goods_id", nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "price", nullable = false, precision = 10)
	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Column(name = "ws_price", nullable = false, precision = 10)
	public Double getWsPrice() {
		return this.wsPrice;
	}

	public void setWsPrice(Double wsPrice) {
		this.wsPrice = wsPrice;
	}

	@Column(name = "vip_price", precision = 10)
	public Double getVipPrice() {
		return this.vipPrice;
	}

	public void setVipPrice(Double vipPrice) {
		this.vipPrice = vipPrice;
	}

	@Column(name = "num", nullable = false)
	public Integer getNum() {
		return this.num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	@Column(name = "match_name", length = 100)
	public String getMatchName() {
		return this.matchName;
	}

	public void setMatchName(String matchName) {
		this.matchName = matchName;
	}

}
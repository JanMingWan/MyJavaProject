package com.system.frontService;

import java.util.List;

import com.system.base.IBaseService;
import com.system.frontModel.WsCity;
import com.system.frontModelDriven.CityModelDriven;

/**
 * 
 * @classDescription:城市业务类接口,由于city表不需要经常修改
 * @author: 王嘉明
 * @cerateTime: 2013-12-5
 * @className: ICityService.java
 */
public interface ICityService extends IBaseService<WsCity, CityModelDriven> {
	/**
	 * 获取所有城市
	 * @return
	 */
	public List<WsCity> allCity();
}

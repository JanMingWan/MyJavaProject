package com.system.manageModelDriven;

import java.io.Serializable;

import com.system.base.impl.BaseModelDriven;

/**
 * admin模型驱动
 * 
 * 
 * @author 王嘉明
 * @cerateTime 2013/11/23
 */
public class AdminModelDriven extends BaseModelDriven implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -768460710521792414L;
	private String adminId;// id
	private String name;// 登录账号
	private String password;// 密码
	private String email;// 邮箱
	private String realName;// 真实姓名
	private Boolean status;// 是否冻结
	private Short type;// 管理员类型（1超级管理员，2区域管理员，3普通管理员）
	private Integer manageCity;// 管理地区
	
	private String roleId;
	

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Integer getManageCity() {
		return manageCity;
	}

	public void setManageCity(Integer manageCity) {
		this.manageCity = manageCity;
	}

}

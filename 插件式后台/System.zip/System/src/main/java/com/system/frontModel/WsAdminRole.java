package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsAdminRole entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_admin_role", catalog = "wslm")
public class WsAdminRole implements java.io.Serializable {

	// Fields

	private Integer roleId;
	private String roleName;
	private String actionList;
	private String roleDescribe;

	// Constructors

	/** default constructor */
	public WsAdminRole() {
	}

	/** minimal constructor */
	public WsAdminRole(String roleName) {
		this.roleName = roleName;
	}

	/** full constructor */
	public WsAdminRole(String roleName, String actionList, String roleDescribe) {
		this.roleName = roleName;
		this.actionList = actionList;
		this.roleDescribe = roleDescribe;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "role_id", unique = true, nullable = false)
	public Integer getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	@Column(name = "role_name", nullable = false, length = 45)
	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Column(name = "action_list", length = 65535)
	public String getActionList() {
		return this.actionList;
	}

	public void setActionList(String actionList) {
		this.actionList = actionList;
	}

	@Column(name = "role_describe", length = 65535)
	public String getRoleDescribe() {
		return this.roleDescribe;
	}

	public void setRoleDescribe(String roleDescribe) {
		this.roleDescribe = roleDescribe;
	}

}
package com.system.action.manage;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ModelDriven;
import com.system.base.impl.BaseAction;
import com.system.manageModel.Authority;
import com.system.manageModelDriven.AuthorityModelDriven;
import com.system.manageService.IAuthorityService;
import com.system.util.jsonUtil.Json;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:权限&菜单类action
 * @author: 王嘉明
 * @cerateTime: 2013-11-28
 * @className: AuthorityAction.java
 */
@Namespace("/manageAuthority")
@Results({
		@Result(name = "authroity_Page", location = "/WEB-INF/manage/authority/authority.jsp"),
		@Result(name = "success", location = "/WEB-INF/manage/result/success.jsp"),
		@Result(name = "input", location = "/WEB-INF/manage/result/error.jsp"),
		@Result(name = "updateAuthority_SUCCESS", location = "/WEB-INF/manage/authority/editAuthority.jsp"),
		@Result(name = "jumpRelevance_SUCCESS", location = "/WEB-INF/manage/authority/relevanceMenu.jsp")})
public class AuthorityAction extends BaseAction implements
		ModelDriven<AuthorityModelDriven> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4068347092368937820L;
	AuthorityModelDriven authorityModelDriven = new AuthorityModelDriven();

	@Autowired
	IAuthorityService authorityService;

	/**
	 * 检查名字
	 * 
	 * @return
	 */
	public void checkAuthorityName() {
		boolean checkResult = authorityService
				.checkAuthority(authorityModelDriven);
		Json json = new Json();
		if (checkResult) {
			json.setSuccess(true);
			json.setMsg("验证通过");
		} else {
			json.setSuccess(false);
			json.setMsg("该名字已存在");
		}
		this.writeJson(json);
	}

	/**
	 * 保存权限
	 * 
	 * @return
	 */
	public String saveAuthority() {
		authorityService.save(authorityModelDriven);
		authorityModelDriven.setSuccess("成功添加" + authorityModelDriven.getName()
				+ "权限");
		return SUCCESS;
	}

	/**
	 * 页面跳转
	 * 
	 * @return
	 */
	public String jumpAuthorityPage() {
		Page<Authority> authority_Page = authorityService.findAll(this.getRoot()+ "/manageAuthority/authority!jumpAuthorityPage",
						authorityModelDriven);// 获取分页
		this.setRequestAttribute("authority_Page", authority_Page);
		return "authroity_Page";
	}

	/**
	 * 删除&批量删除
	 * 
	 * @return
	 */
	public String deleteAuthority() {
		authorityService.delete(authorityModelDriven);
		authorityModelDriven.setSuccess("成功删除");
		return SUCCESS;
	}

	/**
	 * 更新
	 * 
	 * @return
	 */
	public String updateAuthority() {
		authorityService.update(authorityModelDriven);
		authorityModelDriven.setSuccess("更新成功");
		return SUCCESS;
	}

	/**
	 * 搜索
	 * 
	 * @return
	 */
	public String searchAuthority() {
		Page<Authority> authority_Page = authorityService.search(this.getRoot()
				+ "/manageAuthority/authority!searchAuthority?name="
				+ authorityModelDriven.getName(), authorityModelDriven);
		this.setRequestAttribute("authority_Page", authority_Page);
		return "authroity_Page";
	}

	/**
	 * 更新权限
	 * 
	 * @return
	 */
	public String jumpUpdateAuthority() {
		Authority authority = authorityService.get(authorityModelDriven);
		this.setRequestAttribute("authority", authority);
		authorityModelDriven.setMessage("你正在更新" + authority.getName() + "权限。");
		return "updateAuthority_SUCCESS";
	}

	/**
	 * 关联跳转
	 * 
	 * @return
	 */
	public String jumpRelevance() {
		this.setRequestAttribute("authorities",
				authorityService.getAuthorityList(authorityModelDriven));
		this.setRequestAttribute("menus", authorityService.getMenus());
		authorityModelDriven.setMessage("注意：若权限已经关联菜单项，将会取消之前的关联菜单项并关联新菜单");
		return "jumpRelevance_SUCCESS";
	}

	/**
	 * 关联
	 * 
	 * @return
	 */
	public String relevance() {
		int success_Authority = authorityService
				.updateRelevance(authorityModelDriven);
		authorityModelDriven.setSuccess("成功关联" + success_Authority + "条菜单");
		return SUCCESS;
	}
    /**
     * 查询
     * @return
     */
	public String searchSecondMenu() {
		Page<Authority> authority_Page = authorityService.searchSecondMenu(
				this.getRoot()
						+ "/manageAuthority/authority!searchSecondMenu?name="
						+ authorityModelDriven.getMenuId(),
				authorityModelDriven);
		this.setRequestAttribute("authority_Page", authority_Page);
		return "authroity_Page";
	}

	// ------模型驱动-------
	@Override
	public AuthorityModelDriven getModel() {
		return authorityModelDriven;
	}

}

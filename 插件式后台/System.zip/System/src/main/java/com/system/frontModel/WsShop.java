package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShop entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop", catalog = "wslm")
public class WsShop implements java.io.Serializable {

	// Fields

	private Integer shopId;
	private String shopName;
	private Integer shopTypeFirst;
	private String shopTypeSecond;
	private String shopImage;
	private Integer rank;
	private Integer credit;
	private String businessLicense;
	private String organizationLicense;
	private String taxLicense;
	private Integer clickCount;
	private Boolean isAlipay;
	private Boolean isRebate;
	private Boolean isOrder;
	private Boolean isActive;
	private Boolean isName;
	private Integer bannerId;
	private String bannerPath;
	private Integer backgroundId;
	private String backgroundPath;
	private Boolean verifyStatus;
	private Integer createTime;
	private String failureReasons;
	private Integer accountId;
	private String lat;
	private String lnt;
	private String content;
	private String env;
	private String tag1;
	private String tag2;
	private String tag3;
	private Boolean isDiscount;
	private Boolean isVip;
	private Integer totalBuy;
	private Integer activeId;
	private String activePath;

	// Constructors

	/** default constructor */
	public WsShop() {
	}

	/** minimal constructor */
	public WsShop(String shopName, Integer shopTypeFirst,
			String shopTypeSecond, Integer clickCount, Boolean isAlipay,
			Boolean isRebate, Boolean isOrder, Boolean isActive,
			Boolean isName, Integer bannerId, Boolean verifyStatus,
			Integer createTime, Integer accountId, Boolean isDiscount,
			Boolean isVip) {
		this.shopName = shopName;
		this.shopTypeFirst = shopTypeFirst;
		this.shopTypeSecond = shopTypeSecond;
		this.clickCount = clickCount;
		this.isAlipay = isAlipay;
		this.isRebate = isRebate;
		this.isOrder = isOrder;
		this.isActive = isActive;
		this.isName = isName;
		this.bannerId = bannerId;
		this.verifyStatus = verifyStatus;
		this.createTime = createTime;
		this.accountId = accountId;
		this.isDiscount = isDiscount;
		this.isVip = isVip;
	}

	/** full constructor */
	public WsShop(String shopName, Integer shopTypeFirst,
			String shopTypeSecond, String shopImage, Integer rank,
			Integer credit, String businessLicense, String organizationLicense,
			String taxLicense, Integer clickCount, Boolean isAlipay,
			Boolean isRebate, Boolean isOrder, Boolean isActive,
			Boolean isName, Integer bannerId, String bannerPath,
			Integer backgroundId, String backgroundPath, Boolean verifyStatus,
			Integer createTime, String failureReasons, Integer accountId,
			String lat, String lnt, String content, String env, String tag1,
			String tag2, String tag3, Boolean isDiscount, Boolean isVip,
			Integer totalBuy, Integer activeId, String activePath) {
		this.shopName = shopName;
		this.shopTypeFirst = shopTypeFirst;
		this.shopTypeSecond = shopTypeSecond;
		this.shopImage = shopImage;
		this.rank = rank;
		this.credit = credit;
		this.businessLicense = businessLicense;
		this.organizationLicense = organizationLicense;
		this.taxLicense = taxLicense;
		this.clickCount = clickCount;
		this.isAlipay = isAlipay;
		this.isRebate = isRebate;
		this.isOrder = isOrder;
		this.isActive = isActive;
		this.isName = isName;
		this.bannerId = bannerId;
		this.bannerPath = bannerPath;
		this.backgroundId = backgroundId;
		this.backgroundPath = backgroundPath;
		this.verifyStatus = verifyStatus;
		this.createTime = createTime;
		this.failureReasons = failureReasons;
		this.accountId = accountId;
		this.lat = lat;
		this.lnt = lnt;
		this.content = content;
		this.env = env;
		this.tag1 = tag1;
		this.tag2 = tag2;
		this.tag3 = tag3;
		this.isDiscount = isDiscount;
		this.isVip = isVip;
		this.totalBuy = totalBuy;
		this.activeId = activeId;
		this.activePath = activePath;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "shop_id", unique = true, nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "shop_name", nullable = false, length = 60)
	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	@Column(name = "shop_type_first", nullable = false)
	public Integer getShopTypeFirst() {
		return this.shopTypeFirst;
	}

	public void setShopTypeFirst(Integer shopTypeFirst) {
		this.shopTypeFirst = shopTypeFirst;
	}

	@Column(name = "shop_type_second", nullable = false, length = 45)
	public String getShopTypeSecond() {
		return this.shopTypeSecond;
	}

	public void setShopTypeSecond(String shopTypeSecond) {
		this.shopTypeSecond = shopTypeSecond;
	}

	@Column(name = "shop_image", length = 100)
	public String getShopImage() {
		return this.shopImage;
	}

	public void setShopImage(String shopImage) {
		this.shopImage = shopImage;
	}

	@Column(name = "rank")
	public Integer getRank() {
		return this.rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Column(name = "credit")
	public Integer getCredit() {
		return this.credit;
	}

	public void setCredit(Integer credit) {
		this.credit = credit;
	}

	@Column(name = "business_license", length = 100)
	public String getBusinessLicense() {
		return this.businessLicense;
	}

	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}

	@Column(name = "organization_license", length = 100)
	public String getOrganizationLicense() {
		return this.organizationLicense;
	}

	public void setOrganizationLicense(String organizationLicense) {
		this.organizationLicense = organizationLicense;
	}

	@Column(name = "tax_license", length = 100)
	public String getTaxLicense() {
		return this.taxLicense;
	}

	public void setTaxLicense(String taxLicense) {
		this.taxLicense = taxLicense;
	}

	@Column(name = "click_count", nullable = false)
	public Integer getClickCount() {
		return this.clickCount;
	}

	public void setClickCount(Integer clickCount) {
		this.clickCount = clickCount;
	}

	@Column(name = "is_alipay", nullable = false)
	public Boolean getIsAlipay() {
		return this.isAlipay;
	}

	public void setIsAlipay(Boolean isAlipay) {
		this.isAlipay = isAlipay;
	}

	@Column(name = "is_rebate", nullable = false)
	public Boolean getIsRebate() {
		return this.isRebate;
	}

	public void setIsRebate(Boolean isRebate) {
		this.isRebate = isRebate;
	}

	@Column(name = "is_order", nullable = false)
	public Boolean getIsOrder() {
		return this.isOrder;
	}

	public void setIsOrder(Boolean isOrder) {
		this.isOrder = isOrder;
	}

	@Column(name = "is_active", nullable = false)
	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@Column(name = "is_name", nullable = false)
	public Boolean getIsName() {
		return this.isName;
	}

	public void setIsName(Boolean isName) {
		this.isName = isName;
	}

	@Column(name = "banner_id", nullable = false)
	public Integer getBannerId() {
		return this.bannerId;
	}

	public void setBannerId(Integer bannerId) {
		this.bannerId = bannerId;
	}

	@Column(name = "banner_path", length = 100)
	public String getBannerPath() {
		return this.bannerPath;
	}

	public void setBannerPath(String bannerPath) {
		this.bannerPath = bannerPath;
	}

	@Column(name = "background_id")
	public Integer getBackgroundId() {
		return this.backgroundId;
	}

	public void setBackgroundId(Integer backgroundId) {
		this.backgroundId = backgroundId;
	}

	@Column(name = "background_path", length = 100)
	public String getBackgroundPath() {
		return this.backgroundPath;
	}

	public void setBackgroundPath(String backgroundPath) {
		this.backgroundPath = backgroundPath;
	}

	@Column(name = "verify_status", nullable = false)
	public Boolean getVerifyStatus() {
		return this.verifyStatus;
	}

	public void setVerifyStatus(Boolean verifyStatus) {
		this.verifyStatus = verifyStatus;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

	@Column(name = "failure_reasons", length = 200)
	public String getFailureReasons() {
		return this.failureReasons;
	}

	public void setFailureReasons(String failureReasons) {
		this.failureReasons = failureReasons;
	}

	@Column(name = "account_id", nullable = false)
	public Integer getAccountId() {
		return this.accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	@Column(name = "lat", length = 45)
	public String getLat() {
		return this.lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	@Column(name = "lnt", length = 45)
	public String getLnt() {
		return this.lnt;
	}

	public void setLnt(String lnt) {
		this.lnt = lnt;
	}

	@Column(name = "content", length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "env", length = 65535)
	public String getEnv() {
		return this.env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	@Column(name = "tag1", length = 20)
	public String getTag1() {
		return this.tag1;
	}

	public void setTag1(String tag1) {
		this.tag1 = tag1;
	}

	@Column(name = "tag2", length = 20)
	public String getTag2() {
		return this.tag2;
	}

	public void setTag2(String tag2) {
		this.tag2 = tag2;
	}

	@Column(name = "tag3", length = 20)
	public String getTag3() {
		return this.tag3;
	}

	public void setTag3(String tag3) {
		this.tag3 = tag3;
	}

	@Column(name = "is_discount", nullable = false)
	public Boolean getIsDiscount() {
		return this.isDiscount;
	}

	public void setIsDiscount(Boolean isDiscount) {
		this.isDiscount = isDiscount;
	}

	@Column(name = "is_vip", nullable = false)
	public Boolean getIsVip() {
		return this.isVip;
	}

	public void setIsVip(Boolean isVip) {
		this.isVip = isVip;
	}

	@Column(name = "total_buy")
	public Integer getTotalBuy() {
		return this.totalBuy;
	}

	public void setTotalBuy(Integer totalBuy) {
		this.totalBuy = totalBuy;
	}

	@Column(name = "active_id")
	public Integer getActiveId() {
		return this.activeId;
	}

	public void setActiveId(Integer activeId) {
		this.activeId = activeId;
	}

	@Column(name = "active_path", length = 100)
	public String getActivePath() {
		return this.activePath;
	}

	public void setActivePath(String activePath) {
		this.activePath = activePath;
	}

}
package com.system.manageDao.impl;

import org.springframework.stereotype.Repository;

import com.system.base.impl.BaseDaoImpl;
import com.system.manageDao.IMenuDao;
import com.system.manageModel.Menu;
/**
 * 
 * @classDescription:菜单数据访问层实现类
 * @author: 王嘉明
 * @cerateTime: 2013-11-26
 * @className: MenuDaoImpl.java
 */
@Repository
public class MenuDaoImpl extends BaseDaoImpl<Menu> implements IMenuDao {

}

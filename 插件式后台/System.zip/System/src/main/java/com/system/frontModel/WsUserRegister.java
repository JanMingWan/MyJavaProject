package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsUserRegister entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_user_register", catalog = "wslm")
public class WsUserRegister implements java.io.Serializable {

	// Fields

	private Integer registerId;
	private String registerEmail;
	private String registerPassword;
	private Integer registerTime;
	private String registerCode;
	private Boolean registerType;

	// Constructors

	/** default constructor */
	public WsUserRegister() {
	}

	/** minimal constructor */
	public WsUserRegister(String registerEmail, String registerPassword,
			Boolean registerType) {
		this.registerEmail = registerEmail;
		this.registerPassword = registerPassword;
		this.registerType = registerType;
	}

	/** full constructor */
	public WsUserRegister(String registerEmail, String registerPassword,
			Integer registerTime, String registerCode, Boolean registerType) {
		this.registerEmail = registerEmail;
		this.registerPassword = registerPassword;
		this.registerTime = registerTime;
		this.registerCode = registerCode;
		this.registerType = registerType;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "register_id", unique = true, nullable = false)
	public Integer getRegisterId() {
		return this.registerId;
	}

	public void setRegisterId(Integer registerId) {
		this.registerId = registerId;
	}

	@Column(name = "register_email", nullable = false, length = 60)
	public String getRegisterEmail() {
		return this.registerEmail;
	}

	public void setRegisterEmail(String registerEmail) {
		this.registerEmail = registerEmail;
	}

	@Column(name = "register_password", nullable = false, length = 32)
	public String getRegisterPassword() {
		return this.registerPassword;
	}

	public void setRegisterPassword(String registerPassword) {
		this.registerPassword = registerPassword;
	}

	@Column(name = "register_time")
	public Integer getRegisterTime() {
		return this.registerTime;
	}

	public void setRegisterTime(Integer registerTime) {
		this.registerTime = registerTime;
	}

	@Column(name = "register_code", length = 45)
	public String getRegisterCode() {
		return this.registerCode;
	}

	public void setRegisterCode(String registerCode) {
		this.registerCode = registerCode;
	}

	@Column(name = "register_type", nullable = false)
	public Boolean getRegisterType() {
		return this.registerType;
	}

	public void setRegisterType(Boolean registerType) {
		this.registerType = registerType;
	}

}
package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsComment entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_comment", catalog = "wslm")
public class WsComment implements java.io.Serializable {

	// Fields

	private Integer commentId;
	private Integer goodsId;
	private Integer userId;
	private String content;
	private Integer isReply;
	private String shopReply;
	private Boolean qualityScore;
	private Boolean serviceScore;
	private Boolean environmentScore;
	private Integer commentTime;
	private Integer shopReplyTime;

	// Constructors

	/** default constructor */
	public WsComment() {
	}

	/** minimal constructor */
	public WsComment(Integer goodsId, Integer userId, String content,
			Integer isReply, Boolean qualityScore, Boolean serviceScore,
			Boolean environmentScore, Integer commentTime) {
		this.goodsId = goodsId;
		this.userId = userId;
		this.content = content;
		this.isReply = isReply;
		this.qualityScore = qualityScore;
		this.serviceScore = serviceScore;
		this.environmentScore = environmentScore;
		this.commentTime = commentTime;
	}

	/** full constructor */
	public WsComment(Integer goodsId, Integer userId, String content,
			Integer isReply, String shopReply, Boolean qualityScore,
			Boolean serviceScore, Boolean environmentScore,
			Integer commentTime, Integer shopReplyTime) {
		this.goodsId = goodsId;
		this.userId = userId;
		this.content = content;
		this.isReply = isReply;
		this.shopReply = shopReply;
		this.qualityScore = qualityScore;
		this.serviceScore = serviceScore;
		this.environmentScore = environmentScore;
		this.commentTime = commentTime;
		this.shopReplyTime = shopReplyTime;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "comment_id", unique = true, nullable = false)
	public Integer getCommentId() {
		return this.commentId;
	}

	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	@Column(name = "goods_id", nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "user_id", nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "content", nullable = false, length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "is_reply", nullable = false)
	public Integer getIsReply() {
		return this.isReply;
	}

	public void setIsReply(Integer isReply) {
		this.isReply = isReply;
	}

	@Column(name = "shop_reply", length = 45)
	public String getShopReply() {
		return this.shopReply;
	}

	public void setShopReply(String shopReply) {
		this.shopReply = shopReply;
	}

	@Column(name = "quality_score", nullable = false)
	public Boolean getQualityScore() {
		return this.qualityScore;
	}

	public void setQualityScore(Boolean qualityScore) {
		this.qualityScore = qualityScore;
	}

	@Column(name = "service_score", nullable = false)
	public Boolean getServiceScore() {
		return this.serviceScore;
	}

	public void setServiceScore(Boolean serviceScore) {
		this.serviceScore = serviceScore;
	}

	@Column(name = "environment_score", nullable = false)
	public Boolean getEnvironmentScore() {
		return this.environmentScore;
	}

	public void setEnvironmentScore(Boolean environmentScore) {
		this.environmentScore = environmentScore;
	}

	@Column(name = "comment_time", nullable = false)
	public Integer getCommentTime() {
		return this.commentTime;
	}

	public void setCommentTime(Integer commentTime) {
		this.commentTime = commentTime;
	}

	@Column(name = "shop_reply_time")
	public Integer getShopReplyTime() {
		return this.shopReplyTime;
	}

	public void setShopReplyTime(Integer shopReplyTime) {
		this.shopReplyTime = shopReplyTime;
	}

}
package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsGoods entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_goods", catalog = "wslm")
public class WsGoods implements java.io.Serializable {

	// Fields

	private Integer goodsId;
	private String goodsSn;
	private String goodsName;
	private Integer shopId;
	private String content;
	private Boolean status;
	private Integer clickCount;
	private String goodsImage;
	private String minGoodsImage;
	private Boolean isSetmeals;
	private Double averageScore;
	private Integer totalComment;
	private Boolean isSale;
	private String isLock;
	private Integer columnFirstId;
	private Integer columnSecondId;
	private Integer createTime;
	private Integer startTime;
	private Integer stopTime;
	private Integer lockDeadline;
	private Integer typeFirstId;
	private Integer typeSecondId;
	private Integer totalBuy;
	private Boolean isRecommend;
	private Boolean recommendSort;

	// Constructors

	/** default constructor */
	public WsGoods() {
	}

	/** minimal constructor */
	public WsGoods(String goodsSn, String goodsName, Integer shopId,
			String content, Boolean status, String goodsImage,
			Boolean isSetmeals, Double averageScore, Boolean isSale,
			String isLock, Integer columnFirstId, Integer columnSecondId,
			Integer createTime, Integer startTime, Integer stopTime,
			Integer lockDeadline, Integer typeFirstId, Integer typeSecondId,
			Boolean isRecommend) {
		this.goodsSn = goodsSn;
		this.goodsName = goodsName;
		this.shopId = shopId;
		this.content = content;
		this.status = status;
		this.goodsImage = goodsImage;
		this.isSetmeals = isSetmeals;
		this.averageScore = averageScore;
		this.isSale = isSale;
		this.isLock = isLock;
		this.columnFirstId = columnFirstId;
		this.columnSecondId = columnSecondId;
		this.createTime = createTime;
		this.startTime = startTime;
		this.stopTime = stopTime;
		this.lockDeadline = lockDeadline;
		this.typeFirstId = typeFirstId;
		this.typeSecondId = typeSecondId;
		this.isRecommend = isRecommend;
	}

	/** full constructor */
	public WsGoods(String goodsSn, String goodsName, Integer shopId,
			String content, Boolean status, Integer clickCount,
			String goodsImage, String minGoodsImage, Boolean isSetmeals,
			Double averageScore, Integer totalComment, Boolean isSale,
			String isLock, Integer columnFirstId, Integer columnSecondId,
			Integer createTime, Integer startTime, Integer stopTime,
			Integer lockDeadline, Integer typeFirstId, Integer typeSecondId,
			Integer totalBuy, Boolean isRecommend, Boolean recommendSort) {
		this.goodsSn = goodsSn;
		this.goodsName = goodsName;
		this.shopId = shopId;
		this.content = content;
		this.status = status;
		this.clickCount = clickCount;
		this.goodsImage = goodsImage;
		this.minGoodsImage = minGoodsImage;
		this.isSetmeals = isSetmeals;
		this.averageScore = averageScore;
		this.totalComment = totalComment;
		this.isSale = isSale;
		this.isLock = isLock;
		this.columnFirstId = columnFirstId;
		this.columnSecondId = columnSecondId;
		this.createTime = createTime;
		this.startTime = startTime;
		this.stopTime = stopTime;
		this.lockDeadline = lockDeadline;
		this.typeFirstId = typeFirstId;
		this.typeSecondId = typeSecondId;
		this.totalBuy = totalBuy;
		this.isRecommend = isRecommend;
		this.recommendSort = recommendSort;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "goods_id", unique = true, nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "goods_sn", nullable = false, length = 45)
	public String getGoodsSn() {
		return this.goodsSn;
	}

	public void setGoodsSn(String goodsSn) {
		this.goodsSn = goodsSn;
	}

	@Column(name = "goods_name", nullable = false, length = 45)
	public String getGoodsName() {
		return this.goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "content", nullable = false, length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "status", nullable = false)
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Column(name = "click_count")
	public Integer getClickCount() {
		return this.clickCount;
	}

	public void setClickCount(Integer clickCount) {
		this.clickCount = clickCount;
	}

	@Column(name = "goods_image", nullable = false, length = 100)
	public String getGoodsImage() {
		return this.goodsImage;
	}

	public void setGoodsImage(String goodsImage) {
		this.goodsImage = goodsImage;
	}

	@Column(name = "min_goods_image", length = 100)
	public String getMinGoodsImage() {
		return this.minGoodsImage;
	}

	public void setMinGoodsImage(String minGoodsImage) {
		this.minGoodsImage = minGoodsImage;
	}

	@Column(name = "is_setmeals", nullable = false)
	public Boolean getIsSetmeals() {
		return this.isSetmeals;
	}

	public void setIsSetmeals(Boolean isSetmeals) {
		this.isSetmeals = isSetmeals;
	}

	@Column(name = "average_score", nullable = false, precision = 10)
	public Double getAverageScore() {
		return this.averageScore;
	}

	public void setAverageScore(Double averageScore) {
		this.averageScore = averageScore;
	}

	@Column(name = "total_comment")
	public Integer getTotalComment() {
		return this.totalComment;
	}

	public void setTotalComment(Integer totalComment) {
		this.totalComment = totalComment;
	}

	@Column(name = "is_sale", nullable = false)
	public Boolean getIsSale() {
		return this.isSale;
	}

	public void setIsSale(Boolean isSale) {
		this.isSale = isSale;
	}

	@Column(name = "is_lock", nullable = false, length = 1)
	public String getIsLock() {
		return this.isLock;
	}

	public void setIsLock(String isLock) {
		this.isLock = isLock;
	}

	@Column(name = "column_first_id", nullable = false)
	public Integer getColumnFirstId() {
		return this.columnFirstId;
	}

	public void setColumnFirstId(Integer columnFirstId) {
		this.columnFirstId = columnFirstId;
	}

	@Column(name = "column_second_id", nullable = false)
	public Integer getColumnSecondId() {
		return this.columnSecondId;
	}

	public void setColumnSecondId(Integer columnSecondId) {
		this.columnSecondId = columnSecondId;
	}

	@Column(name = "create_time", nullable = false)
	public Integer getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Integer createTime) {
		this.createTime = createTime;
	}

	@Column(name = "start_time", nullable = false)
	public Integer getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Integer startTime) {
		this.startTime = startTime;
	}

	@Column(name = "stop_time", nullable = false)
	public Integer getStopTime() {
		return this.stopTime;
	}

	public void setStopTime(Integer stopTime) {
		this.stopTime = stopTime;
	}

	@Column(name = "lock_deadline", nullable = false)
	public Integer getLockDeadline() {
		return this.lockDeadline;
	}

	public void setLockDeadline(Integer lockDeadline) {
		this.lockDeadline = lockDeadline;
	}

	@Column(name = "type_first_id", nullable = false)
	public Integer getTypeFirstId() {
		return this.typeFirstId;
	}

	public void setTypeFirstId(Integer typeFirstId) {
		this.typeFirstId = typeFirstId;
	}

	@Column(name = "type_second_id", nullable = false)
	public Integer getTypeSecondId() {
		return this.typeSecondId;
	}

	public void setTypeSecondId(Integer typeSecondId) {
		this.typeSecondId = typeSecondId;
	}

	@Column(name = "total_buy")
	public Integer getTotalBuy() {
		return this.totalBuy;
	}

	public void setTotalBuy(Integer totalBuy) {
		this.totalBuy = totalBuy;
	}

	@Column(name = "is_recommend", nullable = false)
	public Boolean getIsRecommend() {
		return this.isRecommend;
	}

	public void setIsRecommend(Boolean isRecommend) {
		this.isRecommend = isRecommend;
	}

	@Column(name = "recommend_sort")
	public Boolean getRecommendSort() {
		return this.recommendSort;
	}

	public void setRecommendSort(Boolean recommendSort) {
		this.recommendSort = recommendSort;
	}

}
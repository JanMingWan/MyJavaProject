package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsFavorable entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_favorable", catalog = "wslm")
public class WsFavorable implements java.io.Serializable {

	// Fields

	private Integer favorableId;
	private String favorable;

	// Constructors

	/** default constructor */
	public WsFavorable() {
	}

	/** full constructor */
	public WsFavorable(String favorable) {
		this.favorable = favorable;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "favorable_id", unique = true, nullable = false)
	public Integer getFavorableId() {
		return this.favorableId;
	}

	public void setFavorableId(Integer favorableId) {
		this.favorableId = favorableId;
	}

	@Column(name = "favorable", nullable = false, length = 20)
	public String getFavorable() {
		return this.favorable;
	}

	public void setFavorable(String favorable) {
		this.favorable = favorable;
	}

}
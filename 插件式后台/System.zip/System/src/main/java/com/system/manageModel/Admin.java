package com.system.manageModel;

// default package

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * 
 * @classDescription:管理员类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: Admin.java
 */
@Entity
@Table(name = "wslm_admin", catalog = "wslm_manage")
public class Admin implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -6573132983921078220L;
	private Long adminId;// id
	private Long createTime;// *创建时间
	private String email;// *邮箱
	private String lastLoginArea;// 最后登录地区
	private String lastLoginCity;// 最后登录城市
	private String lastLoginCounty;// 最后登录国家
	private String lastLoginIsp;// 最后登录运营商
	private Integer manageCity;// *地区管理员管理地方
	private String name;// *登录名
	private String password;// *密码
	private String realName;// *真实姓名
	private Boolean status;// *账号是否被冻结
	private Short type;// *管理员类型（1超级管理员，2地区管理员，3普通管理员）
	private Long lastTime;// *最后登录时间
	private Long modificationTime;// 最后修改时间

	private Set<Role> roles = new HashSet<Role>(0);

	// Constructors

	/** default constructor */
	public Admin() {
	}

	/** minimal constructor */
	public Admin(Long adminId, Long createTime, String name, String password,
			String realName, Boolean status, Short type, Long lastTime) {
		this.adminId = adminId;
		this.createTime = createTime;
		this.name = name;
		this.password = password;
		this.realName = realName;
		this.status = status;
		this.type = type;
		this.lastTime = lastTime;
	}

	/** full constructor */
	public Admin(Long adminId, Long createTime, String email,
			String lastLoginArea, String lastLoginCity, String lastLoginCounty,
			String lastLoginIsp, Integer manageCity, String name,
			String password, String realName, Boolean status, Short type,
			Long lastTime, Set<Role> roles) {
		this.adminId = adminId;
		this.createTime = createTime;
		this.email = email;
		this.lastLoginArea = lastLoginArea;
		this.lastLoginCity = lastLoginCity;
		this.lastLoginCounty = lastLoginCounty;
		this.lastLoginIsp = lastLoginIsp;
		this.manageCity = manageCity;
		this.name = name;
		this.password = password;
		this.realName = realName;
		this.status = status;
		this.type = type;
		this.lastTime = lastTime;
		this.roles = roles;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "admin_id", unique = true, nullable = false)
	public Long getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	@Column(name = "createTime", nullable = false, length = 50)
	public Long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	@Column(name = "email", length = 100)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "last_login_area", length = 100)
	public String getLastLoginArea() {
		return this.lastLoginArea;
	}

	public void setLastLoginArea(String lastLoginArea) {
		this.lastLoginArea = lastLoginArea;
	}

	@Column(name = "last_login_city", length = 100)
	public String getLastLoginCity() {
		return this.lastLoginCity;
	}

	public void setLastLoginCity(String lastLoginCity) {
		this.lastLoginCity = lastLoginCity;
	}

	@Column(name = "last_login_county", length = 100)
	public String getLastLoginCounty() {
		return this.lastLoginCounty;
	}

	public void setLastLoginCounty(String lastLoginCounty) {
		this.lastLoginCounty = lastLoginCounty;
	}

	@Column(name = "last_login_isp", length = 100)
	public String getLastLoginIsp() {
		return this.lastLoginIsp;
	}

	public void setLastLoginIsp(String lastLoginIsp) {
		this.lastLoginIsp = lastLoginIsp;
	}

	@Column(name = "manageCity")
	public Integer getManageCity() {
		return this.manageCity;
	}

	public void setManageCity(Integer manageCity) {
		this.manageCity = manageCity;
	}

	@Column(name = "name", nullable = false, length = 30)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "password", nullable = false, length = 32)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "realName", nullable = false, length = 30)
	public String getRealName() {
		return this.realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	@Column(name = "status", nullable = false)
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Column(name = "type", nullable = false)
	public Short getType() {
		return this.type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	@Column(name = "lastTime")
	public Long getLastTime() {
		return this.lastTime;
	}

	public void setLastTime(Long lastTime) {
		this.lastTime = lastTime;
	}

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "admins")
	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
	
	@Column(name = "modificationTime", nullable = false, length = 50)
	public Long getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(Long modificationTime) {
		this.modificationTime = modificationTime;
	}

}
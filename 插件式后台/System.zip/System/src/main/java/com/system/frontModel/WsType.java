package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsType entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_type", catalog = "wslm")
public class WsType implements java.io.Serializable {

	// Fields

	private Integer typeId;
	private String typeName;
	private Integer pid;
	private Boolean isOn;
	private Boolean sort;
	private String path;

	// Constructors

	/** default constructor */
	public WsType() {
	}

	/** minimal constructor */
	public WsType(String typeName, Integer pid, Boolean isOn, Boolean sort) {
		this.typeName = typeName;
		this.pid = pid;
		this.isOn = isOn;
		this.sort = sort;
	}

	/** full constructor */
	public WsType(String typeName, Integer pid, Boolean isOn, Boolean sort,
			String path) {
		this.typeName = typeName;
		this.pid = pid;
		this.isOn = isOn;
		this.sort = sort;
		this.path = path;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "type_id", unique = true, nullable = false)
	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	@Column(name = "type_name", nullable = false, length = 45)
	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	@Column(name = "pid", nullable = false)
	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	@Column(name = "is_on", nullable = false)
	public Boolean getIsOn() {
		return this.isOn;
	}

	public void setIsOn(Boolean isOn) {
		this.isOn = isOn;
	}

	@Column(name = "sort", nullable = false)
	public Boolean getSort() {
		return this.sort;
	}

	public void setSort(Boolean sort) {
		this.sort = sort;
	}

	@Column(name = "path", length = 100)
	public String getPath() {
		return this.path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
package com.system.manageModel;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @classDescription:权限类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: Authority.java
 */
@Entity
@Table(name = "wslm_authority", catalog = "wslm_manage")
public class Authority implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -142023759765368203L;
	private Integer authorityId;// id
	private Boolean isMenu;// 是否菜单项  （true菜单，false权限）
	private String name;// 名字
	private String permissonCode;// 权限类型(CRUD)
	private Boolean status;// 是否冻结 (true激活，false冻结)
	private String url;// 路径
	private int type;//请求类型(0是所有请求都可以，1是get请求，2是post请求)
	private Long createTime;// 创建时间
	private Long modificationTime;// 最后修改时间

	private Menu menu;
	private Set<Role> roles = new HashSet<Role>(0);

	// Constructors

	/** default constructor */
	public Authority() {
	}

	/** minimal constructor */
	public Authority(Integer authorityId, Menu menu, Boolean isMenu,
			String name, String permissonCode, Boolean status, String url,
			Long createTime) {
		this.authorityId = authorityId;
		this.menu = menu;
		this.isMenu = isMenu;
		this.name = name;
		this.permissonCode = permissonCode;
		this.status = status;
		this.url = url;
		this.createTime = createTime;
	}

	/** full constructor */
	public Authority(Integer authorityId, Menu menu, Boolean isMenu,
			String name, String permissonCode, Boolean status, String url,
			Long createTime, Set<Role> roles) {
		this.authorityId = authorityId;
		this.menu = menu;
		this.isMenu = isMenu;
		this.name = name;
		this.permissonCode = permissonCode;
		this.status = status;
		this.url = url;
		this.createTime = createTime;
		this.roles = roles;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "authority_id", unique = true, nullable = false)
	public Integer getAuthorityId() {
		return this.authorityId;
	}

	public void setAuthorityId(Integer authorityId) {
		this.authorityId = authorityId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "menu_id")
	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	@Column(name = "isMenu", nullable = false)
	public Boolean getIsMenu() {
		return this.isMenu;
	}

	public void setIsMenu(Boolean isMenu) {
		this.isMenu = isMenu;
	}

	@Column(name = "name", nullable = false, length = 50)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "permissonCode", nullable = false, length = 1)
	public String getPermissonCode() {
		return this.permissonCode;
	}

	public void setPermissonCode(String permissonCode) {
		this.permissonCode = permissonCode;
	}

	@Column(name = "status", nullable = false)
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Column(name = "url", nullable = false, length = 200)
	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "createTime", nullable = false)
	public Long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "authorities")
	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	@Column(name = "modificationTime", nullable = false)
	public Long getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(Long modificationTime) {
		this.modificationTime = modificationTime;
	}
	@Column(name = "type", nullable = false,length=5)
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
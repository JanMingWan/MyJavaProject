package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsUserJob entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_user_job", catalog = "wslm")
public class WsUserJob implements java.io.Serializable {

	// Fields

	private Integer jobId;
	private String jobName;

	// Constructors

	/** default constructor */
	public WsUserJob() {
	}

	/** full constructor */
	public WsUserJob(String jobName) {
		this.jobName = jobName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "job_id", unique = true, nullable = false)
	public Integer getJobId() {
		return this.jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	@Column(name = "job_name", nullable = false, length = 45)
	public String getJobName() {
		return this.jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
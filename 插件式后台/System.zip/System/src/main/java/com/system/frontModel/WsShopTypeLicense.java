package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopTypeLicense entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_type_license", catalog = "wslm")
public class WsShopTypeLicense implements java.io.Serializable {

	// Fields

	private Integer typeLicenseId;
	private Integer typeId;
	private String license;

	// Constructors

	/** default constructor */
	public WsShopTypeLicense() {
	}

	/** full constructor */
	public WsShopTypeLicense(Integer typeId, String license) {
		this.typeId = typeId;
		this.license = license;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "type_license_id", unique = true, nullable = false)
	public Integer getTypeLicenseId() {
		return this.typeLicenseId;
	}

	public void setTypeLicenseId(Integer typeLicenseId) {
		this.typeLicenseId = typeLicenseId;
	}

	@Column(name = "type_id", nullable = false)
	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	@Column(name = "license", nullable = false, length = 20)
	public String getLicense() {
		return this.license;
	}

	public void setLicense(String license) {
		this.license = license;
	}

}
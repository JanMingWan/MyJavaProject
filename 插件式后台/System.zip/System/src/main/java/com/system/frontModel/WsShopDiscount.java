package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopDiscount entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_discount", catalog = "wslm")
public class WsShopDiscount implements java.io.Serializable {

	// Fields

	private Integer discountId;
	private Integer termId;
	private String term;
	private Integer favorableId;
	private String favorable;
	private Integer shopId;
	private String discountContent;

	// Constructors

	/** default constructor */
	public WsShopDiscount() {
	}

	/** full constructor */
	public WsShopDiscount(Integer termId, String term, Integer favorableId,
			String favorable, Integer shopId, String discountContent) {
		this.termId = termId;
		this.term = term;
		this.favorableId = favorableId;
		this.favorable = favorable;
		this.shopId = shopId;
		this.discountContent = discountContent;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "discount_id", unique = true, nullable = false)
	public Integer getDiscountId() {
		return this.discountId;
	}

	public void setDiscountId(Integer discountId) {
		this.discountId = discountId;
	}

	@Column(name = "term_id", nullable = false)
	public Integer getTermId() {
		return this.termId;
	}

	public void setTermId(Integer termId) {
		this.termId = termId;
	}

	@Column(name = "term", nullable = false, length = 20)
	public String getTerm() {
		return this.term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	@Column(name = "favorable_id", nullable = false)
	public Integer getFavorableId() {
		return this.favorableId;
	}

	public void setFavorableId(Integer favorableId) {
		this.favorableId = favorableId;
	}

	@Column(name = "favorable", nullable = false, length = 20)
	public String getFavorable() {
		return this.favorable;
	}

	public void setFavorable(String favorable) {
		this.favorable = favorable;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "discount_content", nullable = false, length = 20)
	public String getDiscountContent() {
		return this.discountContent;
	}

	public void setDiscountContent(String discountContent) {
		this.discountContent = discountContent;
	}

}
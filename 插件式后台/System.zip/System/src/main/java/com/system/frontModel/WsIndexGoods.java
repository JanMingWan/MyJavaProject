package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsIndexGoods entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_index_goods", catalog = "wslm")
public class WsIndexGoods implements java.io.Serializable {

	// Fields

	private Integer indexGoodsId;
	private String imagePath;
	private String url;
	private String sn;
	private String goodsName;

	// Constructors

	/** default constructor */
	public WsIndexGoods() {
	}

	/** minimal constructor */
	public WsIndexGoods(String imagePath, String url, String sn) {
		this.imagePath = imagePath;
		this.url = url;
		this.sn = sn;
	}

	/** full constructor */
	public WsIndexGoods(String imagePath, String url, String sn,
			String goodsName) {
		this.imagePath = imagePath;
		this.url = url;
		this.sn = sn;
		this.goodsName = goodsName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "index_goods_id", unique = true, nullable = false)
	public Integer getIndexGoodsId() {
		return this.indexGoodsId;
	}

	public void setIndexGoodsId(Integer indexGoodsId) {
		this.indexGoodsId = indexGoodsId;
	}

	@Column(name = "image_path", nullable = false, length = 100)
	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Column(name = "url", nullable = false, length = 100)
	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "sn", nullable = false, length = 10)
	public String getSn() {
		return this.sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	@Column(name = "goods_name", length = 50)
	public String getGoodsName() {
		return this.goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

}
package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopColumn entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_column", catalog = "wslm")
public class WsShopColumn implements java.io.Serializable {

	// Fields

	private Integer columnId;
	private String columnName;
	private Integer shopId;
	private Integer pid;
	private Integer sort;
	private Boolean isOn;

	// Constructors

	/** default constructor */
	public WsShopColumn() {
	}

	/** minimal constructor */
	public WsShopColumn(String columnName, Integer shopId, Integer pid,
			Integer sort) {
		this.columnName = columnName;
		this.shopId = shopId;
		this.pid = pid;
		this.sort = sort;
	}

	/** full constructor */
	public WsShopColumn(String columnName, Integer shopId, Integer pid,
			Integer sort, Boolean isOn) {
		this.columnName = columnName;
		this.shopId = shopId;
		this.pid = pid;
		this.sort = sort;
		this.isOn = isOn;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "column_id", unique = true, nullable = false)
	public Integer getColumnId() {
		return this.columnId;
	}

	public void setColumnId(Integer columnId) {
		this.columnId = columnId;
	}

	@Column(name = "column_name", nullable = false, length = 45)
	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "pid", nullable = false)
	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	@Column(name = "sort", nullable = false)
	public Integer getSort() {
		return this.sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	@Column(name = "is_on")
	public Boolean getIsOn() {
		return this.isOn;
	}

	public void setIsOn(Boolean isOn) {
		this.isOn = isOn;
	}

}
package com.system.manageService.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.manageDao.IAdminDao;
import com.system.manageDao.IAuthorityDao;
import com.system.manageDao.IRoleDao;
import com.system.manageModel.Admin;
import com.system.manageModel.Authority;
import com.system.manageModel.Role;
import com.system.manageModelDriven.RoleModelDriven;
import com.system.manageService.IRoleService;
import com.system.util.date.DateUtil;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:role业务权限
 * @author: 王嘉明
 * @cerateTime: 2013-12-3
 * @className: RoleServiceImpl.java
 */
@Service
public class RoleServiceImpl implements IRoleService {
	/**
	 * 添加role
	 */
	@Autowired
	IRoleDao roleDao;

	@Autowired
	IAuthorityDao authorityDao;

	@Autowired
	IAdminDao adminDao;
	/**
	 * 保存
	 */
	@Override
	public void save(RoleModelDriven roleModelDriven) {
		Role role = new Role();
		role.setName(roleModelDriven.getName());
		long time = DateUtil.getTime();
		role.setCreateTime(time);
		role.setModificationTime(time);
		roleDao.save(role, true);
	}

	/**
	 * 删除
	 */
	@Override
	public void delete(RoleModelDriven roleModelDriven) {
		String[] roleId = roleModelDriven.getRoleId().split(",");
		Map<String, Object> params = new HashMap<String, Object>(1);
		for (int i = 0; i < roleId.length; i++) {// 循环id
			params.put("id", Integer.parseInt(roleId[i]));
			String hql = "from Role role where role.roleId=:id";
			Role role = roleDao.get(hql, params, true);
			roleDao.delete(role, true);
		}
	}

	/**
	 * 更新
	 */
	@Override
	public void update(RoleModelDriven roleModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("id", roleModelDriven.getRoleId());
		Role role = roleDao.get("from Role role where role.roleId=:id", params,
				true);
		role.setName(roleModelDriven.getName());
		role.setModificationTime(DateUtil.getTime());
		roleDao.update(role, true);

	}

	/**
	 * 获取对象
	 */
	@Override
	public Role get(RoleModelDriven roleModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("id", Integer.parseInt(roleModelDriven.getRoleId()));
		return roleDao
				.get("from Role role where role.roleId=:id", params, true);
	}

	/**
	 * 查询所有角色
	 */
	@Override
	public Page<Role> findAll(String forwordName,
			RoleModelDriven roleModelDriven) {
		Page<Role> role_Page = new Page<Role>(25, forwordName,
				roleModelDriven.getSort());// 设置分页
		roleDao.count(role_Page, "select count(*) from Role", null, true);// 记录总条数
		if (roleModelDriven.getPageNo() != null
				&& roleModelDriven.getPageNo().equals("")) {// 设置当前分页
			role_Page.setPageNo(Integer.parseInt(roleModelDriven.getPageNo()));
		}
		String hql = "from Role r order by r.createTime "
				+ roleModelDriven.getSort();
		roleDao.findAll(role_Page, hql, null, true);
		return role_Page;
	}

	@Override
	public Page<Role> search(String forwordName, RoleModelDriven roleModelDriven) {
		Page<Role> role_Page = new Page<Role>(25, forwordName,roleModelDriven.getSort());// 设置分页
		if (roleModelDriven.getName() != null
				&& !roleModelDriven.getName().equals("")) {// 参数不为空情况
			Map<String, Object> params = new HashMap<String, Object>(1);
			params.put("name", "%" + roleModelDriven.getName() + "%");
			roleDao.count(
					role_Page,
					"select count(*) from Role role where role.name like :name",
					params, true);
			if (roleModelDriven.getPageNo() != null
					&&!roleModelDriven.getPageNo().equals("")) {
				role_Page.setPageNo(Integer.parseInt(roleModelDriven
						.getPageNo()));// 设置当前页数
			}
			String hql = "from Role role where role.name like :name order by role.createTime "
					+ roleModelDriven.getSort();
			roleDao.findAll(role_Page, hql, params, true);
		} else {
			roleDao.count(role_Page, "select count(*) from Role", null, true);
			if (roleModelDriven.getPageNo() != null
					&& !roleModelDriven.equals("")) {
				role_Page.setPageNo(Integer.parseInt(roleModelDriven
						.getPageNo()));
			}
			String hql = "from Role role order by role.createTime "
					+ roleModelDriven.getSort();
			roleDao.findAll(role_Page, hql, null, true);

		}
		return role_Page;
	}

	@Override
	public boolean checkRoleName(RoleModelDriven roleModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("name", roleModelDriven.getName());
		List<Role> roles = roleDao.findAll("from Role r where r.name=:name",
				params, true);
		if (roles.size() > 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 获取所有权限
	 */
	@Override
	public List<Authority> getSurplusAuthority(Set<Authority> roleAuthority) {
		List<Authority> allAuthority = authorityDao.findAll("from Authority",
				null, true);
		allAuthority.removeAll(roleAuthority);
		return allAuthority;
	}

	/**
	 * 获取role的权限
	 */
	@Override
	public Set<Authority> getAuthorityList(Role role) {
		return role.getAuthorities();
	}

	/**
	 * 更新权限
	 * 
	 * 把旧的关联删除掉，重设所有角色权限关联
	 */
	@Override
	public void updateRoleAuthority(RoleModelDriven roleModelDriven) {
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("roleId", Integer.parseInt(roleModelDriven.getRoleId()));
		Role role = roleDao.get("from Role role where role.roleId=:roleId",
				params, true);// 获取该角色
		// Set<Authority> existingAuthority=role.getAuthorities();//获取该角色已有权限
		role.setAuthorities(null);
		roleDao.update(role, true);// 取消关联
		params.remove("roleId");// 移除参数
		// 判断roleModelDriven.getAuthroityId()是否null
		if (roleModelDriven.getAuthroityId() != null&& !roleModelDriven.getAuthroityId().equals("")) {
			//分割参数
			String[] authorityId = roleModelDriven.getAuthroityId().split(",");// 获取所选的authorityId
			Set<Authority> selectAuthority = new HashSet<Authority>();// 选中的Authority集合
			for (int i = 0; i < authorityId.length; i++) {//循环参数
				params.put("authorityId",Integer.parseInt(authorityId[i].trim()));// 去除空格添加参数
				selectAuthority.add(authorityDao.get("from Authority a where a.authorityId=:authorityId",params, true));// 搜索对象放进集合
			}
			role.setAuthorities(selectAuthority);
			roleDao.update(role, true);
			// 删除所选以后的权限
		}
		
	}
    /**
     * 剩余管理员
     */
	@Override
	public List<Admin> getSurplusAdmin(Set<Admin> admin) {
		List<Admin>suplusAdmin=adminDao.findAll("from Admin", null,true);
		suplusAdmin.removeAll(admin);
		return suplusAdmin;
	}
    /**
     * 更新角色管理员
     */
	@Override
	public void updateRoleAdmin(RoleModelDriven roleModelDriven) {
       Role role=get(roleModelDriven);
       role.setAdmins(null);
       roleDao.update(role, true);
		if (roleModelDriven.getAdminId() != null
				&& !roleModelDriven.getAdminId().equals("")) {
			Map<String, Object> params = new HashMap<String, Object>();
			String[] adminId = roleModelDriven.getAdminId().split(",");
			Set<Admin> selectAdmin = new HashSet<Admin>();
			for (int i = 0; i < adminId.length; i++) {
				params.put("id", Long.valueOf(adminId[i].trim()));
				selectAdmin.add(adminDao.get(
						"from Admin admin where admin.adminId=:id", params,
						true));
			}
			role.setAdmins(selectAdmin);
			roleDao.update(role, true);
		}
	}
}

package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsOrderGoods entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_order_goods", catalog = "wslm")
public class WsOrderGoods implements java.io.Serializable {

	// Fields

	private Integer orderGoodsId;
	private Integer orderId;
	private Integer goodsId;
	private Integer num;
	private Double price;
	private Double payPrice;
	private Integer matchId;
	private String matchName;

	// Constructors

	/** default constructor */
	public WsOrderGoods() {
	}

	/** minimal constructor */
	public WsOrderGoods(Integer orderId, Integer goodsId, Integer num,
			Double price, Double payPrice, Integer matchId) {
		this.orderId = orderId;
		this.goodsId = goodsId;
		this.num = num;
		this.price = price;
		this.payPrice = payPrice;
		this.matchId = matchId;
	}

	/** full constructor */
	public WsOrderGoods(Integer orderId, Integer goodsId, Integer num,
			Double price, Double payPrice, Integer matchId, String matchName) {
		this.orderId = orderId;
		this.goodsId = goodsId;
		this.num = num;
		this.price = price;
		this.payPrice = payPrice;
		this.matchId = matchId;
		this.matchName = matchName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "order_goods_id", unique = true, nullable = false)
	public Integer getOrderGoodsId() {
		return this.orderGoodsId;
	}

	public void setOrderGoodsId(Integer orderGoodsId) {
		this.orderGoodsId = orderGoodsId;
	}

	@Column(name = "order_id", nullable = false)
	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	@Column(name = "goods_id", nullable = false)
	public Integer getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "num", nullable = false)
	public Integer getNum() {
		return this.num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	@Column(name = "price", nullable = false, precision = 10)
	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Column(name = "pay_price", nullable = false, precision = 10)
	public Double getPayPrice() {
		return this.payPrice;
	}

	public void setPayPrice(Double payPrice) {
		this.payPrice = payPrice;
	}

	@Column(name = "match_id", nullable = false)
	public Integer getMatchId() {
		return this.matchId;
	}

	public void setMatchId(Integer matchId) {
		this.matchId = matchId;
	}

	@Column(name = "match_name", length = 100)
	public String getMatchName() {
		return this.matchName;
	}

	public void setMatchName(String matchName) {
		this.matchName = matchName;
	}

}
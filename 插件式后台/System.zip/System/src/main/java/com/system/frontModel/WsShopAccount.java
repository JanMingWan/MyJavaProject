package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * WsShopAccount entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_account", catalog = "wslm", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class WsShopAccount implements java.io.Serializable {

	// Fields

	private Integer accountId;
	private String email;
	private String password;
	private Integer registerTime;
	private String phone;
	private String lastIp;
	private Integer lastLogin;
	private Boolean isOn;
	private String ownerName;
	private String ownerPhone;
	private String idCard;
	private String bankAccountName;
	private String bankName;
	private String bankAccount;
	private String alipayAccount;
	private String wsNum;

	// Constructors

	/** default constructor */
	public WsShopAccount() {
	}

	/** minimal constructor */
	public WsShopAccount(String password, Integer registerTime, Boolean isOn,
			String wsNum) {
		this.password = password;
		this.registerTime = registerTime;
		this.isOn = isOn;
		this.wsNum = wsNum;
	}

	/** full constructor */
	public WsShopAccount(String email, String password, Integer registerTime,
			String phone, String lastIp, Integer lastLogin, Boolean isOn,
			String ownerName, String ownerPhone, String idCard,
			String bankAccountName, String bankName, String bankAccount,
			String alipayAccount, String wsNum) {
		this.email = email;
		this.password = password;
		this.registerTime = registerTime;
		this.phone = phone;
		this.lastIp = lastIp;
		this.lastLogin = lastLogin;
		this.isOn = isOn;
		this.ownerName = ownerName;
		this.ownerPhone = ownerPhone;
		this.idCard = idCard;
		this.bankAccountName = bankAccountName;
		this.bankName = bankName;
		this.bankAccount = bankAccount;
		this.alipayAccount = alipayAccount;
		this.wsNum = wsNum;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "account_id", unique = true, nullable = false)
	public Integer getAccountId() {
		return this.accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	@Column(name = "email", unique = true, length = 60)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "password", nullable = false, length = 32)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "register_time", nullable = false)
	public Integer getRegisterTime() {
		return this.registerTime;
	}

	public void setRegisterTime(Integer registerTime) {
		this.registerTime = registerTime;
	}

	@Column(name = "phone", length = 11)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "last_ip", length = 15)
	public String getLastIp() {
		return this.lastIp;
	}

	public void setLastIp(String lastIp) {
		this.lastIp = lastIp;
	}

	@Column(name = "last_login")
	public Integer getLastLogin() {
		return this.lastLogin;
	}

	public void setLastLogin(Integer lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Column(name = "is_on", nullable = false)
	public Boolean getIsOn() {
		return this.isOn;
	}

	public void setIsOn(Boolean isOn) {
		this.isOn = isOn;
	}

	@Column(name = "owner_name", length = 20)
	public String getOwnerName() {
		return this.ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	@Column(name = "owner_phone", length = 11)
	public String getOwnerPhone() {
		return this.ownerPhone;
	}

	public void setOwnerPhone(String ownerPhone) {
		this.ownerPhone = ownerPhone;
	}

	@Column(name = "id_card", length = 18)
	public String getIdCard() {
		return this.idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	@Column(name = "bank_account_name", length = 20)
	public String getBankAccountName() {
		return this.bankAccountName;
	}

	public void setBankAccountName(String bankAccountName) {
		this.bankAccountName = bankAccountName;
	}

	@Column(name = "bank_name", length = 50)
	public String getBankName() {
		return this.bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Column(name = "bank_account", length = 30)
	public String getBankAccount() {
		return this.bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	@Column(name = "alipay_account", length = 60)
	public String getAlipayAccount() {
		return this.alipayAccount;
	}

	public void setAlipayAccount(String alipayAccount) {
		this.alipayAccount = alipayAccount;
	}

	@Column(name = "ws_num", nullable = false, length = 11)
	public String getWsNum() {
		return this.wsNum;
	}

	public void setWsNum(String wsNum) {
		this.wsNum = wsNum;
	}

}
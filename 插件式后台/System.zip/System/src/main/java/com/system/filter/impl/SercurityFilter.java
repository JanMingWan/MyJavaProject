package com.system.filter.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;

import com.system.filter.ISercurityFilter;
import com.system.manageModel.Admin;
import com.system.manageModel.Authority;
import com.system.manageService.IAdminService;
import com.system.manageService.IAuthorityService;

/**
 * 
 * @classDescription:安全拦截器
 * @author: 王嘉明
 * @cerateTime: 2013-12-8
 * @className: SercurityFilter.java
 */
public class SercurityFilter extends HttpServlet implements Filter,
		ISercurityFilter {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4172541808196406632L;
	private ServletContext config;// 上下文
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger
			.getLogger(SercurityFilter.class);

	/**
	 * 主拦截器
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String url = httpRequest.getServletPath();// 获取url
		if (skipMethod(url)) {// 检查是否登录方法-是的话放行
			chain.doFilter(request, response);// 登录方法跳过校验
		} else {// 若果不是登录方法
			@SuppressWarnings("unchecked")
			List<Authority> authorities = (List<Authority>) config
					.getAttribute("authorities");// 获取application
			if (authorities != null) {// 判断内置权限是否为空
				Authority authority = null;
				for (Authority aut : authorities) {// 遍历权限
					if (url.equalsIgnoreCase(aut.getUrl())) {// 检查有无保存的权限
						authority = aut;
						break;
					}
				}
				if (authority != null) {// 判断遍历的
					doAdminAuthorities(request, response, chain, authority);//
				} else {
					redirectLogin(request, response);// 重定向主页
				}
			} else {
				redirectLogin(request, response);// 重定向主页
			}
		}
		// 通过
		// chain.doFilter(request, response);
	}

	/**
	 * 初始化安全拦截器拦截器
	 */
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		this.config = arg0.getServletContext();
		logger.info("-----------正在启动安全盾-----------");
		logger.info("-----------开始载入权限集-----------");
		WebApplicationContext applicationContext = (WebApplicationContext) config
				.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
		IAuthorityService authorityService = applicationContext.getBean(
				"authorityServiceImpl", IAuthorityService.class);
		List<Authority> authorities = authorityService.findAll();
		config.setAttribute("authorities", authorities);
		logger.info("-----------成功载入" + authorities.size() + "条权限-----------");
		logger.info("-----------成功启动安全盾-----------");
	}

	/**
	 * 管理员权限判断
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAdminAuthorities(ServletRequest request,
			ServletResponse response, FilterChain chain, Authority authority)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		Admin admin = (Admin) req.getSession().getAttribute("admin");
		if (admin != null) {// session是否为空
			WebApplicationContext applicationContext = (WebApplicationContext) config
					.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
			IAdminService adminService = applicationContext.getBean(
					"adminServiceImpl", IAdminService.class);
			List<Authority> adminAuthority = adminService.get(admin
					.getAdminId());
			if (!adminAuthority.isEmpty()) {// adminAuthority
				boolean isPass = true;
				for (Authority aut : adminAuthority) {
					if (aut.getUrl().equalsIgnoreCase(authority.getUrl())) {
						isPass = false;
						chain.doFilter(request, response);// 通过
						break;
					}
				}
				if (isPass) {// 不拥有权限
					redirectLogin(request, response);// 重定向
				}
			} else {
				redirectLogin(request, response);// 重定向
			}
		} else {// admin为空重定向login
			redirectLogin(request, response);// 重定向
		}
	}

	/**
	 * 销毁
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/**
	 * 不需要拦截的方法 暂时只有登录方法可以不用拦截
	 * 
	 * @return
	 */
	@Override
	public boolean skipMethod(String url) {
		if (url.equalsIgnoreCase("/manageAdmin/admin!login.action")) {// 跳过登录方法
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 重定向登录页面
	 */
	@Override
	public void redirectLogin(ServletRequest request, ServletResponse response) {
		// TODO Auto-generated method stub
		try {
			HttpServletRequest req = (HttpServletRequest) request;
			req.getSession().invalidate();// 烧毁session内容
			PrintWriter out = response.getWriter();
			out.write("<script>window.parent.location.href='"
					+ req.getContextPath() + "/login.jsp';</script>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

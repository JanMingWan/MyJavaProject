package com.system.util.jsonUtil;
/**
 * 
 * @classDescription:json类
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: Json.java
 */
public class Json {
	private boolean success = false;//状态
	private String msg = "";//提示
	private Object obj = null;//类

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

}

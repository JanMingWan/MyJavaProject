package com.system.manageDao;

import com.system.base.IBaseDao;
import com.system.manageModel.Admin;
/**
 * 后台WsAdminDao接口
 * 
 * @author 王嘉明
 * @createTime:2013/11/18
 * @param <T>
 */
public interface IAdminDao extends IBaseDao<Admin>{

}

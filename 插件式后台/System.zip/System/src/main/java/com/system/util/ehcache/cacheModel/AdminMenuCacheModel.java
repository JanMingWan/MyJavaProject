package com.system.util.ehcache.cacheModel;

import java.util.ArrayList;
import java.util.List;

import com.system.manageModel.Authority;
import com.system.manageModel.Menu;

/**
 * 
 * @classDescription: 管理员菜单缓存
 * @author: 王嘉明
 * @cerateTime: 2013-12-11
 * @className: AdminCacheModel.java
 */
public class AdminMenuCacheModel {
	private List<Authority> authority = new ArrayList<Authority>();// 二级菜单
	private List<Menu> menu = new ArrayList<Menu>();// 顶级菜单

	public List<Authority> getAuthority() {
		return authority;
	}

	public void setAuthority(List<Authority> authority) {
		this.authority = authority;
	}

	public List<Menu> getMenu() {
		return menu;
	}

	public void setMenu(List<Menu> menu) {
		this.menu = menu;
	}

}

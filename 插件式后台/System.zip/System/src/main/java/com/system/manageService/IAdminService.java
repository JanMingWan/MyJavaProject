package com.system.manageService;

import java.util.List;

import com.system.base.IBaseService;
import com.system.manageModel.Admin;
import com.system.manageModel.Authority;
import com.system.manageModelDriven.AdminModelDriven;
import com.system.util.ehcache.cacheModel.AdminMenuCacheModel;

/**
 * AdminService业务接口
 * 
 * @author 王嘉明
 * @createTime 2013/11/22
 */
public interface IAdminService extends IBaseService<Admin, AdminModelDriven> {
	/**
	 * 后台登录接口
	 * 
	 * @param adminModelDriven
	 *            驱动模型
	 * @param login_IP
	 *            登录ip
	 * @return
	 */
	public Admin login(AdminModelDriven adminModelDriven, String login_IP);

	/**
	 * 校验登录名是否已存在
	 * 
	 * @param adminModelDriven
	 * @return
	 */
	public boolean checkName(AdminModelDriven adminModelDriven);

	/**
	 * 校验真实姓名是否已存在
	 * 
	 * @param adminModelDriven
	 * @return
	 */
	public boolean checkRealName(AdminModelDriven adminModelDriven);

	/**
	 * 初始化密码
	 * 
	 * @param adminModelDriven
	 */
	public void initializePassword(AdminModelDriven adminModelDriven);

	/**
	 * 获取admin对象
	 * 
	 * @param id
	 */
	public List<Authority> get(Long id);

	/**
	 * 获取该管理员目录
	 * @param admin
	 * @return
	 */
	public AdminMenuCacheModel getMenu(Admin admin);
}

package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsAdminAction entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_admin_action", catalog = "wslm")
public class WsAdminAction implements java.io.Serializable {

	// Fields

	private Short actionId;
	private Short parentId;
	private String actionCode;
	private String actionName;

	// Constructors

	/** default constructor */
	public WsAdminAction() {
	}

	/** full constructor */
	public WsAdminAction(Short parentId, String actionCode, String actionName) {
		this.parentId = parentId;
		this.actionCode = actionCode;
		this.actionName = actionName;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "action_id", unique = true, nullable = false)
	public Short getActionId() {
		return this.actionId;
	}

	public void setActionId(Short actionId) {
		this.actionId = actionId;
	}

	@Column(name = "parent_id", nullable = false)
	public Short getParentId() {
		return this.parentId;
	}

	public void setParentId(Short parentId) {
		this.parentId = parentId;
	}

	@Column(name = "action_code", nullable = false, length = 20)
	public String getActionCode() {
		return this.actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	@Column(name = "action_name", nullable = false, length = 50)
	public String getActionName() {
		return this.actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

}
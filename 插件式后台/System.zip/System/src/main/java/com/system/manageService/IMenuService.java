package com.system.manageService;

import com.system.base.IBaseService;
import com.system.manageModel.Authority;
import com.system.manageModel.Menu;
import com.system.manageModelDriven.MenuModelDriven;
import com.system.util.page.Page;

/**
 * 
 * @classDescription:菜单业务接口
 * @author: 王嘉明
 * @cerateTime: 2013-11-27
 * @className: IMenuService.java
 */
public interface IMenuService extends IBaseService<Menu, MenuModelDriven> {
	/**
	 * 检查名字
	 * 
	 * @param menuModelDriven
	 * @return 成功true 失败false
	 */
	public boolean checkMenuName(MenuModelDriven menuModelDriven);
	/**
	 * 获取二级菜单
	 * @param forwordName
	 * @param menuModelDriven
	 * @return
	 */
	public Page<Authority> getAuthorityList(String forwordName,
			MenuModelDriven menuModelDriven) ;
}

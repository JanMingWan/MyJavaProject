package com.system.base;

import java.util.List;
import java.util.Map;

import com.system.util.page.Page;

/**
 * 后台BaseDao接口，所有Dao必须继承这个Dao进行拓展
 * 
 * @author 王嘉明
 * @createTime:2013/11/18
 */
public interface IBaseDao<T> {
	/**
	 * 保存
	 * 
	 * @param object
	 * @param type
	 *            session类型 true后台session，false为前台session
	 */
	public void save(T object, boolean type);

	/**
	 * 删除
	 * 
	 * @param object
	 * @param type
	 *            session类型 true后台session，false为前台session 
	 */
	public void delete(T object, boolean type);

	/**
	 * 更新
	 * 
	 * @param object
	 * @param type
	 *            session类型 true后台session，false为前台session
	 */
	public void update(T object, boolean type);

	/**
	 * 获取对象
	 * 
	 * @param hql
	 *            语句
	 * @param params
	 *            占位参数 (若没设为null)
	 * @param type
	 *            session类型 true后台session，false为前台session
	 * @return
	 */
	public T get(String hql, Map<String, Object> params, boolean type);

	/**
	 * 保存或更新
	 * 
	 * @param object
	 * @param type
	 *            session类型 true后台session，false为前台session
	 */
	public void saveOrUpdate(T object, boolean type);

	/**
	 * 无分页查询集合
	 * 
	 * @param hql
	 *            语句
	 * @param params
	 *            占位参数 (若没设为null)
	 * @param type
	 *            session类型 true后台session，false为前台session
	 * @return
	 */
	public List<T> findAll(String hql, Map<String, Object> params, boolean type);

	/**
	 * 分页查询
	 * 
	 * @param page
	 *            分页类
	 * @param hql
	 *            语句
	 * @param params
	 *            占位参数 (若没设为null)
	 * @param type
	 *            session类型 true后台session，false为前台session
	 * @return
	 */
	public Page<T> findAll(Page<T> page, String hql,
			Map<String, Object> params, boolean type);

	/**
	 * 分页查询总数量
	 * 
	 * @param page
	 *            分页类
	 * @param hql
	 *            语句
	 * @param params
	 *            占位参数(若没设为null)
	 * @param type
	 *            session类型 true后台session，false为前台session
	 */
	public void count(Page<T> page, String hql, Map<String, Object> params,
			boolean type);
}

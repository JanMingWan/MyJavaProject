package com.system.frontModel;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WsShopLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ws_shop_log", catalog = "wslm")
public class WsShopLog implements java.io.Serializable {

	// Fields

	private Integer logId;
	private String logInfo;
	private Integer logTime;
	private Integer shopId;
	private Integer logType;
	private String ipAddress;

	// Constructors

	/** default constructor */
	public WsShopLog() {
	}

	/** full constructor */
	public WsShopLog(String logInfo, Integer logTime, Integer shopId,
			Integer logType, String ipAddress) {
		this.logInfo = logInfo;
		this.logTime = logTime;
		this.shopId = shopId;
		this.logType = logType;
		this.ipAddress = ipAddress;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "log_id", unique = true, nullable = false)
	public Integer getLogId() {
		return this.logId;
	}

	public void setLogId(Integer logId) {
		this.logId = logId;
	}

	@Column(name = "log_info", nullable = false, length = 100)
	public String getLogInfo() {
		return this.logInfo;
	}

	public void setLogInfo(String logInfo) {
		this.logInfo = logInfo;
	}

	@Column(name = "log_time", nullable = false)
	public Integer getLogTime() {
		return this.logTime;
	}

	public void setLogTime(Integer logTime) {
		this.logTime = logTime;
	}

	@Column(name = "shop_id", nullable = false)
	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	@Column(name = "log_type", nullable = false)
	public Integer getLogType() {
		return this.logType;
	}

	public void setLogType(Integer logType) {
		this.logType = logType;
	}

	@Column(name = "ip_address", nullable = false, length = 15)
	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

}
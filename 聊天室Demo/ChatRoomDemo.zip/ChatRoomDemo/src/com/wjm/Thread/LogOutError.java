package com.wjm.Thread;

import java.util.Date;

import com.wjm.chatBean.User;
import com.wjm.servlet.ChatSession;

/**
 * �̶߳����û�
 * 
 * @author ������
 * 
 */
public class LogOutError implements Runnable {
	private User user;
	private Date logOutDate;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getLogOutDate() {
		return logOutDate;
	}

	public void setLogOutDate(Date logOutDate) {
		this.logOutDate = logOutDate;
	}

	public LogOutError(User user, Date date) {// �вι��캯��
         this.user=user;
         logOutDate=date;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep( 5 * 1000);
			User u=user;
			ChatSession.userList.remove(user);
			u.setLogOutDate(logOutDate);
			ChatSession.userList.add(u);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

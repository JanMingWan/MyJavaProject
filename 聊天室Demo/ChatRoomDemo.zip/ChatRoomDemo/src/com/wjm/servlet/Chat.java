package com.wjm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.wjm.chatBean.ChatContent;
import com.wjm.chatBean.User;
import com.wjm.service.ChatService;
import com.wjm.service.impl.ChatServiceImpl;

@WebServlet(name = "chat", urlPatterns = { "/chat" }, asyncSupported = true)
public class Chat extends HttpServlet {
	public static List<ChatContent> chatContent = new ArrayList<ChatContent>();// ��������

	private ChatService chatService = new ChatServiceImpl();// ҵ����
	private User user;
	/**
	 * 
	 */
	private static final long serialVersionUID = -6877635028390963703L;

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		user = (User) session.getAttribute("user");
		if (request.getParameter("send") != null) {// �û�����������Ϣ
			if (user.getChatType() == 0) {// �����ҹ���
				chatRoom(request, response);
			} else {
				chatPrivacy(request, response);
			}
		}

	}

	/**
	 * ˽��
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void chatPrivacy(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// ����Ϣ
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		String msg = request.getParameter("data");
		chatContent.add(chatService.addContent(msg, user));
		// ��������Լ�δ������
		List<ChatContent> chatContentList = chatService	.checkChatPrivacyEndMessage(user);
		//update�������һ����Ϣ
		ChatContent chatContent=new ChatContent();
		for(ChatContent cc:chatContentList){
			if(chatContent.getId()==null){
				chatContent=cc;
			}else{
				if(chatContent.getId().intValue()<cc.getId().intValue()){
					chatContent=cc;
				}
			}
		}
		user.setContent(chatContent);
		request.getSession().setAttribute("user",user);
		if (!chatContentList.isEmpty()) {	
			PrintWriter out = response.getWriter();
			out.write(chatService.newMessage(chatContentList,user));
			out.close();
		}
	}

	/**
	 * ������
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void chatRoom(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// ������Ϣ
		request.setCharacterEncoding("UTF-8");
		String msg = request.getParameter("data");
		chatContent.add(chatService.addContent(msg, user));

		// ���������յ���Ϣ
		List<ChatContent> c = chatService
				.checkEndChatContent(chatContent, user);
		ChatContent maxChatContent = new ChatContent();
		for (ChatContent cc : c) {
			if (maxChatContent.getId() == null) {
				maxChatContent = cc;
			}
			if (cc.getId().intValue() > maxChatContent.getId().intValue()) {
				maxChatContent = cc;
			}
		}
		user.setContent(maxChatContent);
		HttpSession session = request.getSession();
		session.setAttribute("user", user);

		String message = chatService.newMessage(c,user);

		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		out.write(message);
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

	// ------------------
	public ChatService getChatService() {
		return chatService;
	}

	public void setChatService(ChatService chatService) {
		this.chatService = chatService;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}

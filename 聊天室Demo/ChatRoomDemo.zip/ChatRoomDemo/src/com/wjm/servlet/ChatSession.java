package com.wjm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wjm.Thread.LogOutError;
import com.wjm.chatBean.User;
import com.wjm.service.UserService;
import com.wjm.service.impl.UserServiceImpl;

@WebServlet(name = "chatSession", urlPatterns = { "/chatSession" }, asyncSupported = true)
public class ChatSession extends HttpServlet {
	public static final List<User> userList = new ArrayList<User>();// �û��б�
	private UserService userService = new UserServiceImpl();
	/**
	 * 
	 */
	private static final long serialVersionUID = -6877635028390963703L;

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = null;
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String[] data = request.getParameter("data").split("/");
		boolean checkUser = true;// ����û����Ƿ����
		for (User u : ChatSession.userList) {
			if (u.getName().equals(data[0])) {
				if (u.getLogOutDate() != null||u.getChatType()!=1) {
					user = u;
					ChatSession.userList.remove(u);// �Ƴ��ڴ�Ŀ¼
					user.setChatType(Integer.parseInt(request
							.getParameter("type")));// ��������״̬
					user.setToUser(data[1]);
					ChatSession.userList.add(user);
					request.getSession().setAttribute("user", user);
					checkUser = false;
					out.write("true");
					out.close();
					break;
				} else {
					LogOutError loe=new LogOutError(u, new Date());//�̼߳���
					new Thread(loe).start();
					out.write("false");
					out.close();
					checkUser = false;
				}
			}
		}
		if (checkUser) {
			user = userService.login(data[0], data[1],
					Integer.parseInt(request.getParameter("type")));
			request.getSession().setAttribute("user", user);
			userList.add(user);
			out.write("true");
			out.close();
		}
		People.numberOfPeople++;
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

	// -------------------
	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

}

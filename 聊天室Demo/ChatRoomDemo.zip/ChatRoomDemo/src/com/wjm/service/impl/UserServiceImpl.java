package com.wjm.service.impl;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.wjm.chatBean.ChatContent;
import com.wjm.chatBean.User;
import com.wjm.service.UserService;

/**
 * �û�ʵ����
 * 
 * @author ������
 * 
 */
public class UserServiceImpl implements UserService {

	@Override
	public User login(String name, String toUser, int chatType) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setLogOutDate(new Date());
		user.setName(name);
		user.setToUser(toUser);
		user.setDate(new Date());
		user.setChatType(chatType);
		user.setContent(new ChatContent());

		return user;
	}

	@Override
	public int numberOfPeople(HttpServletRequest request) {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();

		return 0;
	}

}

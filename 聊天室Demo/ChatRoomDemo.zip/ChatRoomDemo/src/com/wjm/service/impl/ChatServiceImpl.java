package com.wjm.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.wjm.chatBean.ChatContent;
import com.wjm.chatBean.User;
import com.wjm.service.ChatService;
import com.wjm.servlet.Chat;

/**
 * ����ʵ����
 * 
 * @author ������
 * 
 */
public class ChatServiceImpl implements ChatService {

	@Override
	public ChatContent addContent(String data, User user) {
		// TODO Auto-generated method stub
		ChatContent chatContent = new ChatContent();
		chatContent.setContent(data);
		chatContent.setDate(new Date());
		chatContent.setFromName(user.getName());
		chatContent.setType(user.getChatType());
		chatContent.setId(Chat.chatContent.size() + 1L);
		if (user.getChatType() == 0) {
			chatContent.setToName("all");// �����ҷ���ȫ����
		} else {
			chatContent.setToName(user.getToUser());// ����˭
		}
		return chatContent;
	}

	@Override
	public List<ChatContent> checkEndChatContent(List<ChatContent> chatContent,
			User user) {
		// TODO Auto-generated method stub
		List<ChatContent> endChatContent = new ArrayList<ChatContent>();
		if (user.getContent().getId() != null) {
			if (chatContent.size() > 0) {
				for (ChatContent cc : chatContent) {
					if (user.getContent().getDate().getTime() < cc.getDate()
							.getTime() && cc.getType() == user.getChatType()) {// ����
						endChatContent.add(cc);
					}
				}
			}
		} else {// û�����һ����Ϣ
			if (chatContent.size() > 0) {// �ж��ڴ������¼
				for (ChatContent cc : chatContent) {
					if (user.getDate().getTime() < cc.getDate().getTime()
							&& cc.getType() == user.getChatType()) {// ����
						endChatContent.add(cc);
					}
				}
			}
		}
		return endChatContent;
	}

	@Override
	public String newMessage(List<ChatContent> chatContentList,User user) {
		// TODO Auto-generated method stub
		StringBuffer temMessage = new StringBuffer();
		String message = null;
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		for (ChatContent cc : chatContentList) {
			
			temMessage.append(cc.getFromName() + ":" + cc.getContent()
					+ "[����ʱ��:" + sdf.format(cc.getDate()) + "]&");
			
		}
		message = temMessage.toString();

		return message;
	}

	@Override
	public List<ChatContent> checkChatPrivacyEndMessage(User user) {
		// TODO Auto-generated method stub
		List<ChatContent> missMessage = new ArrayList<ChatContent>();
		// Long tmpDefferent = 0L;// ʱ���
		if (user.getContent().getId() != null) {// �������һ������
			if (Chat.chatContent.size() > 0) {
				for (ChatContent cc : Chat.chatContent) {
					if (cc.getDate().getTime() > user.getContent().getDate()
							.getTime()
							&& cc.getType() == user.getChatType()) {
						if (cc.getToName() .equals(user.getName())
								|| cc.getFromName() .equals(user.getName())) {
							missMessage.add(cc);
						}
					}
				}
			}
		} else {// ������
			if (Chat.chatContent.size() > 0) {// �����¼����
				for (ChatContent cc : Chat.chatContent) {// ѭ��
					if (user.getLogOutDate() != null) {//�ж��Ƿ��״ε�½
						if (user.getLogOutDate().getTime() < cc.getDate().getTime() & cc.getType() == user.getChatType()) {// miss
							if (cc.getToName() .equals(user.getName())|| cc.getFromName().equals(user.getName())) {// �ж��Լ��������˼ҷ�
								missMessage.add(cc);
							}
						}
					}else{//�״ε�½
						
					}
				}
			}
		}
		return missMessage;
	}
}

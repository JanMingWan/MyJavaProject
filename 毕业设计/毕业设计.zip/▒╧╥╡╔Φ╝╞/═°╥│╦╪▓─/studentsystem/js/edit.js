// JavaScript Document
function oderNewItem_slt(){
document.form1.action="oderNewItem_slt.html"
document.form1.target="bottom"
}

function productMainClass_add(){
document.productMainClass.action="productMainClass_add.html"
document.productMainClass.target="bottom"
}

function productMainClass_edit(){
document.productMainClass.action="productMainClass_edit.html"
document.productMainClass.target="bottom"
}


function productSubClass_add(){
document.productSubClass.action="productSubClass_add.html"
document.productSubClass.target="bottom"
}

function productSubClass_edit(){
document.productSubClass.action="productSubClass_edit.html"
document.productSubClass.target="bottom"
}


function orderSendAddr_add(){
document.orderSendAddr.action="orderSendAddr_add.html"
document.orderSendAddr.target="bottom"
}

function orderSendAddr_edit(){
document.orderSendAddr.action="orderSendAddr_edit.html"
document.orderSendAddr.target="bottom"
}

function roseModelAccess_add(){
document.roseModelAccess.action="roseModelAccess_add.html"
document.roseModelAccess.target="bottom"
}

function roseModelAccess_edit(){
document.roseModelAccess.action="roseModelAccess_edit.html"
document.roseModelAccess.target="bottom"
}

function employee_add(){
document.employee.action="employee_add.html"
document.employee.target="bottom"
}

function employee_edit(){
document.employee.action="employee_edit.html"
document.employee.target="bottom"
}


function department_add(){
document.department.action="department_add.html"
document.department.target="bottom"
}

function department_edit(){
document.department.action="department_edit.html"
document.department.target="bottom"
}


function rose_add(){
document.rose.action="rose_add.html"
document.rose.target="bottom"
}

function rose_edit(){
document.rose.action="rose_edit.html"
document.rose.target="bottom"
}



function modelSub_add(){
document.modelSub.action="model_add.html"
document.modelSub.target="bottom"
}

function modelSub_edit(){
document.modelSub.action="model_edit.html"
document.modelSub.target="bottom"
}


function business_add(){
document.business.action="business_add.html"
document.business.target="bottom"
}

function business_edit(){
document.business.action="business_edit.html"
document.business.target="bottom"
}


/*
function type_add(){
document.form1.action="document_type_add.html"
document.form1.targe="main"
}
function type_delete(){
document.form1.action="document_type_delete.jsp"
document.form1.target="main"
}
function doc_view_select(){
document.form1.action="document_view_select.jsp"
document.form1.target="main"
}

function doc_add(){
document.form1.action="document_add.html"
document.form1.targe="main"
}
function doc_select(){
document.form1.action="docselect.jsp"
document.form1.target="main"
return true;
}
function doc_distribute(){
document.form1.action="doc_distribute.jsp"
document.form1.target="bottom"
}
function doc_update(){
document.form1.action="doc_update.jsp"
document.form1.target="bottom"
}
function infor_type_add(){
document.form1.action="information_type_add.html"
document.form1.targe="main"
}
function infor_type_delete(){
document.form1.action="information_type_delete.jsp"
document.form1.target="main"
}
function infor_view(){
document.form1.action="information_view.jsp"
document.form1.target="main"
}
function infor_distribute(){
document.form1.action="information_distribute.jsp"
document.form1.targe="main"
}
function infor_update(){
document.form1.action="information_update.jsp"
document.form1.target="main"
}
function infor_delete(){
document.form1.action="information_delete.jsp"
document.form1.target="main"
}
function selectpage(){
document.selectpage.action="job_more_1.jsp"
document.selectpage.target="iframe"
}
*/

	
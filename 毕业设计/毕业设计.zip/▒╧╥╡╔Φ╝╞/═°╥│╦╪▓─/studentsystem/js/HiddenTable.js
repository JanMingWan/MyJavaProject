// JavaScript Document
function hiddenall(objTr){
	if(objTr==jibenziliao){
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==jibencanshu){
	jibenziliao.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==waixingcanshu){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";;
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==dipancanshu){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==fadongjicanshu){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==qitacanshu){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==qitashuoming){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	}
	else if(objTr==biaozhunzhuangbei){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	xuanzhuangzhuangbei.style.display = "none";
	} 
	else if(objTr==xuanzhuangzhuangbei){
	jibenziliao.style.display = "none";
	jibencanshu.style.display = "none";
	waixingcanshu.style.display = "none";
	dipancanshu.style.display = "none";
	fadongjicanshu.style.display = "none";
	qitacanshu.style.display = "none";
	qitashuoming.style.display = "none";
	biaozhunzhuangbei.style.display = "none";
	}
	}
package com.wjm.mainChange;

import java.io.IOException;

import com.wjm.main.WriteExcel;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;

/**
 * 
 * @classDescription:入口Main方法
 * @author: 王嘉明
 * @cerateTime: 2014-1-15
 * @className: change.java
 */
public class change {
	/**
	 * 程序入口
	 * @param args
	 * @throws BiffException
	 * @throws IOException
	 * @throws WriteException
	 */
	public static void main(String[] args) throws BiffException, IOException, WriteException {
		WriteExcel we=new WriteExcel("C:/Users/wjm/Desktop/test2/test.xls","C:/Users/wjm/Desktop/test2/central(公共卫生部分).xls");
		we.entrance();
		System.out.println("转换结束");
	}
}

package com.wjm.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import com.wjm.resources.WriteResources;

/**
 * 
 * @classDescription:Update-Excel
 * @author: 王嘉明
 * @cerateTime: 2014-1-16
 * @className: WriteExcel.java
 */
public class WriteExcel {
	private String path = "";
	private String centralPath = "";
	private Workbook book;
	private WritableWorkbook wbook;

	/**
	 * 有参构造方法
	 * 
	 * @param path
	 *            需要写的Excel路径
	 * @throws IOException 中央Excel
	 * @throws BiffException
	 * 
	 */
	public WriteExcel(String path, String centralPath) throws BiffException,
			IOException {
		this.centralPath = centralPath;
		book = Workbook.getWorkbook(new File(path));
		wbook = Workbook.createWorkbook(new File(path), book);// 副本
	}

	/**
	 * 入口
	 * 
	 * @param readCentralExcelPatp
	 *            中央Excel
	 * @throws IOException
	 * @throws WriteException
	 */
	// 测试名
	public void entrance() throws IOException, WriteException {
		for (int i = 0; i < book.getNumberOfSheets(); i++) {// 遍历里面所有工作簿
			System.out.println("转化器正在处理：" + book.getSheet(i).getName() + "工作簿");
			Sheet wSheet = wbook.getSheet(i);
			translation(wSheet, i);// 翻译表
		}
		close();
	}

	/**
	 * 翻译方法
	 * 
	 * @param sheet
	 *            工作簿
	 * @throws IOException
	 * @throws WriteException
	 */
	public void translation(Sheet sheet, int sheetNum) throws WriteException,
			IOException {
		String sheetName = sheet.getName();
		ReadCentralExcel re = new ReadCentralExcel(centralPath);
		Sheet centralSheet = re.matchSheet(sheetName);// 中央Excel表
		int row = sheet.getRows(), column = sheet.getColumns();
		int titleRow = 0, titleColumn = 10000, contentRow = 0, contentColumn = 0, englishRow = 0, englishColumn = 0;
		if (centralSheet != null) {// 若存在对应表开始移植数据
			/**
			 * 解析坐标
			 */
			for (Map.Entry<Integer, String> coordinate : searchCoordinate(sheet)
					.entrySet()) {
				if (coordinate.getKey() == 0) {// 中文字段
					String sc = coordinate.getValue();
					String coord[] = sc.split(",");
					titleRow = Integer.valueOf(coord[0]);
					titleColumn = Integer.valueOf(coord[1]);
				}
				if (coordinate.getKey() == 1) {// 中文字段
					String sc = coordinate.getValue();
					String coord[] = sc.split(",");
					contentRow = Integer.valueOf(coord[0]);
					contentColumn = Integer.valueOf(coord[1]);
				}
				if (coordinate.getKey() == 2) {// 中文字段
					String sc = coordinate.getValue();
					String coord[] = sc.split(",");
					englishRow = Integer.valueOf(coord[0]);
					englishColumn = Integer.valueOf(coord[1]);
				}
			}
			if (titleColumn < 9999) {// 是否存在中文列
				for (int i = titleRow + 1; i < row; i++) {// 循环行
					String translationName = re.matchPropertyTitle(centralSheet,sheet.getCell(titleColumn, i).getContents().trim()).trim();
                   if (!translationName.equals("")) {// 若查到
						write(sheetNum, i, contentColumn, translationName);
					} else {// 若差不多，翻译自身英文
						write(sheetNum, i, contentColumn,getEnglishName(sheet, i, englishColumn));
					}
				}
			}

		} else {// 否则开始自己翻译
			for (Map.Entry<Integer, String> coordinate : searchCoordinate(sheet).entrySet()) {
				if (coordinate.getKey() == 1) {// 翻译位置字段
					String sc = coordinate.getValue();
					String coord[] = sc.split(",");
					contentRow = Integer.valueOf(coord[0]);
					contentColumn = Integer.valueOf(coord[1]);
				}
				if (coordinate.getKey() == 2) {// 英文字段
					String sc = coordinate.getValue();
					String coord[] = sc.split(",");
					englishRow = Integer.valueOf(coord[0]);
					englishColumn = Integer.valueOf(coord[1]);
				}
			}
			for(int i=contentRow+1;i<row;i++){//循环英文
				String eName=getEnglishName(sheet, i, englishColumn);
				write(sheetNum, i, contentColumn, eName);
			}
			
			
		}
	}

	/**
	 * 写入内容 ps:内容超长30个字符变红
	 * 
	 * @param sheetNum
	 *            工作簿号
	 * @param row
	 *            行号
	 * @param column
	 *            列号
	 * @param content
	 *            内容
	 * @throws RowsExceededException
	 * @throws IOException
	 * @throws WriteException
	 */
	public void write(int sheetNum, int row, int column, String content)
			throws RowsExceededException, WriteException {
		WritableSheet wSheet = wbook.getSheet(sheetNum);
		if (content.length() > 30) {
			WritableFont font = new WritableFont(WritableFont.TIMES, 10,
					WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE,
					Colour.RED);
			WritableCellFormat wcf = new WritableCellFormat(font);
			Label label = new Label(column, row, content, wcf);
			wSheet.addCell(label);
		} else {
			Label label = new Label(column, row, content);
			wSheet.addCell(label);
		}
	}

	/**
	 * 获取翻译好的自身英文
	 * 
	 * @param sheet
	 * @param row
	 * @param column
	 */
	public String getEnglishName(Sheet sheet, int row, int column) {
		return tranEnglist(sheet.getCell(column, row).getContents().trim());
	}

	/**
	 * 翻译自身英文
	 * 
	 * @param content
	 * @return
	 */
	public String tranEnglist(String content) {
		/**
		 * 记录大写的位置
		 */
		List<Integer> location = new ArrayList<Integer>(0);
		char[] ch = content.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			if ((int) ch[i] >= 65 && (int) ch[i] <= 90) {
				location.add(i - 1);
			}
		}
		StringBuffer sringBuffer = new StringBuffer(content);
		if (location.size() <= 0) {
			return content.toLowerCase();
		} else {
			for (int i = 1; i < location.size(); i++) {
				sringBuffer.insert(location.get(i) + i, "_");
			}
			return sringBuffer.toString().toLowerCase();
		}
	}

	/**
	 * 关闭方法
	 * 
	 * @throws IOException
	 * @throws WriteException
	 */
	public void close() throws IOException, WriteException {
		wbook.write();
		wbook.close();
		book.close();
	}

	/**
	 * 寻找需要翻译的中文字段头坐标
	 * 
	 * @param writeSheet
	 * @return 0=字段头;1=写入翻译的坐标;2=原来英文坐标
	 */
	public Map<Integer, String> searchCoordinate(Sheet writeSheet) {
		int row = writeSheet.getRows();// 获取行
		int column = writeSheet.getColumns();// 获取列
		boolean titleTOF = false, propertyTOF = false, englistTOF = false;
		Map<Integer, String> Coordinate = new HashMap<Integer, String>(3);
		for (int i = 0; i < row; i++) {// 循环行
			for (int j = 0; j < column; j++) {// 循环列
				/**
				 * 头字段
				 */
				for (int listNum = 0; listNum < WriteResources.getTitle()
						.size(); listNum++) {// 循环字段头资源
					if (writeSheet.getCell(j, i).getContents().trim()
							.equals(WriteResources.getTitle().get(listNum))) {
						Coordinate.put(0, i + "," + j);
						titleTOF = true;
					}
				}
				/**
				 * 翻译
				 */
				for (int listNum = 0; listNum < WriteResources.getProperty()
						.size(); listNum++) {// 循环字段头资源
					if (writeSheet.getCell(j, i).getContents().trim()
							.equals(WriteResources.getProperty().get(listNum))) {
						Coordinate.put(1, i + "," + j);
						propertyTOF = true;
					}
				}
				/**
				 * 原来英文坐标
				 */
				for (int listNum = 0; listNum < WriteResources.getEnglisth()
						.size(); listNum++) {// 循环字段头资源
					if (writeSheet.getCell(j, i).getContents().trim()
							.equals(WriteResources.getEnglisth().get(listNum))) {
						Coordinate.put(2, i + "," + j);
						englistTOF = true;
					}
				}
				if (titleTOF == true && propertyTOF == true
						&& englistTOF == true) {
					break;
				}
			}
			if (titleTOF == true && propertyTOF == true && englistTOF == true) {
				break;
			}
		}
		return Coordinate;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}

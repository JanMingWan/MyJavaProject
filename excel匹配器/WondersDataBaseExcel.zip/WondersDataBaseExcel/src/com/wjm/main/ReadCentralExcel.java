package com.wjm.main;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import com.wjm.resources.CentralExcelResources;

/**
 * 
 * @classDescription:读取中央excel
 * @author: 王嘉明
 * @cerateTime: 2014-1-15
 * @className: ReadExcel.java
 */
public class ReadCentralExcel {
	private String path = "";
	private Workbook book;// 读取的excel
	/**
	 * 有参构造常数
	 * 
	 * @param path
	 *            读取文档的路径
	 */
	public ReadCentralExcel(String path) {
		try {
			book = Workbook.getWorkbook(new File(path));
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 获取工作薄数量
	 * 
	 * @return
	 */
	public int getSheetNum() {
		return book.getNumberOfSheets();
	}

	/**
	 * 获取工作薄名字
	 * 
	 * @param i
	 * @return
	 */
	public String getSheetName(int i) {
		return book.getSheet(i).getName();
	}

	/**
	 * 获取工作薄行数
	 * 
	 * @param i
	 * @return
	 */
	public int getSheetRows(int i) {
		return book.getSheet(i).getRows();
	}

	/**
	 * 匹配工作薄
	 * 
	 * @return
	 */
	public Sheet matchSheet(String name) {
		Sheet matchSheet = null;
		for (int i = 0; i < getSheetNum(); i++) {
			if (book.getSheet(i).getName().trim().equals(name.trim())) {
				matchSheet = book.getSheet(i);
				break;
			}
		}
		return matchSheet;
	}

	/**
	 * 返回匹配英文
	 * 
	 * @param sheet
	 * @return
	 */
	public String matchPropertyTitle(Sheet sheet, String name) {
		String propertyName="";
		boolean titleTOF = false,propertyTOF=false;
		int row = sheet.getRows();// 获取行
		int column = sheet.getColumns();// 获取列
		int titleRow=0,titleColumn=0,propertyRow=0,propertyColumn=0;// 当前行列
		
		/**
		 * 寻找匹配列
		 */
		for (int columnNum = 0; columnNum < column; columnNum++) {
			for (int rowNum = 0; rowNum < row; rowNum++) {
				for (int listNum = 0; listNum < CentralExcelResources.getTitle().size(); listNum++) {//属性中文定位
					if (sheet.getCell(columnNum, rowNum).getContents().trim().equals(CentralExcelResources.getTitle().get(listNum))) {
						titleRow = rowNum;
						titleColumn = columnNum;
						titleTOF = true;
					}
				}
				for(int listNum = 0; listNum < CentralExcelResources.getProperty().size(); listNum++){//翻译定位
					if (sheet.getCell(columnNum, rowNum).getContents().trim().equals(CentralExcelResources.getProperty().get(listNum))) {
						propertyRow = rowNum;
						propertyColumn = columnNum;
						propertyTOF = true;
					}
				}
				if (titleTOF==true&&propertyTOF==true) {
					break;
				}
			}
			if (titleTOF==true&&propertyTOF==true) {
				break;
			}
		}
		/**
		 * 寻找匹配的属性
		 */
		//System.out.println(titleRow+":"+titleColumn+":"+propertyRow+":"+propertyColumn);
		
		for(int i=titleRow;i<row;i++){
			if(sheet.getCell(titleColumn,i).getContents().trim().equals(name.trim())){
				propertyName=sheet.getCell(propertyColumn,i).getContents();
			    break;
			}
		}
		return propertyName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}

package com.wjm.resources;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @classDescription:需要翻译的Excel资源文件
 * @author: 王嘉明
 * @cerateTime: 2014-1-15
 * @className: WriteResources.java
 */
public class WriteResources {
	/**
	 * 获取excel匹配文档
	 * @return
	 */
	public static List<String> getTitle() {//中文名
		List<String> title = new ArrayList<String>();
		title.add("数据元名称");
		return title;
	}
	
	public static List<String>getProperty(){//数据库翻译名
		List<String> property = new ArrayList<String>();
		property.add("中心字段名");
		return property;
	}
	
	public static List<String>getEnglisth(){//数据库翻译名
		List<String> property = new ArrayList<String>();
		property.add("接口字段名");
		return property;
	}
}

package com.wjm.resources;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @classDescription:资源文件
 * @author: 王嘉明
 * @cerateTime: 2014-1-15
 * @className: Resources.java
 */
public class CentralExcelResources {
	/**
	 * 获取excel匹配文档
	 * @return
	 */
	public static List<String> getTitle() {//中文名
		List<String> title = new ArrayList<String>();
		title.add("数据元名称");
		title.add("中文描述");
		title.add("数据项");
		return title;
	}
	
	public static List<String>getProperty(){//数据库翻译名
		List<String> property = new ArrayList<String>();
		property.add("中心字段名");
		property.add("数据库字段名");
		property.add("中心字段");
		return property;
	}
}
